```
 * OmiGA: a toolkit for Omics Genetic Analysis
 *
 * Copyright © 2024, Jinyan Teng
 *
 * This file is distributed under the GNU General Public
 * License, Version 3. Please see the file LICENSE for more
 * details.
 *
 * All the files in this project are allowed to be copied, 
 * modified, and distributed for educational, research and 
 * non-profit purposes, without charge and without a written 
 * agreement, provided that this copyright notice are included
 * in all copies. If you intend to use this project for 
 * commercial purposes, kindly contact the author for 
 * authorization prior to use.
```
struct PartialV{T}
    vec_ratio::Vector{T}
    eigvals::Vector{T}
    eigvecs::Matrix{T}
end
struct LowRankApproxUDV{T}
    U::Matrix{T}
    D::Vector{T}
    V::Matrix{T}
    M::Matrix{T}
    method::String
    rank::Int
    _2_norm::Float64
    corr::Float64
end
function LowRankApproxUDV(K2::Matrix{T}, approx_method::String, approx_rank::Int, avg_2norm_threshold::AbstractFloat, max_rank::Number) where {T}
    _2_norm = 1e6
    test_rank = copy(approx_rank)
    iter = 1
    K2U = nothing
    K2D = nothing
    K2V = nothing
    M = nothing
    corr = NAN
    if max_rank isa AbstractFloat
        max_rank_prop = max_rank
        max_rank = Int(round(size(K2, 1) * max_rank_prop))
    end
    while true
        if approx_method == "aca"
            K2U, K2V = aca(K2, test_rank)
            K2D = ones(T, test_rank)
            K2V = K2V' |> Matrix
        elseif approx_method == "psvd"
            opts = LRAOptions(rank=test_rank, rtol=1e-20)
            F = psvdfact(K2, opts)
            K2U = F.U
            K2D = F.S
            K2V = F.Vt
        elseif approx_method == "cur"
            opts = LRAOptions(rank=test_rank, rtol=1e-20)
            U = curfact(K2, opts)
            F = CUR(K2, U)
            K2U = F.C
            K2D = F.U
            K2V = F.C'
        elseif approx_method == "pheig"
            opts = LRAOptions(rank=test_rank, rtol=1e-20)
            F = pheigfact(K2, opts)
            K2U = F.vectors
            K2D = F.values
            K2V = F.vectors' |> Matrix
        end
        M = K2U * diagm(K2D) * K2V
        corr = cor(M[:], K2[:])
        _2_norm = norm(M - K2)
        avg_2_norm = _2_norm^2 / length(M)
        println("LRA iter: ", iter, ", approx_rank: ", test_rank, ", _2_norm: ", _2_norm, ", avg_2_norm: ", avg_2_norm)
        if (avg_2_norm < avg_2norm_threshold) | (test_rank >= max_rank)
            break
        else
            alpha = _2_norm / sqrt(avg_2norm_threshold * length(M))
            alpha *= 1.5
            test_rank = Int(round(alpha * test_rank))
            if test_rank > max_rank
                test_rank = max_rank
            end
        end
        iter += 1
    end
    test_rank = length(K2D)
    println("Final LRA rank: ", test_rank)
    LowRankApproxUDV{eltype(K2U)}(K2U, K2D, K2V, M, approx_method, test_rank, _2_norm, corr)
end
function reml(VCM_Arr::Vector{Matrix{T}}, y::Vector{T}, X::Matrix{T}, Vi_X::Matrix{T}, Xt_Vi_X_i::Matrix{T}, Hi::Matrix{T}, Py::Vector{T}, P::Matrix{T}, PA::Matrix{T}, Vi::Matrix{T}, cVi::Matrix{T}, Di::Diagonal{T,Vector{T}}, EAvec_Di::Matrix{T}, EAvec::Matrix{T}; pred_rand_eff::Bool=false, EA::Union{Nothing,Eigen{T,T,Matrix{T},Vector{T}}}=nothing, varcmp::Union{Nothing,Vector{T}}=nothing, partialV::Union{Nothing,PartialV{Float32}}=nothing, LRA_factors::Union{Nothing,LowRankApproxUDV{T}}=nothing, em_update::Bool=false, convergence_parameters::T=1e-8, convergence_dlogL::T=NAN) where {T}
    begin
        _n = length(y)
        Var_y = var(y)
        _n_cmp = length(VCM_Arr)
        _X_c = size(X, 2)
        fill!(Vi_X, 0)
        fill!(Xt_Vi_X_i, 0)
        fill!(Hi, 0)
        fill!(Py, 0)
        fill!(P, 0)
        fill!(PA, 0)
        fill!(Vi, 0)
        fill!(cVi, 0)
        fill!(cVi, 0)
        fill!(Di, 0)
        fill!(EAvec_Di, 0)
        no_constrain = false
        prior_var_flag = !isnothing(varcmp)
        if !prior_var_flag
            varcmp = zeros(T, _n_cmp)
            varcmp .= Var_y / _n_cmp
        else
            if em_update
                prior_var_flag = false
            else
                prior_var_flag = true
            end
        end
    end
    lgL, converged_flag = reml_iteration(VCM_Arr, y, X, Vi_X, Xt_Vi_X_i, Hi, Py, varcmp, P, PA, Vi, cVi, Di, EAvec_Di, EAvec, prior_var_flag=prior_var_flag, EA=EA, partialV=partialV, LRA_factors=LRA_factors, convergence_parameters=convergence_parameters, convergence_dlogL=convergence_dlogL)
    begin
        if pred_rand_eff
            u = zeros(T, _n, _n_cmp)
            for i in 1:_n_cmp
                u[:, i] .= matmul(VCM_Arr[i], Py) * varcmp[i]
            end
        else
            u = nothing
        end
        b_bat = zeros(T, _X_c)
        matmul!(b_bat, matmul(Xt_Vi_X_i, Vi_X'), y)
        Hsq = zeros(T, _n_cmp - 1)
        VarHsq = zeros(T, _n_cmp - 1)
        Vp, VarVp = calcu_Vp(varcmp, Hi)
        for i in eachindex(Hsq)
            Hsq[i], VarHsq[i] = calcu_hsq(i, Vp, VarVp, varcmp, Hi)
        end
    end
    abc_uni = Dict(
        :ΣG => varcmp[1:(_n_cmp-1)],
        :ΣG_se => nothing,
        :Σe => varcmp[_n_cmp],
        :Σe_se => nothing,
        :Σp => Vp,
        :Σp_se => VarVp,
        :h2 => Hsq,
        :h2_se => VarHsq,
        :logL => lgL,
        :logL0 => nothing,
        :n => _n,
        :Fix_eff => b_bat,
        :Fix_eff_se => nothing,
        :u => u,
        :converged => converged_flag
    )
    return abc_uni
end
function reml(VCM_Arr::Vector{Matrix{T}}, y::Vector{T}, X::Matrix{T}; pred_rand_eff::Bool=false, EA::Union{Nothing,Eigen{T,T,Matrix{T},Vector{T}}}=nothing, varcmp::Union{Nothing,Vector{T}}=nothing, partialV::Union{Nothing,PartialV{Float32}}=nothing, LRA_factors::Union{Nothing,LowRankApproxUDV{T}}=nothing, em_update::Bool=false, convergence_parameters::T=1e-6, convergence_dlogL::T=NAN) where {T}
    begin
        _n = length(y)
        Var_y = var(y)
        _n_cmp = length(VCM_Arr)
        _X_c = size(X, 2)
        Vi_X = zeros(T, _n, _X_c)
        Xt_Vi_X_i = zeros(T, _X_c, _X_c)
        Hi = zeros(T, _n_cmp, _n_cmp)
        Py = zeros(T, _n)
        no_constrain = false
        prior_var_flag = !isnothing(varcmp)
        if !prior_var_flag
            varcmp = zeros(T, _n_cmp)
            varcmp .= Var_y / _n_cmp
        else
            if em_update
                prior_var_flag = false
            else
                prior_var_flag = true
            end
        end
    end
    lgL, converged_flag = reml_iteration(VCM_Arr, y, X, Vi_X, Xt_Vi_X_i, Hi, Py, varcmp, prior_var_flag=prior_var_flag, EA=EA, partialV=partialV, LRA_factors=LRA_factors, convergence_parameters=convergence_parameters, convergence_dlogL=convergence_dlogL)
    begin
        if pred_rand_eff
            u = zeros(T, _n, _n_cmp)
            for i in 1:_n_cmp
                u[:, i] .= matmul(VCM_Arr[i], Py) * varcmp[i]
            end
        else
            u = nothing
        end
        b_bat = zeros(T, _X_c)
        matmul!(b_bat, matmul(Xt_Vi_X_i, Vi_X'), y)
        Hsq = zeros(T, _n_cmp - 1)
        VarHsq = zeros(T, _n_cmp - 1)
        Vp, VarVp = calcu_Vp(varcmp, Hi)
        for i in eachindex(Hsq)
            Hsq[i], VarHsq[i] = calcu_hsq(i, Vp, VarVp, varcmp, Hi)
        end
    end
    abc_uni = Dict(
        :ΣG => varcmp[1:(_n_cmp-1)],
        :ΣG_se => nothing,
        :Σe => varcmp[_n_cmp],
        :Σe_se => nothing,
        :Σp => Vp,
        :Σp_se => VarVp,
        :h2 => Hsq,
        :h2_se => VarHsq,
        :logL => lgL,
        :logL0 => nothing,
        :n => _n,
        :Fix_eff => b_bat,
        :Fix_eff_se => nothing,
        :u => u,
        :converged => converged_flag
    )
    return abc_uni
end
function reml_iteration(VCM_Arr::Vector{Matrix{T}}, y::Vector{T}, X::Matrix{T}, Vi_X::Matrix{T}, Xt_Vi_X_i::Matrix{T}, Hi::Matrix{T}, Py::Vector{T}, varcmp::Vector{T}, P::Matrix{T}, PA::Matrix{T}, Vi::Matrix{T}, cVi::Matrix{T}, Di::Diagonal{T,Vector{T}}, EAvec_Di::Matrix{T}, EAvec::Matrix{T}; prior_var_flag::Bool=false, reml_max_iter::Int=100, no_constrain::Bool=false, EA::Union{Nothing,Eigen{T,T,Matrix{T},Vector{T}}}=nothing, partialV::Union{Nothing,PartialV{Float32}}=nothing, LRA_factors::Union{Nothing,LowRankApproxUDV{T}}=nothing, convergence_parameters::T=1e-6, convergence_dlogL::T=NAN) where {T}
    if isnan(convergence_dlogL)
        is_calcu_logdet = false
    else
        is_calcu_logdet = true
    end
    begin
        mtd_str = ["AI-REML", "EM-REML"]
        _n_cmp = length(VCM_Arr)
        _var_name = ["Ve"]
        for i in (_n_cmp-1):-1:1
            pushfirst!(_var_name, string("Vg", i))
        end
        _n = length(y)
        Var_y = var(y)
        if !isnothing(LRA_factors)
            approx_rank = LRA_factors.rank
            Ai_U = zeros(T, _n, approx_rank)
            V_Ai = zeros(T, approx_rank, _n)
            V_Ai_U = zeros(T, approx_rank, approx_rank)
            Ai_U_Di_V_Ai_U_i = zeros(T, _n, approx_rank)
            Ai_U_Di_V_Ai_U_i_V_Ai = zeros(T, _n, _n)
        end
        if !isnothing(EA)
            EAvect = EA.vectors' |> Matrix
        end
        _reml_mtd = 1
        constrain_num = 0
        iter = 0
        reml_mtd_tmp = copy(_reml_mtd)
        logdet_V = 0.0
        logdet_Xt_Vi_X = 0.0
        prev_lgL = -1e20
        lgL = -1e20
        dlogL = 1000.0
        dpars = 100.0
        dgra = 100.0
        prev_dlogL = 1000.0
        unstable_dlogL = false
        extreme_dlogL = false
        n_unreliable = 0
        prev_prev_varcmp = copy(varcmp)
        prev_varcmp = copy(varcmp)
        varcomp_init = copy(varcmp)
        converged_flag = false
    end
    while iter < reml_max_iter
        if iter == 0
            prev_varcmp .= varcomp_init
            if prior_var_flag
                print("Prior values of variance components: ")
                for i in 1:_n_cmp
                    print(varcmp[i], "\t")
                end
                println()
            else
                _reml_mtd = 2
                println("Calculating prior values of variance components by EM-REML ...")
            end
        end
        if iter == 1
            _reml_mtd = copy(reml_mtd_tmp)
            print("Prior values of variance components: ")
            for i in 1:_n_cmp
                print(varcmp[i], "\t")
            end
            println()
            if is_calcu_logdet
                print(string("Running ", mtd_str[_reml_mtd], " algorithm ...", "\nIter.\tlogL\tdpars\t"))
            else
                print(string("Running ", mtd_str[_reml_mtd], " algorithm ...", "\nIter.\tdpars\t"))
            end
            for i in 1:_n_cmp
                print(_var_name[i], "\t")
            end
            println()
        end
        if (_n_cmp == 2) && !isnothing(EA)
            logdet_V = calcu_Vi!(Vi, VCM_Arr, prev_varcmp, EA, Di, EAvec_Di, EAvect, cVi, is_calcu_logdet=is_calcu_logdet)
        elseif (_n_cmp == 3) && !isnothing(LRA_factors)
            logdet_V = calcu_Vi!(Vi, VCM_Arr, prev_varcmp, EA, Di, EAvec_Di, EAvect, LRA_factors, Ai_U, V_Ai, V_Ai_U, Ai_U_Di_V_Ai_U_i, Ai_U_Di_V_Ai_U_i_V_Ai, is_calcu_logdet=is_calcu_logdet)
        elseif (_n_cmp == 3) && !isnothing(partialV)
            logdet_V = calcu_Vi!(Vi, VCM_Arr, prev_varcmp, partialV, Di, EAvec_Di, EAvec, is_calcu_logdet=is_calcu_logdet)
        else
            logdet_V = calcu_Vi!(Vi, VCM_Arr, prev_varcmp, is_calcu_logdet=is_calcu_logdet)
        end
        if isinf(logdet_V)
            break
        end
        logdet_Xt_Vi_X = calcu_P!(Vi, Vi_X, Xt_Vi_X_i, P, X, is_calcu_logdet=is_calcu_logdet)
        if isinf(logdet_Xt_Vi_X)
            break
        end
        if _reml_mtd == 1
            delta, R = ai_reml!(PA, P, Hi, Py, prev_varcmp, varcmp, dlogL, VCM_Arr, y, is_calcu_logdet=is_calcu_logdet, prev_prev_varcmp=prev_prev_varcmp)
            if isnan(delta[1])
                break
            end
        elseif _reml_mtd == 2
            R = em_reml!(PA, P, Py, prev_varcmp, varcmp, VCM_Arr, y)
        end
        lgL = -0.5 * (logdet_Xt_Vi_X + logdet_V + dot(y, Py))
        if !no_constrain
            constrain_num = constrain_varcmp!(varcmp, y)
        end
        if iter >= 1
            print(iter, "\t")
            @runif is_calcu_logdet print(lgL, "\t")
            print(dpars, "\t")
            for i in 1:_n_cmp
                print(varcmp[i], "\t")
            end
            println()
        end
        dlogL = lgL - prev_lgL
        dpars = norm(varcmp - prev_varcmp)^2 / norm(varcmp)^2
        dgra = norm(R)
        con_1 = dpars < convergence_parameters
        con_2 = abs(dlogL) < convergence_dlogL || (abs(dlogL) < 1e-2 && dlogL < 0)
        con_3 = dgra < 1e-6
        if con_1 || con_2 || con_3
            converged_flag = true
            if con_1
                println("* Parameters change converged.")
            end
            if con_2
                println("* Log-likelihood ratio converged.")
            end
            if con_3
                println("* Partial derivative converged.")
            end
            break
        end
        if iter > ifelse(is_calcu_logdet, 2, 0)
            if sum(varcmp) > 2 * Var_y
                varcmp .= prev_varcmp
                @runif _args_debug println("* sum(varcmp) > 2 * Var_y")
                break
            end
            if abs(lgL) > 1e4
                varcmp .= prev_varcmp
                @runif _args_debug println("* abs(lgL) > 1e4")
                break
            end
            prev_r_t = (prev_varcmp ./ sum(prev_varcmp)) .< 0.0001
            r_t = (varcmp ./ sum(varcmp)) .< 0.0001
            if sum(r_t .& prev_r_t) > 0
                varcmp[r_t.&prev_r_t] .= 0
            end
            extreme_dlogL = abs(dlogL) > abs(prev_dlogL)
            unstable_dlogL = (dlogL * prev_dlogL) < 0
            if extreme_dlogL | unstable_dlogL
                n_unreliable += 1
                println("Warning: Unstable iteration (n = ", n_unreliable, ").")
            end
            unstable_dlogL = false
            extreme_dlogL = false
            if n_unreliable == 3
                @runif _args_debug println("* n_unreliable == 3")
                break
            end
        end
        prev_prev_varcmp .= prev_varcmp
        prev_varcmp .= varcmp
        prev_lgL = copy(lgL)
        prev_dlogL = copy(dlogL)
        iter += 1
    end
    if converged_flag
        println("* AIREML converged.")
    else
        println("* AIREML not converged.")
    end
    return lgL, converged_flag
end
function reml_iteration(VCM_Arr::Vector{Matrix{T}}, y::Vector{T}, X::Matrix{T}, Vi_X::Matrix{T}, Xt_Vi_X_i::Matrix{T}, Hi::Matrix{T}, Py::Vector{T}, varcmp::Vector{T}; prior_var_flag::Bool=false, reml_max_iter::Int=100, no_constrain::Bool=false, EA::Union{Nothing,Eigen{T,T,Matrix{T},Vector{T}}}=nothing, partialV::Union{Nothing,PartialV{Float32}}=nothing, LRA_factors::Union{Nothing,LowRankApproxUDV{T}}=nothing, convergence_parameters::T=1e-8, convergence_dlogL::T=NAN) where {T}
    if isnan(convergence_dlogL)
        is_calcu_logdet = false
    else
        is_calcu_logdet = true
    end
    begin
        mtd_str = ["AI-REML", "EM-REML"]
        _n_cmp = length(VCM_Arr)
        _var_name = ["Ve"]
        for i in (_n_cmp-1):-1:1
            pushfirst!(_var_name, string("Vg", i))
        end
        _n = length(y)
        Var_y = var(y)
        _X_c = size(X, 2)
        P = zeros(T, _n, _n)
        PA = zeros(T, _n, _n)
        Vi = zeros(T, _n, _n)
        cVi = zeros(T, _n, _n)
        if !isnothing(LRA_factors)
            approx_rank = LRA_factors.rank
            Ai_U = zeros(T, _n, approx_rank)
            V_Ai = zeros(T, approx_rank, _n)
            V_Ai_U = zeros(T, approx_rank, approx_rank)
            Ai_U_Di_V_Ai_U_i = zeros(T, _n, approx_rank)
            Ai_U_Di_V_Ai_U_i_V_Ai = zeros(T, _n, _n)
        end
        if !isnothing(EA)
            EAvect = EA.vectors' |> Matrix
        end
        Di = Diagonal(zeros(T, _n, _n))
        EAvec_Di = zeros(T, _n, _n)
        EAvec = zeros(T, _n, _n)
        _reml_mtd = 1
        constrain_num = 0
        iter = 0
        reml_mtd_tmp = copy(_reml_mtd)
        logdet_V = 0.0
        logdet_Xt_Vi_X = 0.0
        prev_lgL = -1e20
        lgL = -1e20
        dlogL = 1000.0
        dpars = 100.0
        dgra = 100.0
        prev_dlogL = 1000.0
        unstable_dlogL = false
        extreme_dlogL = false
        n_unreliable = 0
        prev_prev_varcmp = copy(varcmp)
        prev_varcmp = copy(varcmp)
        varcomp_init = copy(varcmp)
        converged_flag = false
    end
    while iter < reml_max_iter
        if iter == 0
            prev_varcmp .= varcomp_init
            if prior_var_flag
                print("Prior values of variance components: ")
                for i in 1:_n_cmp
                    print(varcmp[i], "\t")
                end
                println()
            else
                _reml_mtd = 2
                println("Calculating prior values of variance components by EM-REML ...")
            end
        end
        if iter == 1
            _reml_mtd = copy(reml_mtd_tmp)
            print("Prior values of variance components: ")
            for i in 1:_n_cmp
                print(varcmp[i], "\t")
            end
            println()
            if is_calcu_logdet
                print(string("Running ", mtd_str[_reml_mtd], " algorithm ...", "\nIter.\tlogL\tdpars\t"))
            else
                print(string("Running ", mtd_str[_reml_mtd], " algorithm ...", "\nIter.\tdpars\t"))
            end
            for i in 1:_n_cmp
                print(_var_name[i], "\t")
            end
            println()
        end
        if (_n_cmp == 2) && !isnothing(EA)
            logdet_V = calcu_Vi!(Vi, VCM_Arr, prev_varcmp, EA, Di, EAvec_Di, EAvect, cVi, is_calcu_logdet=is_calcu_logdet)
        elseif (_n_cmp == 3) && !isnothing(LRA_factors)
            logdet_V = calcu_Vi!(Vi, VCM_Arr, prev_varcmp, EA, Di, EAvec_Di, EAvect, LRA_factors, Ai_U, V_Ai, V_Ai_U, Ai_U_Di_V_Ai_U_i, Ai_U_Di_V_Ai_U_i_V_Ai, is_calcu_logdet=is_calcu_logdet)
        elseif (_n_cmp == 3) && !isnothing(partialV)
            logdet_V = calcu_Vi!(Vi, VCM_Arr, prev_varcmp, partialV, Di, EAvec_Di, EAvec, is_calcu_logdet=is_calcu_logdet)
        else
            logdet_V = calcu_Vi!(Vi, VCM_Arr, prev_varcmp, is_calcu_logdet=is_calcu_logdet)
        end
        if isinf(logdet_V)
            break
        end
        logdet_Xt_Vi_X = calcu_P!(Vi, Vi_X, Xt_Vi_X_i, P, X, is_calcu_logdet=is_calcu_logdet)
        if isinf(logdet_Xt_Vi_X)
            break
        end
        if _reml_mtd == 1
            delta, R = ai_reml!(PA, P, Hi, Py, prev_varcmp, varcmp, dlogL, VCM_Arr, y, is_calcu_logdet=is_calcu_logdet, prev_prev_varcmp=prev_prev_varcmp)
            if isnan(delta[1])
                break
            end
        elseif _reml_mtd == 2
            R = em_reml!(PA, P, Py, prev_varcmp, varcmp, VCM_Arr, y)
        end
        lgL = -0.5 * (logdet_Xt_Vi_X + logdet_V + dot(y, Py))
        if !no_constrain
            constrain_num = constrain_varcmp!(varcmp, y)
        end
        if iter >= 1
            print(iter, "\t")
            @runif is_calcu_logdet print(lgL, "\t")
            print(dpars, "\t")
            for i in 1:_n_cmp
                print(varcmp[i], "\t")
            end
            println()
        end
        dlogL = lgL - prev_lgL
        dpars = norm(varcmp - prev_varcmp)^2 / norm(varcmp)^2
        dgra = norm(R)
        con_1 = dpars < convergence_parameters
        con_2 = abs(dlogL) < convergence_dlogL || (abs(dlogL) < 1e-2 && dlogL < 0)
        con_3 = dgra < 1e-6
        if con_1 || con_2 || con_3
            converged_flag = true
            if con_1
                println("* Parameters change converged.")
            end
            if con_2
                println("* Log-likelihood ratio converged.")
            end
            if con_3
                println("* Partial derivative converged.")
            end
            break
        end
        if iter > ifelse(is_calcu_logdet, 2, 0)
            if sum(varcmp) > 2 * Var_y
                varcmp .= prev_varcmp
                @runif _args_debug println("* sum(varcmp) > 2 * Var_y")
                break
            end
            if abs(lgL) > 1e4
                varcmp .= prev_varcmp
                @runif _args_debug println("* abs(lgL) > 1e4")
                break
            end
            prev_r_t = (prev_varcmp ./ sum(prev_varcmp)) .< 0.0001
            r_t = (varcmp ./ sum(varcmp)) .< 0.0001
            if sum(r_t .& prev_r_t) > 0
                varcmp[r_t.&prev_r_t] .= 0
            end
            extreme_dlogL = abs(dlogL) > abs(prev_dlogL)
            unstable_dlogL = (dlogL * prev_dlogL) < 0
            if extreme_dlogL | unstable_dlogL
                n_unreliable += 1
                println("Warning: Unstable iteration (n = ", n_unreliable, ").")
            end
            unstable_dlogL = false
            extreme_dlogL = false
            if n_unreliable == 3
                @runif _args_debug println("* n_unreliable == 3")
                break
            end
        end
        prev_prev_varcmp .= prev_varcmp
        prev_varcmp .= varcmp
        prev_lgL = copy(lgL)
        prev_dlogL = copy(dlogL)
        iter += 1
    end
    if converged_flag
        println("* AIREML converged.")
    else
        println("* AIREML not converged.")
    end
    return lgL, converged_flag
end
function calcu_Vi!(Vi::Matrix{T}, VCM_Arr::Vector{Matrix{T}}, prev_varcmp::Vector{T}, partialV::Union{Nothing,PartialV{Float32}}, Di::Diagonal{T,Vector{T}}, EAvec_Di::Matrix{T}, EAvec::Matrix{T}; is_calcu_logdet::Bool=true) where {T}
    ratio = maximum([prev_varcmp[1] / prev_varcmp[2], prev_varcmp[2] / prev_varcmp[1]])
    println("Ratio between vg1 and vg2: ", ratio)
    if ratio > maximum(partialV.vec_ratio)
        logdet_V = calcu_Vi!(Vi::Matrix{T}, VCM_Arr::Vector{Matrix{T}}, prev_varcmp::Vector{T})
    else
        if is_calcu_logdet
            _n_cmp = length(VCM_Arr)
            fill!(Vi, 0)
            Vi[diagind(Vi)] .= prev_varcmp[_n_cmp]
            for i in 1:(_n_cmp-1)
                Vi .+= VCM_Arr[i] .* prev_varcmp[i]
            end
            begin
                cholesky!(Vi)
                logdet_V = logdet(UpperTriangular(Vi)) * 2
            end
        else
            logdet_V = NAN
        end
        ratio_index = argmin(abs.(ratio .- partialV.vec_ratio)) * 2
        if prev_varcmp[1] >= prev_varcmp[2]
            ratio_index -= 1
        end
        j = ratio_index
        n_samples = size(Vi, 1)
        range_inds = n_samples*(j-1)+1:n_samples*j
        vals_inds = CartesianIndices((range_inds,))
        vecs_inds = CartesianIndices((range_inds, 1:n_samples))
        copyto!(EAvec, CartesianIndices((1:n_samples, 1:n_samples)), partialV.eigvecs, vecs_inds)
        begin
            Di[diagind(Di)] .= partialV.eigvals[vals_inds]
            Di[diagind(Di)] .*= sum(prev_varcmp[1:2])
            Di[diagind(Di)] .+= prev_varcmp[3]
            Di[diagind(Di)] .\= 1.0
        end
        mul!(EAvec_Di, Di, EAvec')
        matmul!(Vi, EAvec, EAvec_Di)
    end
    return logdet_V
end
function calcu_Vi!(Vi::Matrix{T}, VCM_Arr::Vector{Matrix{T}}, prev_varcmp::Vector{T}; is_calcu_logdet::Bool=true) where {T}
    _n_cmp = length(VCM_Arr)
    fill!(Vi, 0)
    Vi[diagind(Vi)] .= prev_varcmp[_n_cmp]
    for i in 1:(_n_cmp-1)
        Vi .+= VCM_Arr[i] .* prev_varcmp[i]
    end
    logdet_V = NAN
    if isposdef(Vi)
        begin
            cVi = cholesky!(Vi)
            @runif is_calcu_logdet logdet_V, _ = logabsdet(cVi)
        end
        Vi .= inv(cVi)
    else
        begin
            @runif is_calcu_logdet logdet_V, _ = logabsdet(Vi)
        end
        try
            Vi .= inv(Vi)
        catch e
            return Inf
        end
    end
    return logdet_V
end
function calcu_Vi!(Vi::Matrix{T}, VCM_Arr::Vector{Matrix{T}}, prev_varcmp::Vector{T}, EA::Eigen{T,T,Matrix{T},Vector{T}}, Di::Diagonal{T,Vector{T}}, EAvec_Di::Matrix{T}, EAvect::Matrix{T}, LRA_factors::LowRankApproxUDV{T}; is_calcu_logdet::Bool=true) where {T}
    if is_calcu_logdet
        _n_cmp = length(VCM_Arr)
        begin
            fill!(Vi, 0)
            Vi[diagind(Vi)] .= prev_varcmp[_n_cmp]
        end
        for i in 1:(_n_cmp-1)
            Vi .+= VCM_Arr[i] .* prev_varcmp[i]
        end
        logdet_V, _ = logabsdet(Vi)
    else
        logdet_V = NAN
    end
    Di[diagind(Di)] .= 1.0 ./ (prev_varcmp[1] .* EA.values .+ prev_varcmp[3])
    mul!(EAvec_Di, Di, EAvect)
    matmul!(Vi, EA.vectors, EAvec_Di)
    if prev_varcmp[2] > 0
        lDi = Diagonal(1.0 ./ (prev_varcmp[2] .* LRA_factors.D))
        Ai_U = matmul(Vi, LRA_factors.U)
        V_Ai = matmul(LRA_factors.V, Vi)
        Di_V_Ai_U_i = inv(lDi + matmul(LRA_factors.V, Ai_U))
        Ai_U_DDinv = matmul(Ai_U, Di_V_Ai_U_i)
        Vi .-= matmul(Ai_U_DDinv, V_Ai)
    end
    return logdet_V
end
function calcu_Vi!(Vi::Matrix{T}, VCM_Arr::Vector{Matrix{T}}, prev_varcmp::Vector{T}, EA::Eigen{T,T,Matrix{T},Vector{T}}, Di::Diagonal{T,Vector{T}}, EAvec_Di::Matrix{T}, EAvect::Matrix{T}, LRA_factors::LowRankApproxUDV{T}, Ai_U::Matrix{T}, V_Ai::Matrix{T}, V_Ai_U::Matrix{T}, Ai_U_Di_V_Ai_U_i::Matrix{T}, Ai_U_Di_V_Ai_U_i_V_Ai::Matrix{T}; is_calcu_logdet::Bool=true) where {T}
    if is_calcu_logdet
        _n_cmp = length(VCM_Arr)
        begin
            fill!(Vi, 0)
            Vi[diagind(Vi)] .= prev_varcmp[_n_cmp]
        end
        for i in 1:(_n_cmp-1)
            Vi .+= VCM_Arr[i] .* prev_varcmp[i]
        end
        logdet_V, _ = logabsdet(Vi)
    else
        logdet_V = NAN
    end
    Di[diagind(Di)] .= 1.0 ./ (prev_varcmp[1] .* EA.values .+ prev_varcmp[3])
    mul!(EAvec_Di, Di, EAvect)
    matmul!(Vi, EAvect', EAvec_Di)
    if prev_varcmp[2] > 0
        matmul!(Ai_U, Vi, LRA_factors.U)
        matmul!(V_Ai, LRA_factors.V, Vi)
        matmul!(V_Ai_U, LRA_factors.V, Ai_U)
        V_Ai_U[diagind(V_Ai_U)] .+= 1.0 ./ (prev_varcmp[2] .* LRA_factors.D)
        try
            V_Ai_U .= inv(V_Ai_U)
        catch e
            return Inf
        end
        matmul!(Ai_U_Di_V_Ai_U_i, Ai_U, V_Ai_U)
        matmul!(Ai_U_Di_V_Ai_U_i_V_Ai, Ai_U_Di_V_Ai_U_i, V_Ai)
        Vi .-= Ai_U_Di_V_Ai_U_i_V_Ai
    end
    return logdet_V
end
function calcu_Vi!(Vi::Matrix{T}, VCM_Arr::Vector{Matrix{T}}, prev_varcmp::Vector{T}, EA::Eigen{T,T,Matrix{T},Vector{T}}, cVi::Matrix{T}; is_calcu_logdet::Bool=true) where {T}
    if is_calcu_logdet
        Vi .= VCM_Arr[2]
        n = size(Vi, 1)
        Di = I(n) |> Matrix{Float64}
        matmul!(Vi, VCM_Arr[1], Di, prev_varcmp[1], prev_varcmp[2])
        begin
            cVi .= Vi
            if isposdef!(cVi)
                logdet_V = logdet(UpperTriangular(cVi)) * 2
            else
                logdet_V = logdet(Vi)
            end
        end
    else
        logdet_V = NAN
    end
    Di[diagind(Di)] .= 1.0 ./ (prev_varcmp[1] .* EA.values .+ prev_varcmp[2])
    matmul!(Vi, matmul(EA.vectors, Di), EA.vectors')
    return logdet_V
end
function calcu_Vi!(Vi::Matrix{T}, VCM_Arr::Vector{Matrix{T}}, prev_varcmp::Vector{T}, EA::Eigen{T,T,Matrix{T},Vector{T}}, Di::Diagonal{T,Vector{T}}, EAvec_Di::Matrix{T}, EAvect::Matrix{T}, cVi::Matrix{T}; is_calcu_logdet::Bool=true) where {T}
    if is_calcu_logdet
        Vi .= VCM_Arr[1]
        n = size(Vi, 1)
        begin
            rmul!(Vi, prev_varcmp[1])
            Vi[diagind(Vi)] .+= prev_varcmp[2]
        end
        begin
            cVi .= Vi
            if isposdef!(cVi)
                logdet_V = logdet(UpperTriangular(cVi)) * 2
            else
                logdet_V, _ = logabsdet(Vi)
            end
        end
    else
        logdet_V = NAN
    end
    Di[diagind(Di)] .= 1.0 ./ (prev_varcmp[1] .* EA.values .+ prev_varcmp[2])
    mul!(EAvec_Di, Di, EAvect)
    matmul!(Vi, EA.vectors, EAvec_Di)
    return logdet_V
end
function calcu_P!(Vi::Matrix{T}, Vi_X::Matrix{T}, Xt_Vi_X_i::Matrix{T}, P::Matrix{T}, X::Matrix{T}; is_calcu_logdet::Bool=true) where {T}
    matmul!(Vi_X, Vi, X)
    matmul!(Xt_Vi_X_i, X', Vi_X)
    if is_calcu_logdet
        logdet_Xt_Vi_X, _ = logabsdet(Xt_Vi_X_i)
    else
        logdet_Xt_Vi_X = NAN
    end
    try
        Xt_Vi_X_i .= inv(Xt_Vi_X_i)
    catch e
        return Inf
    end
    matmul!(P, matmul(Vi_X, Xt_Vi_X_i), Vi_X')
    P .-= Vi
    lmul!(-1.0, P)
    return logdet_Xt_Vi_X
end
function calcu_P!(Vi::Matrix{T}, Vi_X::Matrix{T}, Xt_Vi_X_i::Matrix{T}, P::Matrix{T}, X::Matrix{T}, Vi_X_Xt_Vi_X_i::Matrix{T}; is_calcu_logdet::Bool=true) where {T}
    matmul!(Vi_X, Vi, X)
    matmul!(Xt_Vi_X_i, X', Vi_X)
    if is_calcu_logdet
        logdet_Xt_Vi_X, _ = logabsdet(Xt_Vi_X_i)
    else
        logdet_Xt_Vi_X = NAN
    end
    try
        Xt_Vi_X_i .= inv(Xt_Vi_X_i)
    catch e
        return Inf
    end
    matmul!(Vi_X_Xt_Vi_X_i, Vi_X, Xt_Vi_X_i)
    matmul!(P, Vi_X_Xt_Vi_X_i, Vi_X')
    P .-= Vi
    lmul!(-1.0, P)
    return logdet_Xt_Vi_X
end
function calcu_tr_PA!(PA::Matrix{T}, P::Matrix{T}, tr_PA::Vector{T}, VCM_Arr::Vector{Matrix{T}}) where {T}
    _n_cmp = length(VCM_Arr)
    for i in 1:_n_cmp
        PA .= P .* VCM_Arr[i]
        tr_PA[i] = sum(PA)
    end
end
function calcu_tr_PA!(P::Matrix{T}, tr_PA::Vector{T}, VCM_Arr::Vector{Matrix{T}}) where {T}
    _n_cmp = length(VCM_Arr)
    PA = similar(P)
    for i in 1:_n_cmp
        PA .= P .* VCM_Arr[i]
        tr_PA[i] = sum(PA)
    end
end
function em_reml!(PA::Matrix{T}, P::Matrix{T}, Py::Vector{T}, prev_varcmp::Vector{T}, varcmp::Vector{T}, VCM_Arr::Vector{Matrix{T}}, y::Vector{T}) where {T}
    _n_cmp = length(varcmp)
    tr_PA = zeros(T, _n_cmp)
    _n = length(Py)
    calcu_tr_PA!(PA, P, tr_PA, VCM_Arr)
    matmul!(Py, P, y)
    R = zeros(T, _n_cmp)
    @inbounds for i in 1:_n_cmp
        R[i] = dot(matmul(VCM_Arr[i], Py), Py)
        varcmp[i] = prev_varcmp[i] - prev_varcmp[i] * prev_varcmp[i] * (tr_PA[i] - R[i]) / _n
    end
    return R
end
function ai_reml!(PA::Matrix{T}, P::Matrix{T}, Hi::Matrix{T}, Py::Vector{T}, prev_varcmp::Vector{T}, varcmp::Vector{T}, dlogL::Float64, VCM_Arr::Vector{Matrix{T}}, y::Vector{T}; is_calcu_logdet::Bool=true, prev_prev_varcmp::Union{Nothing,Vector{T}}=nothing) where {T}
    _n = length(y)
    _n_cmp = length(varcmp)
    matmul!(Py, P, y)
    APy = zeros(T, _n, _n_cmp)
    APy[:, _n_cmp] .= Py
    @inbounds for i in 1:(_n_cmp-1)
        APy[:, i] .= matmul(VCM_Arr[i], Py)
    end
    begin
        R = zeros(T, _n_cmp)
        P_APy = zeros(T, _n, _n_cmp)
        matmul!(R, APy', Py)
        matmul!(P_APy, P, APy)
        matmul!(Hi, APy', P_APy)
    end
    Hi .*= 0.5
    tr_PA = zeros(T, _n_cmp)
    calcu_tr_PA!(PA, P, tr_PA, VCM_Arr)
    R .= -0.5 * (tr_PA - R)
    delta = zeros(T, _n_cmp)
    try
        Hi .= inv(Hi)
    catch e
        return fill!(delta, NAN), fill!(R, NAN)
    end
    mul!(delta, Hi, R)
    if is_calcu_logdet
        if dlogL > 1.0
            varcmp .= prev_varcmp + 0.316 * delta
        else
            varcmp .= prev_varcmp + delta
        end
    else
        if isnothing(prev_prev_varcmp)
            error("'prev_prev_varcmp' must be provided!")
        end
        if norm(varcmp - prev_prev_varcmp)^2 / norm(varcmp)^2 > 0.01
            varcmp .= prev_varcmp + 0.316 * delta
        else
            varcmp .= prev_varcmp + delta
        end
    end
    return delta, R
end
function constrain_varcmp!(varcmp::Vector{T}, y::Vector{T}) where {T}
    _n_cmp = length(varcmp)
    delta = 0.0
    constr_scale = 1e-6
    num = 0
    constrain = zeros(Int, _n_cmp)
    for i in 1:_n_cmp
        if varcmp[i] < 0
            Var_y = var(y)
            delta += Var_y * constr_scale - varcmp[i]
            varcmp[i] = Var_y * constr_scale
            constrain[i] = 1
            num += 1
        end
    end
    delta /= _n_cmp - num
    for i in 1:_n_cmp
        if constrain[i] < 1 && varcmp[i] > delta
            varcmp[i] -= delta
        end
    end
    return num
end
function cg_inv(M::Matrix{T}) where {T}
    n = size(M, 1)
    Mi = zeros(T, n, n)
    b = I(n) |> Matrix{Float64}
    @inbounds Threads.@threads for i in 1:n
        Mi[:, i] .= cg(M, b[:, i])
    end
    return Mi
end
function cg_inv!(M::Matrix{T}, Mi::Matrix{T}) where {T}
    n = size(M, 1)
    b = I(n) |> Matrix{Float64}
    @inbounds Threads.@threads for i in 1:n
        Mi[:, i] .= cg(M, b[:, i])
    end
    return true
end
function calcu_Vp(varcmp::Vector{T}, Hi::Matrix{T}) where {T}
    _n_cmp = length(varcmp)
    Vp = 0.0
    VarVp = 0.0
    for i in 1:_n_cmp
        Vp += varcmp[i]
        for j in 1:_n_cmp
            VarVp += Hi[i, j]
        end
    end
    return Vp, VarVp
end
function calcu_hsq(i::Int, Vp::Float64, VarVp::Float64, varcmp::Vector{T}, Hi::Matrix{T}) where {T}
    _n_cmp = length(varcmp)
    V1 = varcmp[i]
    VarV1 = Hi[i, i]
    Cov12 = 0.0
    for j in 1:_n_cmp
        Cov12 += Hi[i, j]
    end
    hsq = V1 / Vp
    var_hsq = (V1 / Vp) * (V1 / Vp) * (VarV1 / (V1 * V1) + VarVp / (Vp * Vp) - (2 * Cov12) / (V1 * Vp))
    return hsq, var_hsq
end
function getOpenMendelVC(G::Matrix{T}, Y::Vector{T}; EA::Union{Nothing,Eigen{T,T,Matrix{T},Vector{T}}}=nothing, X::Union{Nothing,Matrix{T}}=nothing, method::String=["MLE", "REML"][2], algo::Symbol=[:MM, :FS][1]) where {T}
    n = length(Y)
    if isnothing(X)
        X = ones(T, n, 1)
    end
    vcdata = VarianceComponentVariate(Y, X, (G, spdiagm(ones(T, n))))
    vcmodel = VarianceComponentModel(vcdata)
    if !isnothing(EA)
        if method == "MLE"
            logl, vcmodel, Σse, Σcov, Bse, Bcov = fit_mle!(vcmodel, vcdata, EA; algo=algo)
        else
            logl, vcmodel, Σse, Σcov, Bse, Bcov = fit_reml!(vcmodel, vcdata, EA; algo=algo)
        end
    else
        if method == "MLE"
            logl, vcmodel, Σse, Σcov, Bse, Bcov = fit_mle!(vcmodel, vcdata; algo=algo)
        else
            logl, vcmodel, Σse, Σcov, Bse, Bcov = fit_reml!(vcmodel, vcdata; algo=algo)
        end
    end
    h, hse = VarianceComponentModels.heritability(vcmodel.Σ, Σcov)
    abc_uni = Dict(
        :ΣG => vec(vcmodel.Σ[1]),
        :ΣG_se => vec(Σse[1]),
        :Σe => vcmodel.Σ[2][1],
        :Σe_se => Σse[2][1],
        :Σp => nothing,
        :Σp_se => nothing,
        :h2 => h,
        :h2_se => hse,
        :logL => logl,
        :logL0 => nothing,
        :n => n,
        :Fix_eff => vec(vcmodel.B),
        :Fix_eff_se => vec(Bse),
        :u => nothing
    )
    return abc_uni
end