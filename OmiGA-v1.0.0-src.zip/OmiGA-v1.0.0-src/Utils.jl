```
 * OmiGA: a toolkit for Omics Genetic Analysis
 *
 * Copyright © 2024, Jinyan Teng
 *
 * This file is distributed under the GNU General Public
 * License, Version 3. Please see the file LICENSE for more
 * details.
 *
 * All the files in this project are allowed to be copied, 
 * modified, and distributed for educational, research and 
 * non-profit purposes, without charge and without a written 
 * agreement, provided that this copyright notice are included
 * in all copies. If you intend to use this project for 
 * commercial purposes, kindly contact the author for 
 * authorization prior to use.
```
function compare_chromosomes(a, b)
    get_num = s -> begin
        num_match = match(r"\d+", s)
        if num_match !== nothing
            parsed = tryparse(Int, num_match.match)
            return parsed === nothing ? typemax(Int) : parsed
        else
            return typemax(Int)
        end
    end
    get_num(a) < get_num(b)
end
function count_max_consecutive_true(vec)
    count = 0
    max_count = 0
    for v in vec
        if v
            count = count + 1
            max_count = max(max_count, count)
        else
            count = 0
        end
    end
    return max_count
end
function rematch_sample_id!(iid::Vector{T}, id_map::DataFrame) where {T}
    matchidx = repeat([nothing], length(iid)) |> Vector{Union{Nothing,Int64}}
    for i in axes(id_map, 2)
        _matchidx = vmatch(id_map[:, i], iid)
        _matchedidx = .!isnothing.(_matchidx)
        erroridx = matchidx[.!isnothing.(matchidx).&_matchedidx] .!= _matchidx[.!isnothing.(matchidx).&_matchedidx]
        if any(erroridx)
            error(string(iid[erroridx], " appear multiple times in the id map file!"))
        else
            matchidx[.!isnothing.(_matchidx)] .= _matchidx[.!isnothing.(_matchidx)]
        end
    end
    if any(isnothing.(matchidx))
        error("Cannot found ", iid[isnothing.(matchidx)], " in the id map file!")
    end
    iid .= id_map[matchidx, 1]
    return iid
end
function first_nonnan_argmin(arr::AbstractArray{T}) where {T}
    min_val = Inf
    min_idx = 0
    for (idx, val) in enumerate(arr)
        if !isnan(val) && val < min_val
            min_val = val
            min_idx = idx
        end
    end
    if min_idx == 0
        return -1
    end
    return min_idx
end
function first_nonnan_argmax(arr::AbstractArray{T}) where {T}
    max_val = -Inf
    max_idx = 0
    for (idx, val) in enumerate(arr)
        if !isnan(val) && val > max_val
            max_val = val
            max_idx = idx
        end
    end
    if max_idx == 0
        return -1
    end
    return max_idx
end
function extract_max_by_group(groups, values)
    group_dict = Dict()
    for (group, value) in zip(groups, values)
        if !haskey(group_dict, group) || value > group_dict[group]
            group_dict[group] = value
        end
    end
    max_values = [group_dict[group] for group in groups]
    unique_max_values = unique(max_values)
    return unique_max_values
end
function count_consecutive(arr::Vector)
    counts = []
    first_indices = [1]
    count = 1
    for i in 2:length(arr)
        if arr[i] == arr[i-1]
            count += 1
        else
            push!(counts, count)
            count = 1
            push!(first_indices, i)
        end
    end
    push!(counts, count)
    return counts, first_indices
end
function is_collinear(v1, v2, cor_cutoff)
    abscor = abs(cor(v1, v2))
    return abscor > cor_cutoff
end
function remove_collinear_columns(matrix; cor_cutoff=0.9, return_index=false)
    num_cols = size(matrix, 2)
    cols_to_keep = [1]
    for i in 2:num_cols
        is_new_col_collinear = any(j -> is_collinear(matrix[:, i], matrix[:, j], cor_cutoff), cols_to_keep)
        if !is_new_col_collinear
            push!(cols_to_keep, i)
        end
    end
    if return_index
        return cols_to_keep
    else
        return matrix[:, cols_to_keep]
    end
end
function create_design_matrix(categories::Vector)
    unique_categories = unique(categories)
    design_matrix = zeros(Int, length(categories), length(unique_categories))
    for (i, category) in enumerate(categories)
        category_index = findfirst(x -> x == category, unique_categories)
        design_matrix[i, category_index] = 1
    end
    design_matrix = design_matrix[:, 1:(end-1)]
    return design_matrix
end
function create_design_matrix(categories_mat::Matrix)
    nc = size(categories_mat, 2)
    c_design_matrix = nothing
    for i in 1:nc
        categories = categories_mat[:, i]
        design_matrix = create_design_matrix(categories)
        if i == 1
            c_design_matrix = design_matrix
        else
            c_design_matrix = [c_design_matrix design_matrix]
        end
    end
    return c_design_matrix
end
function ranking(x::AbstractVector; ties_method="average")
    sorted_indices = sortperm(x)
    ranks = similar(x, Float64)
    current_rank = 1.0
    i = 1
    while i <= length(x)
        start = i
        while i < length(x) && x[sorted_indices[i]] == x[sorted_indices[i+1]]
            i += 1
        end
        if ties_method == "average"
            rank_value = (start + i) / 2.0
        elseif ties_method == "min"
            rank_value = start
        elseif ties_method == "max"
            rank_value = i
        elseif ties_method == "first"
            rank_value = start
        elseif ties_method == "last"
            rank_value = i
        elseif ties_method == "random"
            rank_value = start + rand() * (i - start)
        else
            error("Unsupported ties.method: $ties_method")
        end
        for j in start:i
            ranks[sorted_indices[j]] = rank_value
        end
        current_rank += (i - start + 1)
        i += 1
    end
    return ranks
end
function inverse_normal_transform(x::AbstractVector)
    ranks = ranking(x)
    norm_cdf = (ranks) ./ (length(x) + 1)
    quantile.(Normal(), norm_cdf)
end
function inverse_normal_transform(x::AbstractMatrix)
    x0 = similar(x)
    for i in 1:size(x, 2)
        x0[:, i] .= inverse_normal_transform(x[:, i])
    end
    return x0
end
function inverse_normal_transform!(x::AbstractMatrix)
    for i in 1:size(x, 2)
        x[:, i] .= inverse_normal_transform(x[:, i])
    end
end
function At_mul_B(A, B)
    return permutedims(A) * B
end
function At_mul_B!(C, A, B)
    mul!(C, permutedims(A), B)
end
macro runif(cond, expr)
    quote
        if $(esc(cond))
            $(esc(expr))
        end
    end
end
function df_to_float32!(df)
    cols_float64 = [eltype(df[:, x]) == Float64 for x in range(1, ncol(df))]
    df[!, cols_float64] = Float32.(df[!, cols_float64])
end
function df_to_32bit!(df)
    cols_float64 = [eltype(df[:, x]) == Float64 for x in range(1, ncol(df))]
    cols_int64 = [eltype(df[:, x]) == Int64 for x in range(1, ncol(df))]
    df[!, cols_float64] = Float32.(df[!, cols_float64])
    df[!, cols_int64] = Int32.(df[!, cols_int64])
end
function println_to_file(message::String, filename::String)
    open(filename, "a") do file
        println(message)
        println(file, message)
        flush(file)
    end
end
function print_to_file(message::String, filename::String)
    open(filename, "a") do file
        print(message)
        print(file, message)
        flush(file)
    end
end
function format_milliseconds(milliseconds::Millisecond)
    total_seconds = milliseconds.value ÷ 1000
    hours = total_seconds ÷ 3600
    minutes = (total_seconds ÷ 60) % 60
    seconds = total_seconds % 60
    milliseconds = milliseconds.value % 1000
    return string(hours, ":", minutes, ":", seconds, ":", milliseconds)
end
function vmatch(S, V, rm_nothing=false)
    idx = [findfirst(isequal(x), S) for x in V]
    idx = Vector{Union{Nothing,Int}}(idx)
    if rm_nothing
        idx = idx[.~isnothing.(idx)]
    end
    return idx
end
function vin(S, V)
    idx = [findfirst(isequal(x), S) for x in V]
    idx = Vector{Union{Nothing,Int}}(idx)
    inn = .~isnothing.(idx)
    return inn
end
function lower_tri(n::Int)
    n_ = Int(n * (n + 1) / 2 - n)
    _idxs = repeat([0], n_)
    _idx = 2:n
    sum_idxs = length(_idx)
    _idxs[1:sum_idxs] = _idx
    for i in 1:(n-1)
        _idx = _idx[2:end] .+ n
        sum_idxs += length(_idx)
        _idxs[sum_idxs-length(_idx)+1:sum_idxs] = _idx
    end
    return _idxs
end
function upper_tri(n::Int)
    n_ = Int(n * (n + 1) / 2 - n)
    _idxs = repeat([0], n_)
    for i in 2:n
        _idx = Int((i - 1) * n + 1):Int((i - 1) * n + (i - 1))
        _idxs[Int((i - 1) * (i - 2) / 2 + 1):Int((i) * (i - 1) / 2)] .= _idx
    end
    return _idxs
end
function writeGRMBin(REL, REL_id, prefix::String, type::Type=Float32; fam_id=nothing)
    function sum_i(i)
        return sum(1:i)
    end
    n = size(REL, 1)
    i = sum_i.(1:n)
    out_REL = Array{type}(repeat([NaN], maximum(i)))
    out_REL[i] = diag(REL)
    idx_up = upper_tri(n)
    out_REL[isnan.(out_REL)] = REL[idx_up]
    open(string(prefix, ".grm.bin"), "w") do f
        write(f, out_REL)
    end
    id = DataFrame(hcat(ifelse(isnothing(fam_id), REL_id, fam_id), REL_id), :auto)
    CSV.write(string(prefix, ".grm.id"), id, delim=" ", header=false)
    return true
end
function readGRMBin(prefix::String; type::Type=Float32, return_type::Type=Float64)
    function sum_i(i)
        return sum(1:i)
    end
    BinFileName = string(prefix, ".grm.bin")
    IDFileName = string(prefix, ".grm.id")
    if !isfile(BinFileName)
        error(string("No found '", BinFileName, "'!"))
    end
    if !isfile(IDFileName)
        error(string("No found '", IDFileName, "'!"))
    end
    id = CSV.read(IDFileName, DataFrame, header=false, types=Dict(:Column1 => String, :Column2 => String))
    n = size(id, 1)
    i = sum_i.(1:n)
    i_max = maximum(i)
    grm = zeros(type, i_max)
    open(BinFileName, "r") do f
        grm = Mmap.mmap(f, Vector{type}, i_max, position(f))
    end
    out_REL = Array{return_type}(undef, (n, n))
    out_REL[1:n+1:n*n] = grm[i]
    seq_grm = 1:length(grm)
    tmp = repeat([-1], length(grm))
    tmp[i] .= i
    off = seq_grm[seq_grm.!=tmp]
    out_REL[upper_tri(size(out_REL, 1))] = grm[off]
    out_REL = out_REL'
    out_REL[upper_tri(size(out_REL, 1))] = grm[off]
    return Array(out_REL), id.Column2, id.Column1
end
function readPlinkBed(prefix::String; type::Type=Int8, model=ADDITIVE_MODEL, center::Bool=false, scale::Bool=false, impute::Bool=false, byrow=true)
    bed = SNP_matrix(string(prefix, ".bed"))
    if !byrow
        bed = bed'
    end
    bim = CSV.read(string(prefix, ".bim"), DataFrame, header=false, buffer_in_memory=true, types=Dict(1 => String, 2 => String, 3 => Int, 4 => Int, 5 => String, 6 => String))
    rename!(bim, ["chromosome", "variant", "cM", "position", "a1", "a2"])
    fam = CSV.read(string(prefix, ".fam"), DataFrame, header=false, buffer_in_memory=true, types=Dict(1 => String, 2 => String))
    FID = string.(fam[:, 1])::Vector{String}
    IID = string.(fam[:, 2])::Vector{String}
    if type == UInt8
        return bed, IID, FID, bim
    else
        geno = convert(Matrix{type}, bed)::Matrix{type}
        return geno, IID, FID, bim
    end
end
function readPlinkBed(prefix::String, dominance::Bool, byrow::Bool)
    bed = SnpArray(string(prefix, ".bed"))
    if !byrow
        bed = bed' |> Matrix
        replace!(bed, 0x00 => 0x02, 0x02 => 0x01, 0x03 => 0x00)
    else
        bed = replace(bed, 0x00 => 0x02, 0x02 => 0x01, 0x03 => 0x00)
    end
    if dominance
        geno_DOM = copy(bed)
        replace!(geno_DOM, 0x02 => 0x00)
    end
    bim = CSV.read(string(prefix, ".bim"), DataFrame, header=false, buffer_in_memory=true, types=Dict(1 => String, 2 => String, 3 => Int, 4 => Int, 5 => String, 6 => String))
    rename!(bim, ["chromosome", "variant", "cM", "position", "a1", "a2"])
    fam = CSV.read(string(prefix, ".fam"), DataFrame, header=false, buffer_in_memory=true, types=Dict(1 => String, 2 => String))
    FID = string.(fam[:, 1])::Vector{String}
    IID = string.(fam[:, 2])::Vector{String}
    if dominance
        return bed, IID, FID, bim, geno_DOM
    else
        return bed, IID, FID, bim
    end
end
function get_allele_af(genotype::AbstractArray; byrow::Bool=true)
    dims = ifelse(byrow, 1, 2)
    return vec(sum(genotype, dims=dims)) / (2 * size(genotype, dims))
end
function get_allele_maf(genotype::AbstractArray; byrow::Bool=true)
    maf = get_allele_af(genotype, byrow=byrow)
    maf[maf.>0.5] .= 1 .- maf[maf.>0.5]
    return maf
end
function get_allele_het_rate(genotype::AbstractArray; byrow::Bool=true)
    dims = ifelse(byrow, 1, 2)
    return vec(sum(genotype .== 1, dims=dims)) / size(genotype, dims)
end
function get_allele_het_rate(genotype::SNP_matrix)
    return het(genotype)
end
function get_allele_af(genotype::SNP_matrix)
    return af(genotype)
end
function get_allele_maf(genotype::SNP_matrix)
    return maf(genotype)
end
