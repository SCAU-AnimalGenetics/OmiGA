```
 * OmiGA: a toolkit for Omics Genetic Analysis
 *
 * Copyright © 2024, Jinyan Teng
 *
 * This file is distributed under the GNU General Public
 * License, Version 3. Please see the file LICENSE for more
 * details.
 *
 * All the files in this project are allowed to be copied, 
 * modified, and distributed for educational, research and 
 * non-profit purposes, without charge and without a written 
 * agreement, provided that this copyright notice are included
 * in all copies. If you intend to use this project for 
 * commercial purposes, kindly contact the author for 
 * authorization prior to use.
```
function runOmiGA_her(_struct_PHENO, _struct_GENO, _struct_KIN, _struct_COVAR; _struct_DOM::Union{Nothing,Dominance}=nothing)
    phenotype = _struct_PHENO.phenotype
    pheno_annotation = _struct_PHENO.annotation
    X_MME = copy(_struct_COVAR.X_MME)
    if !isnothing(_args_geno_file_prefix)
        genotype = _struct_GENO.genotype
        snp_annotation = _struct_GENO.annotation
        if !isnothing(_struct_DOM)
            domGenotype = _struct_DOM.genotype
        end
        @runif USE_Float32 snp_annotation.af .= Float64.(snp_annotation.af)
    else
        genotype = nothing
        domGenotype = nothing
        snp_annotation = nothing
    end
    convergence_parameters = FloatT(_args_dpars)
    convergence_dlogL = FloatT(NAN)
    if isnothing(genotype)
        n_glo_snps = 0
    else
        n_glo_snps = _struct_GENO.n_snps
    end
    _n, _X_c = size(X_MME)
    _args_glo_h2 = false
    _args_trans_h2 = false
    _args_cis_h2 = false
    glo_h2_model = _args_h2_model
    trans_h2_model = _args_h2_model
    cis_h2_model = _args_h2_model
    if _args_h2_model in ["Ag", "Dg", "Ag+Dg"]
        _args_glo_h2 = true
    elseif _args_h2_model in ["At", "Dt", "Ag+Dt"]
        _args_trans_h2 = true
    elseif _args_h2_model in ["Ac", "Dc", "Ag+Ac", "Ag+Dc", "At+Ac"]
        _args_cis_h2 = true
    else
        error("Unsupported heritability model!")
    end
    if isnothing(_args_h2_algo)
        h2_algo = "em_aireml"
    else
        h2_algo = _args_h2_algo
    end
    _args_glo_h2_algo = h2_algo
    _args_trans_h2_algo = h2_algo
    _args_cis_h2_algo = h2_algo
    glo_h2_algo = _args_glo_h2_algo
    @runif _args_glo_h2 if glo_h2_model in ["Ag+Dg"]
        if _args_glo_h2_algo != "em_aireml"
            h2_algo = glo_h2_algo = "em_aireml"
            @info string("--h2-algo was set to 'em_aireml' for ", glo_h2_model)
        end
    end
    trans_h2_algo = _args_trans_h2_algo
    @runif _args_trans_h2 if trans_h2_model in ["Ag+Dt"]
        if _args_trans_h2_algo != "em_aireml"
            h2_algo = trans_h2_algo = "em_aireml"
            @info string("--h2-algo was set to 'em_aireml' for ", trans_h2_model)
        end
    end
    cis_h2_algo = _args_cis_h2_algo
    @runif _args_cis_h2 if cis_h2_model in ["Ag+Ac", "Ag+Dc", "At+Ac"]
        if _args_cis_h2_algo != "em_aireml"
            h2_algo = cis_h2_algo = "em_aireml"
            @info string("--h2-algo was set to 'em_aireml' for ", cis_h2_model)
        end
    end
    In = diagm(ones(FloatT, _n))
    pre_calcu_xQ_glo = glo_h2_algo in ["idul", "idul_aireml"]
    pre_calcu_xQ_trans = trans_h2_algo in ["idul", "idul_aireml"]
    pre_calcu_eigen = true
    if pre_calcu_xQ_glo
        if glo_h2_model == "Ag"
            glo_xQ = _struct_KIN.EA.vectors' * X_MME
        elseif glo_h2_model == "Dg"
            glo_xQ = _struct_KIN.domEA.vectors' * X_MME
        end
    end
    if _args_glo_h2
        if glo_h2_model == "Ag"
            glo_KSs = [_struct_KIN.GRM, In]
            glo_EA = ifelse(pre_calcu_eigen, _struct_KIN.EA, nothing)
        elseif glo_h2_model == "Dg"
            glo_KSs = [_struct_KIN.domGRM, In]
            glo_EA = ifelse(pre_calcu_eigen, _struct_KIN.domEA, nothing)
        elseif glo_h2_model == "Ag+Dg"
            glo_KSs = [_struct_KIN.GRM, _struct_KIN.domGRM, In]
            glo_EA = nothing
        end
        glo_n_cmp = length(glo_KSs)
    end
    _args_PreV = _args_glo_h2 & (glo_h2_model == "Ag+Dg")
    if _args_PreV
        path_partialv = _args_path_partialv
        if !isnothing(path_partialv)
            _struct_PartialV = load(path_partialv)["data"]
        else
            println_to_file("Performing PAED ...", log_file)
            G1 = _struct_KIN.GRM |> Matrix{Float32}
            G2 = _struct_KIN.domGRM |> Matrix{Float32}
            ratio_step = Float32(_args_paed_step)
            ratio_max = Float32(_args_paed_max)
            vec_ratio = range(1, ratio_max, step=ratio_step) |> Vector{Float32}
            eig_rows = length(vec_ratio) * 2 * _n
            cGRM_eigvals = zeros(Float32, eig_rows)
            cGRM_eigvecs = zeros(Float32, eig_rows, _n)
            cGRM = similar(G1, Float32)
            for i in eachindex(vec_ratio)
                v1_v2_ratio = vec_ratio[i]
                v1 = v1_v2_ratio / (1 + v1_v2_ratio)
                v2 = 1 - v1
                cGRM .= v1 * G1 + v2 * G2
                cval, cvec = eigen!(cGRM)
                j = i * 2 - 1
                range_inds = _n*(j-1)+1:_n*j
                vals_inds = CartesianIndices((range_inds,))
                vecs_inds = CartesianIndices((range_inds, 1:_n))
                copyto!(cGRM_eigvals, vals_inds, cval, CartesianIndices(cval))
                copyto!(cGRM_eigvecs, vecs_inds, cvec, CartesianIndices(cvec))
                cGRM .= v2 * G1 + v1 * G2
                cval, cvec = eigen!(cGRM)
                j = i * 2
                range_inds = _n*(j-1)+1:_n*j
                vals_inds = CartesianIndices((range_inds,))
                vecs_inds = CartesianIndices((range_inds, 1:_n))
                copyto!(cGRM_eigvals, vals_inds, cval, CartesianIndices(cval))
                copyto!(cGRM_eigvecs, vecs_inds, cvec, CartesianIndices(cvec))
            end
            _struct_PartialV = PartialV{Float32}(vec_ratio, cGRM_eigvals, cGRM_eigvecs)
            save(joinpath(_args_output_dir, string(_args_out_prefix, ".paed.jld2")), "data", _struct_PartialV)
            println_to_file("PAED done.", log_file)
            cGRM_eigvals = nothing
            cGRM_eigvecs = nothing
            G1 = nothing
            G2 = nothing
            cGRM = nothing
            GC.gc()
        end
    end
    if _args_trans_h2
        if trans_h2_model == "At"
            trans_KSs = [zeros(FloatT, _n, _n), In]
        elseif trans_h2_model == "Dt"
            trans_KSs = [zeros(FloatT, _n, _n), In]
        elseif trans_h2_model == "Ag+Dt"
            trans_KSs = [_struct_KIN.GRM, zeros(FloatT, _n, _n), In]
        end
        trans_n_cmp = length(trans_KSs)
    end
    if _args_cis_h2
        if cis_h2_model == "Ac"
            cis_KSs = [zeros(FloatT, _n, _n), In]
        elseif cis_h2_model == "Dc"
            cis_KSs = [zeros(FloatT, _n, _n), In]
        elseif cis_h2_model == "Ag+Ac"
            cis_KSs = [_struct_KIN.GRM, zeros(FloatT, _n, _n), In]
        elseif cis_h2_model == "Ag+Dc"
            cis_KSs = [_struct_KIN.GRM, zeros(FloatT, _n, _n), In]
        elseif cis_h2_model == "At+Ac"
            cis_KSs = [zeros(FloatT, _n, _n), zeros(FloatT, _n, _n), In]
        end
        cis_n_cmp = length(cis_KSs)
        if _args_use_low_rank_approx
            if _args_approx_rank isa AbstractFloat
                approx_rank = Int(round(_n * _args_approx_rank))
            elseif _args_approx_rank isa Integer
                approx_rank = _args_approx_rank
            end
            if isnothing(_args_max_approx_rank)
                max_approx_rank = 1.0
            else
                max_approx_rank = _args_max_approx_rank
            end
        end
    end
    if _args_glo_h2
        glo_Σ_i = fill(NAN, glo_n_cmp)
        glo_h2 = fill(NAN, glo_n_cmp - 1)
        glo_h2_se = fill(NAN, glo_n_cmp - 1)
        glo_fix_eff = zeros(FloatT, _X_c)
    end
    if _args_cis_h2
        cis_Σ_i = fill(NAN, cis_n_cmp)
        cis_h2 = fill(NAN, cis_n_cmp - 1)
        cis_h2_se = fill(NAN, cis_n_cmp - 1)
    end
    if _args_trans_h2
        trans_Σ_i = fill(NAN, trans_n_cmp)
        trans_h2 = fill(NAN, trans_n_cmp - 1)
        trans_h2_se = fill(NAN, trans_n_cmp - 1)
    end
    n_trans_snps = 0
    n_cis_snps = 0
    _args_save_memory = h2_algo in ["em_aireml", "idul_aireml"]
    if _args_save_memory
        _Vi_X = zeros(FloatT, _n, _X_c)
        _Xt_Vi_X_i = zeros(FloatT, _X_c, _X_c)
        _Py = zeros(FloatT, _n)
        _P = zeros(FloatT, _n, _n)
        _PA = zeros(FloatT, _n, _n)
        _Vi = zeros(FloatT, _n, _n)
        _cVi = zeros(FloatT, _n, _n)
        _Di = Diagonal(zeros(FloatT, _n, _n))
        _EAvec_Di = zeros(FloatT, _n, _n)
        _EAvec = zeros(FloatT, _n, _n)
        if _args_glo_h2
            glo_Hi = zeros(FloatT, glo_n_cmp, glo_n_cmp)
        end
        if _args_trans_h2
            trans_Hi = zeros(FloatT, trans_n_cmp, trans_n_cmp)
        end
        if _args_cis_h2
            cis_Hi = zeros(FloatT, cis_n_cmp, cis_n_cmp)
        end
    end
    n_grm = length(split(_args_h2_model, "+"))
    chroms = string.(unique(pheno_annotation.chrom))
    for chrom in chroms
        @runif _args_cis_h2 | _args_trans_h2 snp_index_chrom = snp_annotation.chromosome .== chrom
        _gene_annot = pheno_annotation[pheno_annotation.chrom.==chrom, :]
        _n_genes = length(_gene_annot.pheno_id)
        if n_grm == 2
            _df_hers = DataFrame(pheno_id=_gene_annot.pheno_id,
                chrom=chrom,
                glo_snps=n_glo_snps,
                trans_snps=0,
                cis_snps=0,
                algo=h2_algo,
                model=_args_h2_model,
                vg1=NAN,
                vg2=NAN,
                ve=NAN,
                h2_g1=NAN,
                h2se_g1=NAN,
                h2_g2=NAN,
                h2se_g2=NAN,
            )
        else
            _df_hers = DataFrame(pheno_id=_gene_annot.pheno_id,
                chrom=chrom,
                glo_snps=n_glo_snps,
                trans_snps=0,
                cis_snps=0,
                algo=h2_algo,
                model=_args_h2_model,
                vg1=NAN,
                ve=NAN,
                h2_g1=NAN,
                h2se_g1=NAN,
            )
        end
        if _args_use_low_rank_approx & (cis_h2_algo == "em_aireml") & (cis_h2_model in ["Ag+Ac", "Ag+Dc", "At+Ac"])
            _df_hers.cis_rank .= 0
        end
        if h2_algo in ["em_aireml", "idul_aireml"]
            converged_flag = false
            _df_hers.converged .= converged_flag
        end
        _df_covar_B = hcat(DataFrame(pheno_id=_gene_annot.pheno_id, chrom=chrom), DataFrame(Dict(Symbol(lpad(i, 5, '0')) => repeat([NAN], _n_genes) for i in 0:(_X_c-1))))
        rename!(_df_covar_B, ["pheno_id", "chrom", string.("B", 0:(_X_c-1))...])
        if _args_cis_h2
            if !is_pre_adj_genotype
                _2p = 2 * snp_annotation.af[snp_index_chrom] |> Vector{FloatT}
                if cis_h2_model in ["Ac", "Ag+Ac", "At+Ac"]
                    chrom_genotype = similar(genotype[:, snp_index_chrom], FloatT)
                    chrom_genotype .= genotype[:, snp_index_chrom] .- _2p'
                end
                if cis_h2_model in ["Dc", "Ag+Dc"]
                    _2pq = _2p .* (1 .- snp_annotation.af[snp_index_chrom]) |> Vector{FloatT}
                    chrom_domGenotype = similar(domGenotype[:, snp_index_chrom], FloatT)
                    chrom_domGenotype .= domGenotype[:, snp_index_chrom] .- _2pq'
                end
            else
                error("No support pre-adjusted genotype data!")
            end
            _chrom_snp_annot = snp_annotation[snp_index_chrom, :]
            _chrom_snp_annot.reindex = 1:size(_chrom_snp_annot, 1)
        end
        if _args_trans_h2 | (cis_h2_model == "At+Ac")
            begin
                _trans_annot = snp_annotation[.!snp_index_chrom, :]
                n_trans_snps = nrow(_trans_annot)
                trans_afs = snp_annotation.af[_trans_annot.index]
            end
            if cis_h2_model in ["At+Ac"]
                cis_KSs[1] .= getG_fast(genotype[:, _trans_annot.index]; alpha=_args_grm_alpha, afs=trans_afs, return_eltype=FloatT)
            end
            if trans_h2_model in ["At"]
                trans_KSs[1] .= getG_fast(genotype[:, _trans_annot.index]; alpha=_args_grm_alpha, afs=trans_afs, return_eltype=FloatT)
                trans_EA = ifelse(pre_calcu_eigen, eigen(trans_KSs[1]), nothing)
                if pre_calcu_xQ_trans
                    trans_xQ = matmul(trans_EA.vectors', X_MME)
                end
            end
            if trans_h2_model in ["Dt", "Ag+Dt"]
                trans_KSs[trans_n_cmp-1] .= getG_dominance(domGenotype[:, _trans_annot.index], code_type="dominance", afs=trans_afs, byrow=true)
                if trans_h2_model in ["Dt"]
                    trans_EA = ifelse(pre_calcu_eigen, eigen(trans_KSs[trans_n_cmp-1]), nothing)
                    if pre_calcu_xQ_trans
                        trans_xQ = matmul(trans_EA.vectors', X_MME)
                    end
                end
            end
        end
        GC.gc()
        time_start = now()
        println_to_file(string("Chromosome: ", chrom, ", start at: ", time_start), log_file)
        for i in 1:_n_genes
            gene = _gene_annot.pheno_id[i]
            println_to_file(string("GENE: ", i, "/", _n_genes), log_file)
            exppheno = phenotype[:, findfirst(pheno_annotation.pheno_id .== gene)]
            if _args_glo_h2
                if glo_h2_model in ["Ag", "Dg"]
                    if glo_h2_algo == "minmax"
                        glo_vc = getOpenMendelVC(glo_KSs[1], exppheno, EA=glo_EA, X=X_MME, algo=:MM)
                    elseif glo_h2_algo == "em_aireml"
                        glo_vc = reml(glo_KSs, exppheno, X_MME, _Vi_X, _Xt_Vi_X_i, glo_Hi, _Py, _P, _PA, _Vi, _cVi, _Di, _EAvec_Di, _EAvec, EA=glo_EA, convergence_parameters=convergence_parameters, convergence_dlogL=convergence_dlogL)
                    elseif glo_h2_algo == "idul_aireml"
                        prior_glo_vc = get_IDUL_VarianceComponent(glo_EA, exppheno, X_MME, xQ=glo_xQ, max_iter=5, thre=FloatT(1e-4))
                        glo_vc = reml(glo_KSs, exppheno, X_MME, _Vi_X, _Xt_Vi_X_i, glo_Hi, _Py, _P, _PA, _Vi, _cVi, _Di, _EAvec_Di, _EAvec, EA=glo_EA, varcmp=[prior_glo_vc[:ΣG][1], prior_glo_vc[:Σe]], em_update=true, convergence_parameters=convergence_parameters, convergence_dlogL=convergence_dlogL)
                    elseif glo_h2_algo == "idul"
                        glo_vc = get_IDUL_VarianceComponent(glo_EA, exppheno, X_MME, xQ=glo_xQ)
                    end
                    glo_Σ_i .= [glo_vc[:ΣG][1], glo_vc[:Σe]]
                elseif glo_h2_model in ["Ag+Dg"]
                    if glo_h2_algo == "em_aireml"
                        glo_vc = reml(glo_KSs, exppheno, X_MME, _Vi_X, _Xt_Vi_X_i, glo_Hi, _Py, _P, _PA, _Vi, _cVi, _Di, _EAvec_Di, _EAvec, partialV=_struct_PartialV, convergence_parameters=convergence_parameters, convergence_dlogL=convergence_dlogL)
                    end
                    glo_Σ_i .= [glo_vc[:ΣG][1], glo_vc[:ΣG][2], glo_vc[:Σe]]
                end
                glo_h2 .= glo_vc[:h2]
                glo_h2_se .= glo_vc[:h2_se]
                glo_fix_eff .= glo_vc[:Fix_eff]
                _df_covar_B[i, :] = [gene chrom glo_fix_eff']
                _df_hers.glo_snps[i] = n_glo_snps
                _df_hers.vg1[i] = glo_Σ_i[1]
                _df_hers.ve[i] = glo_Σ_i[glo_n_cmp]
                _df_hers.h2_g1[i] = glo_h2[1]
                _df_hers.h2se_g1[i] = glo_h2_se[1]
                if glo_n_cmp == 3
                    _df_hers.vg2[i] = glo_Σ_i[2]
                    _df_hers.h2_g2[i] = glo_h2[2]
                    _df_hers.h2se_g2[i] = glo_h2_se[2]
                end
                if h2_algo in ["em_aireml", "idul_aireml"]
                    _df_hers.converged[i] = glo_vc[:converged]
                end
            end
            if _args_cis_h2
                cissnps_annot, n_cis_snps = get_cis_snp_info(_gene_annot, _chrom_snp_annot, gene, _args_cis_window)
                fill!(cis_h2, NAN)
                fill!(cis_h2_se, NAN)
                fill!(cis_Σ_i, NAN)
                approx_ranki = 0
                if n_cis_snps > 0
                    if cis_h2_model in ["Ac", "Ag+Ac", "At+Ac"]
                        cis_KSs[cis_n_cmp-1] .= getG_fast(chrom_genotype[:, cissnps_annot.reindex]; alpha=_args_grm_alpha, afs=cissnps_annot.af, return_eltype=FloatT)
                    end
                    if cis_h2_model in ["Dc", "Ag+Dc"]
                        cis_KSs[cis_n_cmp-1] .= getG_dominance(chrom_domGenotype[:, cissnps_annot.reindex], code_type="dominance", adjusted=true, afs=cissnps_annot.af, byrow=true)
                    end
                    if cis_h2_model in ["Ac", "Dc"]
                        cis_EA = eigen(cis_KSs[1])
                        if cis_h2_algo == "minmax"
                            cis_vc = getOpenMendelVC(cis_KSs[1], exppheno, EA=cis_EA, X=X_MME, algo=:MM)
                        elseif cis_h2_algo == "em_aireml"
                            cis_vc = reml(cis_KSs, exppheno, X_MME, _Vi_X, _Xt_Vi_X_i, cis_Hi, _Py, _P, _PA, _Vi, _cVi, _Di, _EAvec_Di, _EAvec, EA=cis_EA, convergence_parameters=convergence_parameters, convergence_dlogL=convergence_dlogL)
                        elseif cis_h2_algo == "idul_aireml"
                            prior_cis_vc = get_IDUL_VarianceComponent(cis_EA, exppheno, X_MME, max_iter=5, thre=FloatT(1e-4))
                            cis_vc = reml(cis_KSs, exppheno, X_MME, _Vi_X, _Xt_Vi_X_i, cis_Hi, _Py, _P, _PA, _Vi, _cVi, _Di, _EAvec_Di, _EAvec, EA=cis_EA, varcmp=[prior_cis_vc[:ΣG][1], prior_cis_vc[:Σe]], em_update=true, convergence_parameters=convergence_parameters, convergence_dlogL=convergence_dlogL)
                        elseif cis_h2_algo == "idul"
                            cis_vc = get_IDUL_VarianceComponent(cis_EA, exppheno, X_MME)
                        end
                        cis_Σ_i .= [cis_vc[:ΣG][1], cis_vc[:Σe]]
                    elseif cis_h2_model in ["Ag+Ac", "Ag+Dc", "At+Ac"]
                        if cis_h2_algo == "em_aireml"
                            if _args_use_low_rank_approx
                                println("** LowRankApprox **")
                                LRA_factors = LowRankApproxUDV(cis_KSs[2], _args_approx_method, approx_rank, _args_avg_2norm_threshold, max_approx_rank)
                                cis_vc = reml([cis_KSs[1], LRA_factors.M, cis_KSs[3]], exppheno, X_MME, _Vi_X, _Xt_Vi_X_i, cis_Hi, _Py, _P, _PA, _Vi, _cVi, _Di, _EAvec_Di, _EAvec, EA=_struct_KIN.EA, LRA_factors=LRA_factors, convergence_parameters=convergence_parameters, convergence_dlogL=convergence_dlogL)
                                approx_ranki = LRA_factors.rank
                            else
                                cis_vc = reml(cis_KSs, exppheno, X_MME, _Vi_X, _Xt_Vi_X_i, cis_Hi, _Py, _P, _PA, _Vi, _cVi, _Di, _EAvec_Di, _EAvec, convergence_parameters=convergence_parameters, convergence_dlogL=convergence_dlogL)
                            end
                        end
                        cis_Σ_i .= [cis_vc[:ΣG][1], cis_vc[:ΣG][2], cis_vc[:Σe]]
                    end
                    cis_h2 .= cis_vc[:h2]
                    cis_h2_se .= cis_vc[:h2_se]
                    if h2_algo in ["em_aireml", "idul_aireml"]
                        _df_hers.converged[i] = cis_vc[:converged]
                    end
                    _df_hers.vg1[i] = cis_Σ_i[1]
                    _df_hers.ve[i] = cis_Σ_i[cis_n_cmp]
                    _df_hers.h2_g1[i] = cis_h2[1]
                    _df_hers.h2se_g1[i] = cis_h2_se[1]
                    if _args_use_low_rank_approx & (cis_h2_algo == "em_aireml") & (cis_h2_model in ["Ag+Ac", "Ag+Dc", "At+Ac"])
                        _df_hers.cis_rank[i] = approx_ranki
                    end
                    if cis_n_cmp == 3
                        _df_hers.vg2[i] = cis_Σ_i[2]
                        _df_hers.h2_g2[i] = cis_h2[2]
                        _df_hers.h2se_g2[i] = cis_h2_se[2]
                    end
                    _df_hers.cis_snps[i] = n_cis_snps
                    if cis_h2_model in ["At+Ac"]
                        _df_hers.trans_snps[i] = n_trans_snps
                    end
                end
            end
            if _args_trans_h2
                if trans_h2_model in ["At", "Dt"]
                    if trans_h2_algo == "minmax"
                        trans_vc = getOpenMendelVC(trans_KSs[1], exppheno, EA=trans_EA, X=X_MME, algo=:MM)
                    elseif trans_h2_algo == "em_aireml"
                        trans_vc = reml(trans_KSs, exppheno, X_MME, _Vi_X, _Xt_Vi_X_i, trans_Hi, _Py, _P, _PA, _Vi, _cVi, _Di, _EAvec_Di, _EAvec, EA=trans_EA, convergence_parameters=convergence_parameters, convergence_dlogL=convergence_dlogL)
                    elseif trans_h2_algo == "idul_aireml"
                        prior_trans_vc = get_IDUL_VarianceComponent(trans_EA, exppheno, X_MME, xQ=trans_xQ, max_iter=5, thre=FloatT(1e-3))
                        trans_vc = reml(trans_KSs, exppheno, X_MME, _Vi_X, _Xt_Vi_X_i, trans_Hi, _Py, _P, _PA, _Vi, _cVi, _Di, _EAvec_Di, _EAvec, EA=trans_EA, varcmp=[prior_trans_vc[:ΣG][1], prior_trans_vc[:Σe]], em_update=true, convergence_parameters=convergence_parameters, convergence_dlogL=convergence_dlogL)
                    elseif trans_h2_algo == "idul"
                        trans_vc = get_IDUL_VarianceComponent(trans_EA, exppheno, X_MME, xQ=trans_xQ)
                    end
                    trans_Σ_i .= [trans_vc[:ΣG][1], trans_vc[:Σe]]
                elseif trans_h2_model in ["Ag+Dt"]
                    if trans_h2_algo == "em_aireml"
                        trans_vc = reml(trans_KSs, exppheno, X_MME, _Vi_X, _Xt_Vi_X_i, trans_Hi, _Py, _P, _PA, _Vi, _cVi, _Di, _EAvec_Di, _EAvec, convergence_parameters=convergence_parameters, convergence_dlogL=convergence_dlogL)
                    end
                    trans_Σ_i .= [trans_vc[:ΣG][1], trans_vc[:ΣG][2], trans_vc[:Σe]]
                end
                trans_h2 .= trans_vc[:h2]
                trans_h2_se .= trans_vc[:h2_se]
                _df_hers.vg1[i] = trans_Σ_i[1]
                _df_hers.ve[i] = trans_Σ_i[trans_n_cmp]
                _df_hers.h2_g1[i] = trans_h2[1]
                _df_hers.h2se_g1[i] = trans_h2_se[1]
                if trans_n_cmp == 3
                    _df_hers.vg2[i] = trans_Σ_i[2]
                    _df_hers.h2_g2[i] = trans_h2[2]
                    _df_hers.h2se_g2[i] = trans_h2_se[2]
                end
                _df_hers.trans_snps[i] = n_trans_snps
                if h2_algo in ["em_aireml", "idul_aireml"]
                    _df_hers.converged[i] = trans_vc[:converged]
                end
            end
            @runif _args_debug if i % 10 == 0
                println_to_file(string("*** Elapsed time (h:m:s:ms): ", format_milliseconds(now() - time_start)), log_file)
                show(to)
            end
        end
        begin
            cols_float = [_df_hers[1, x] isa AbstractFloat for x in range(1, ncol(_df_hers))]
            _df_hers[:, cols_float] = round.(_df_hers[:, cols_float], sigdigits=6)
            if length(_args_chrom) > 0
                CSV.write(joinpath(_args_output_dir, string(_args_out_prefix, ".her_est.txt")), _df_hers, delim="\t")
                if _args_glo_h2
                    CSV.write(joinpath(_args_output_dir, string(_args_out_prefix, ".her_est.", chrom, ".B")), _df_covar_B, delim="\t")
                end
            else
                is_append = chrom != chroms[1]
                CSV.write(joinpath(_args_output_dir, string(_args_out_prefix, ".her_est.txt.gz")), _df_hers, delim="\t", compress=true, append=is_append)
                if _args_glo_h2
                    CSV.write(joinpath(_args_output_dir, string(_args_out_prefix, ".her_est.B.gz")), _df_covar_B, delim="\t", compress=true, append=is_append)
                end
            end
        end
        println_to_file(string("+++ Total elapsed time (h:m:s:ms): ", format_milliseconds(now() - time_start)), log_file)
        if _args_debug
            println_to_file(string(to), log_file)
        end
    end
end
