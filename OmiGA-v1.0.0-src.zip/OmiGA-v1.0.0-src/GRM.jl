```
 * OmiGA: a toolkit for Omics Genetic Analysis
 *
 * Copyright © 2024, Jinyan Teng
 * Copyright © 2024, Wenjin Zhang
 *
 * This file is distributed under the GNU General Public
 * License, Version 3. Please see the file LICENSE for more
 * details.
 *
 * All the files in this project are allowed to be copied, 
 * modified, and distributed for educational, research and 
 * non-profit purposes, without charge and without a written 
 * agreement, provided that this copyright notice are included
 * in all copies. If you intend to use this project for 
 * commercial purposes, kindly contact the author for 
 * authorization prior to use.
```
function get_expvar_optimized!(M::Matrix{Int8}, n_samples::Int, n_snps::Int, _2p::Matrix{T}, _2pq::Matrix{T}) where {T<:Float32}
    _p = zeros(Float32, 1, n_snps)
    _2nsamples = 1.0f0 / (2.0f0 * n_samples)
    sacle_vec = fill(_2nsamples, 1, n_samples)
    mul!(_p, sacle_vec, M)
    mul!(_2p, _p, 2.0f0)
    @. _p = 1.0f0 - _p
    @. _2pq = _2p * _p
end
function getG_fast(M::Matrix; alpha::Int=0, afs::Union{Nothing,AbstractArray{T}}=nothing, return_eltype::DataType=Float32) where {T<:AbstractFloat}
    n_samples, n_snps = size(M)
    α = alpha
    _halfα = α / 2.0f0
    scalvar = 0.0f0
    blocks = 1000
    block_size = ceil(Int, n_snps / blocks)
    G = zeros(Float32, n_samples, n_samples)
    tempG = zeros(Float32, n_samples, n_samples)
    X_block = zeros(Float32, n_samples, block_size)
    if α != 0.0f0
        _2pqα_block = zeros(Float32, 1, block_size)
    end
    _2p = zeros(Float32, 1, n_snps)
    _2pq = zeros(Float32, 1, n_snps)
    if isnothing(afs)
        get_expvar_optimized!(M, n_samples, n_snps, _2p, _2pq)
    else
        mul!(_2p, afs, 2.0f0)
        @. _2pq[:] = 1.0f0 - afs
        @. _2pq *= _2p
    end
    if α == -1.0f0
        scalvar = n_snps
    elseif α == 0.0f0
        scalvar = sum(_2pq)
    else
        scalvar = sum(_2pq .^ (1.0f0 + α))
    end
    for b in 1:blocks
        i = (b - 1) * block_size + 1
        j = min(b * block_size, n_snps)
        cblk_size = j - i + 1
        if cblk_size < block_size
            X_block = view(X_block, :, 1:cblk_size)
            if α != 0.0f0
                _2pqα_block = view(_2pqα_block, :, 1:cblk_size)
            end
        end
        M_block = view(M, :, i:j)
        _2p_block = view(_2p, :, i:j)
        _2pq_block = view(_2pq, :, i:j)
        broadcast!(-, X_block, M_block, _2p_block)
        if α != 0.0f0
            _2pqα_block .= _2pq_block .^ _halfα
            broadcast!(*, X_block, X_block, _2pqα_block)
        end
        mul!(tempG, X_block, X_block')
        tempG ./= scalvar
        G .+= tempG
    end
    G .= Symmetric(G)
    if return_eltype != Float32
        return return_eltype.(G)
    end
    return G
end
function getG_VanRaden(geno::Matrix; adjusted::Bool=false, afs::Union{Nothing,Vector{T}}=nothing, byrow::Bool=false, return_eltype::DataType=Float64) where {T<:Float64}
    n_samples, n_snps = size(geno)[ifelse(byrow, [1, 2], [2, 1])]
    if isnothing(afs)
        if adjusted
            error("'afs' must be provided for pre-adjusted genotype data")
        end
        afs = vec(sum(geno, dims=ifelse(byrow, 1, 2))) / (2 * n_samples)
    end
    _2p = 2 .* afs
    sum_2pq = dot(_2p, (1 .- afs))
    G = zeros(T, n_samples, n_samples)
    if n_snps < 100000
        M = copy(geno)
        if byrow
            if !adjusted
                M = M .- _2p'
            end
            mul!(G, M, M')
        else
            if !adjusted
                M = M .- _2p
            end
            mul!(G, M', M)
        end
    else
        block_size = 50000
        if byrow
            M = zeros(T, n_samples, block_size)
            iter_collects = collect(Iterators.partition(1:length(_2p), block_size))
            for i in 1:(length(iter_collects)-1)
                M .= geno[:, iter_collects[i]]
                M .-= _2p[iter_collects[i]]'
                G .+= matmul(M, M')
            end
            M = geno[:, iter_collects[end]] |> Matrix{T}
            M .-= _2p[iter_collects[end]]'
            G .+= matmul(M, M')
        else
            M = zeros(T, block_size, n_samples)
            iter_collects = collect(Iterators.partition(1:length(_2p), block_size))
            for i in 1:(length(iter_collects)-1)
                M .= geno[iter_collects[i], :]
                M .-= _2p[iter_collects[i]]
                G .+= matmul(M', M)
            end
            M = geno[iter_collects[end], :] |> Matrix{T}
            M .-= _2p[iter_collects[end]]
            G .+= matmul(M', M)
        end
    end
    G ./= sum_2pq
    G .= Symmetric(G)
    if return_eltype == Float32
        G = Float32.(G)
    end
    return G
end
function getG_VanRaden!(G::Matrix{T}, geno::Matrix{T}; adjusted::Bool=false, afs::Union{Nothing,Vector{T}}=nothing, byrow::Bool=false) where {T<:Float64}
    n_samples, n_snps = size(geno)[ifelse(byrow, [1, 2], [2, 1])]
    if isnothing(afs)
        if adjusted
            error("'afs' must be provided for pre-adjusted genotype data")
        end
        afs = vec(sum(geno, dims=ifelse(byrow, 1, 2))) / (2 * n_samples)
    end
    _2p = 2 .* afs
    sum_2pq = dot(_2p, (1 .- afs))
    fill!(G, 0.0)
    if n_snps < 100000
        M = copy(geno)
        if byrow
            if !adjusted
                M = M .- _2p'
            end
            mul!(G, M, M')
        else
            if !adjusted
                M = M .- _2p
            end
            mul!(G, M', M)
        end
    else
        block_size = 50000
        if byrow
            M = zeros(T, n_samples, block_size)
            iter_collects = collect(Iterators.partition(1:length(_2p), block_size))
            for i in 1:(length(iter_collects)-1)
                M .= geno[:, iter_collects[i]]
                M .-= _2p[iter_collects[i]]'
                G .+= matmul(M, M')
            end
            M = geno[:, iter_collects[end]] |> Matrix{T}
            M .-= _2p[iter_collects[end]]'
            G .+= matmul(M, M')
        else
            M = zeros(T, block_size, n_samples)
            iter_collects = collect(Iterators.partition(1:length(_2p), block_size))
            for i in 1:(length(iter_collects)-1)
                M .= geno[iter_collects[i], :]
                M .-= _2p[iter_collects[i]]
                G .+= matmul(M', M)
            end
            M = geno[iter_collects[end], :] |> Matrix{T}
            M .-= _2p[iter_collects[end]]
            G .+= matmul(M', M)
        end
    end
    G ./= sum_2pq
    G .= Symmetric(G)
    return G
end
function getG_dominance(geno::Matrix; code_type::String, adjusted::Bool=false, afs::Union{Nothing,Vector{T}}=nothing, byrow::Bool=false, return_eltype::DataType=Float64) where {T<:Float64}
    if code_type == "additive"
        if adjusted
            error("genotype data must be coded as 0,1,2")
        end
        if isnothing(afs)
            afs = vec(sum(geno, dims=ifelse(byrow, 1, 2))) / (2 * n_samples)
        end
        S = replace(geno, 2 => 0)
    elseif code_type == "dominance"
        S = copy(geno)
        if isnothing(afs)
            error("'afs' must be provided for dominance code genotype data")
        end
    end
    _2pq = 2 .* afs .* (1 .- afs)
    scale_factor = dot(_2pq, 1 .- _2pq)
    n_samples, n_snps = size(geno)[ifelse(byrow, [1, 2], [2, 1])]
    G = zeros(T, n_samples, n_samples)
    if n_snps < 100000
        if byrow
            if !adjusted
                S = S .- _2pq'
            end
            mul!(G, S, S')
        else
            if !adjusted
                S = S .- _2pq
            end
            mul!(G, S', S)
        end
    else
        block_size = 50000
        if byrow
            S = zeros(T, n_samples, block_size)
            iter_collects = collect(Iterators.partition(1:length(_2pq), block_size))
            for i in 1:(length(iter_collects)-1)
                S .= geno[:, iter_collects[i]]
                S .-= _2pq[iter_collects[i]]'
                G .+= matmul(S, S')
            end
            S = geno[:, iter_collects[end]] |> Matrix{T}
            S .-= _2pq[iter_collects[end]]'
            G .+= matmul(S, S')
        else
            S = zeros(T, block_size, n_samples)
            iter_collects = collect(Iterators.partition(1:length(_2pq), block_size))
            for i in 1:(length(iter_collects)-1)
                S .= geno[iter_collects[i], :]
                S .-= _2pq[iter_collects[i]]
                G .+= matmul(S', S)
            end
            S = geno[iter_collects[end], :] |> Matrix{T}
            S .-= _2pq[iter_collects[end]]
            G .+= matmul(S', S)
        end
    end
    G ./= scale_factor
    G .= Symmetric(G)
    if return_eltype == Float32
        G = Float32.(G)
    end
    return G
end
function getG_dominance!(G::Matrix{T}, geno::Matrix{T}; code_type::String, adjusted::Bool=false, afs::Union{Nothing,Vector{T}}=nothing, byrow::Bool=false) where {T<:Float64}
    if code_type == "additive"
        if adjusted
            error("genotype data must be coded as 0,1,2")
        end
        if isnothing(afs)
            afs = vec(sum(geno, dims=ifelse(byrow, 1, 2))) / (2 * n_samples)
        end
        S = replace(geno, 2 => 0)
    elseif code_type == "dominance"
        S = copy(geno)
        if isnothing(afs)
            error("'afs' must be provided for dominance code genotype data")
        end
    end
    _2pq = 2 .* afs .* (1 .- afs)
    scale_factor = dot(_2pq, 1 .- _2pq)
    n_samples, n_snps = size(geno)[ifelse(byrow, [1, 2], [2, 1])]
    fill!(G, 0.0)
    if n_snps < 100000
        if byrow
            if !adjusted
                S = S .- _2pq'
            end
            mul!(G, S, S')
        else
            if !adjusted
                S = S .- _2pq
            end
            mul!(G, S', S)
        end
    else
        block_size = 50000
        if byrow
            S = zeros(T, n_samples, block_size)
            iter_collects = collect(Iterators.partition(1:length(_2pq), block_size))
            for i in 1:(length(iter_collects)-1)
                S .= geno[:, iter_collects[i]]
                S .-= _2pq[iter_collects[i]]'
                G .+= matmul(S, S')
            end
            S = geno[:, iter_collects[end]] |> Matrix{T}
            S .-= _2pq[iter_collects[end]]'
            G .+= matmul(S, S')
        else
            S = zeros(T, block_size, n_samples)
            iter_collects = collect(Iterators.partition(1:length(_2pq), block_size))
            for i in 1:(length(iter_collects)-1)
                S .= geno[iter_collects[i], :]
                S .-= _2pq[iter_collects[i]]
                G .+= matmul(S', S)
            end
            S = geno[iter_collects[end], :] |> Matrix{T}
            S .-= _2pq[iter_collects[end]]
            G .+= matmul(S', S)
        end
    end
    G ./= scale_factor
    G .= Symmetric(G)
    return G
end
