```
 * OmiGA: a toolkit for Omics Genetic Analysis
 *
 * Copyright © 2024, Jinyan Teng
 *
 * This file is distributed under the GNU General Public
 * License, Version 3. Please see the file LICENSE for more
 * details.
 *
 * All the files in this project are allowed to be copied, 
 * modified, and distributed for educational, research and 
 * non-profit purposes, without charge and without a written 
 * agreement, provided that this copyright notice are included
 * in all copies. If you intend to use this project for 
 * commercial purposes, kindly contact the author for 
 * authorization prior to use.
```
function runOmiGA_cis(_struct_PHENO, _struct_GENO, _struct_KIN, _struct_COVAR, _struct_PRIOR_HerB; _struct_DOM::Union{Nothing,Dominance}=nothing, _struct_ITERM::Union{Nothing,InteractionTerm}=nothing)
    phenotype = _struct_PHENO.phenotype
    pheno_annotation = _struct_PHENO.annotation
    X_MME = _struct_COVAR.X_MME
    if !isnothing(_struct_PRIOR_HerB)
        prior_h2 = _struct_PRIOR_HerB.h2
        prior_B = _struct_PRIOR_HerB.B
    else
        prior_h2 = prior_B = nothing
    end
    snp_annotation = _struct_GENO.annotation
    qtl_map_model = _args_qtl_map_model
    qtl_map_algo = _args_qtl_map_algo
    n_samples = _struct_GENO.n_samples
    _n, _X_c = size(X_MME)
    test_phen_type = "raw"
    test_geno_type = "raw"
    perm_phen_type = "raw"
    perm_geno_type = "raw"
    n_tests = 1
    if _args_linear_model
        n_grms = 0
        qtl_map_algo = "standard_fast"
        if qtl_map_model == "a"
            genotype = _struct_GENO.genotype
            test_phen_type = "residualized"
            test_geno_type = "residualized"
        end
        if qtl_map_model == "d"
            genotype = _struct_DOM.genotype
            test_phen_type = "residualized"
            test_geno_type = "residualized"
        end
        if qtl_map_model == "a+d"
            error("'a+d' is not yet supported!")
            genotype = _struct_GENO.genotype
            domGenotype = _struct_DOM.genotype
            n_tests = 2
        end
        if _args_run_mode == "cis_interaction"
            qtl_map_algo = "idul"
            glo_EA = eigen(diagm(ones(FloatT, n_samples)))
            test_phen_type = "rotate"
            test_geno_type = "rotate"
            xQ = X_MME
            n_tests = 2
        end
    else
        n_grms = 1
        if qtl_map_model == "a+A"
            glo_EA = _struct_KIN.EA
            genotype = _struct_GENO.genotype
            if isnothing(prior_h2) & (_args_h2_algo == "minmax")
                glo_KS = _struct_KIN.GRM
            end
        end
        if qtl_map_model == "d+D"
            glo_EA = _struct_KIN.domEA
            genotype = _struct_DOM.genotype
            if isnothing(prior_h2) & (_args_h2_algo == "minmax")
                glo_KS = _struct_KIN.domGRM
            end
        end
        if qtl_map_model == "d+A"
            glo_EA = _struct_KIN.EA
            genotype = _struct_DOM.genotype
            if isnothing(prior_h2) & (_args_h2_algo == "minmax")
                glo_KS = _struct_KIN.GRM
            end
        end
        if qtl_map_model == "a+d+A+D"
            genotype = _struct_GENO.genotype
            domGenotype = _struct_DOM.genotype
            n_tests = 2
            n_grms = 2
        end
        if qtl_map_model == "d+A+D"
            genotype = _struct_DOM.genotype
            n_grms = 2
        end
        if (qtl_map_algo == "idul") & (n_grms < 2)
            test_phen_type = "rotate"
            test_geno_type = "rotate"
        end
        if _args_run_mode in ["cis_interaction"]
            n_tests = 2
            test_phen_type = "rotate"
            test_geno_type = "rotate"
        end
        _args_PreV = n_grms == 2
        if _args_PreV
            path_partialv = _args_path_partialv
            if !isnothing(path_partialv)
                _struct_PartialV = load(path_partialv)["data"]
            else
                error("--paed-file must be specified for QTL mapping models with two GRMs!")
            end
            if isnothing(prior_h2)
                error("--her-file must be specified for QTL mapping models with two GRMs!")
            end
        end
        if isnothing(prior_h2) & (_args_h2_algo == "idul") & (n_grms < 2)
            test_phen_type = "rotate"
            test_geno_type = "rotate"
        end
        if test_phen_type == "rotate"
            if _args_preadj_covar
                xQ = glo_EA.vectors' * X_MME[:, 1:1]
            else
                xQ = glo_EA.vectors' * X_MME
            end
        end
        if (qtl_map_algo == "idul") & (n_grms == 2)
            xQ = similar(X_MME)
            yQ = zeros(FloatT, n_samples)
            cGRM = zeros(FloatT, n_samples, n_samples)
            glo_EA = Eigen{FloatT,FloatT,Matrix{FloatT},Vector{FloatT}}(zeros(FloatT, n_samples), zeros(FloatT, n_samples, n_samples))
            Inds_AD_vecs = CartesianIndices(glo_EA.vectors)
        end
        if qtl_map_algo == "standard"
            Vi = zeros(FloatT, _n, _n)
            Di = Diagonal(zeros(FloatT, _n, _n))
            EAvec_Di = zeros(FloatT, _n, _n)
            if qtl_map_model in ["a+A+D", "d+A+D", "a+d+A+D"]
                EAvec = zeros(FloatT, _n, _n)
            end
        end
    end
    if _X_c == 1
        QQt = nothing
        DOF = size(X_MME, 1) - 2
    elseif _X_c > 1
        Q, DOF = residualizer(X_MME[:, 2:end])
        QQt = Q * Q'
        I_minus_Q_Qt = I - QQt
    end
    if qtl_map_algo == "idul"
        df_subs = fill(NAN, 5, 3 * n_tests + 2)
    end
    calcu_variant_threshold = _args_calcu_variant_threshold
    multiple_testing_method = isnothing(_args_multiple_testing) ? "clipper" : _args_multiple_testing
    n_perms = _args_n_perms
    nominal_only = _args_nominal_only
    if multiple_testing_method == "acat"
        nominal_only = true
    else
        calcu_variant_threshold = true
    end
    if calcu_variant_threshold
        nominal_only = false
        if multiple_testing_method == "acat"
            permutation_method = "standard_fast"
        elseif multiple_testing_method == "beta_approx"
            permutation_method = "standard_fast"
        else
            permutation_method = nothing
        end
    else
        permutation_method = multiple_testing_method
    end
    if !nominal_only
        if isnothing(permutation_method)
            if n_tests == 1
                if n_samples < 450
                    permutation_method = "standard_fast"
                else
                    permutation_method = "clipper"
                end
            elseif n_tests == 2
                permutation_method = "standard_fast"
            else
                permutation_method = "standard"
            end
        end
        @runif isnothing(n_perms) if permutation_method in ["standard", "standard_fast"]
            n_perms = 1000
        elseif permutation_method == "clipper"
            n_perms = 100
        end
        if (n_tests == 2) | _args_preadj_covar
            Xt_X = X_MME' * X_MME
        end
        if permutation_method in ["standard", "standard_fast", "clipper"]
            if permutation_method == "standard_fast"
                y_perms = fill(NAN, n_samples, n_perms)
                absr_perm = fill(NAN, n_perms)
                perm_phen_type = "raw"
                perm_geno_type = "residualized"
            end
            if permutation_method == "clipper"
                absr_perm = fill(NAN, n_perms)
                perm_phen_type = "residualized"
                perm_geno_type = "residualized"
            end
            if (permutation_method == "standard") & (qtl_map_algo == "idul")
                y_perms = fill(NAN, n_samples, n_perms)
                absr_perm = fill(NAN, n_perms)
                perm_phen_type = "raw"
                perm_geno_type = "raw"
            end
        end
        if (n_tests == 2) & (permutation_method == "standard") & (qtl_map_algo == "idul")
            _xQ_c = size(xQ, 2)
            _c2 = _xQ_c + 2
            xW0 = [ones(FloatT, _n, 2) xQ]
            xtx_init = matmul(xW0', xW0)
            xty_init = zeros(FloatT, _c2, n_perms)
        end
        calcu_variant_threshold = true
    else
        n_perms = 0
    end
    df_perm = DataFrame()
    df_tops = DataFrame()
    pheno_annotation.index = 1:nrow(pheno_annotation)
    chroms = intersect(string.(unique(pheno_annotation.chrom)), string.(unique(snp_annotation.chromosome)))
    _task_write_full_pairs = @task @info "Using Tasks"
    for chrom in chroms
        snp_index_chrom = snp_annotation.chromosome .== chrom
        _gene_annot = pheno_annotation[pheno_annotation.chrom.==chrom, :]
        _snp_annot = snp_annotation[snp_annotation.chromosome.==chrom, :]
        _snp_annot.reindex = USE_Float32 ? Int32.(1:size(_snp_annot, 1)) : 1:size(_snp_annot, 1)
        _gene_snps = [get_cis_snp_info(_gene_annot, _snp_annot, gene, _args_cis_window; nsnp_only=true) for gene in _gene_annot.pheno_id]
        _gene_annot = _gene_annot[_gene_snps.>0, :]
        _gene_snps = _gene_snps[_gene_snps.>0]
        _n_genes = length(_gene_annot.pheno_id)
        _gene_end_index = accumulate(+, _gene_snps)
        _gene_start_index = _gene_end_index[1:end-1] .+ 1
        prepend!(_gene_start_index, 1)
        nrow_df_full = sum(_gene_snps)
        df_full = DataFrame([
            "pheno_id" => repeat([""], nrow_df_full),
            "variant_id" => "",
            "start_distance" => 0,
            "af" => NAN,
            "beta_g1" => NAN,
            "beta_se_g1" => NAN,
            "pval_g1" => NaN,
        ])
        _df_tops = DataFrame(pheno_id=_gene_annot.pheno_id,
            num_var=0,
            num_perm=n_perms,
            dof=DOF,
            map_model=qtl_map_model,
            variant_id="",
            start_distance=0,
            af=NAN,
            beta_g1=NAN,
            beta_se_g1=NAN,
            pval_g1=NaN,
        )
        if n_tests == 1
            @runif calcu_variant_threshold _df_tops.pval_g1_threshold .= NaN
            @runif multiple_testing_method == "acat" _df_tops.pval_g1_acat .= NaN
            _df_perm = hcat(DataFrame(pheno_id=_gene_annot.pheno_id, chrom=chrom), DataFrame(Dict(Symbol(lpad(i, 5, '0')) => repeat([NAN], _n_genes) for i in 1:(n_tests*(n_perms+1)))))
            rename!(_df_perm, ["pheno_id", "chrom", string.("X", 1:(n_tests*(n_perms+1)))...])
            _2p = 2 .* snp_annotation.af[snp_index_chrom]
            _2pq = _2p .* (1 .- snp_annotation.af[snp_index_chrom])
            if is_sample_byrow
                _2p = reshape(_2p, 1, :)
                _2pq = reshape(_2pq, 1, :)
                chrom_genotype = genotype[:, snp_index_chrom] |> Matrix{FloatT}
                if qtl_map_model in ["d+D", "d+A", "d+A+D", "d"]
                    broadcast!(-, chrom_genotype, chrom_genotype, _2pq)
                else
                    broadcast!(-, chrom_genotype, chrom_genotype, _2p)
                end
                if (test_geno_type == "residualized") | (perm_geno_type == "residualized")
                    chrom_genotype_res = copy(chrom_genotype)
                    if qtl_map_algo == "standard_fast"
                        chrom_g1_std = get_matrix_resid!(chrom_genotype_res, QQt, return_std=true)
                    else
                        get_matrix_resid!(chrom_genotype_res, QQt, return_std=false)
                    end
                end
                if (test_phen_type == "residualized") | (perm_phen_type == "residualized")
                    if _args_linear_model
                        chrom_phenotype_res, chrom_phenotype_std = get_matrix_resid(phenotype[:, pheno_annotation.chrom.==chrom], QQt, return_std=true)
                    else
                        chrom_phenotype_res = get_matrix_resid(phenotype[:, pheno_annotation.chrom.==chrom], QQt, return_std=false)
                    end
                end
                if test_geno_type == "rotate"
                    chrom_SQ = glo_EA.vectors' * chrom_genotype
                end
                if test_phen_type == "rotate"
                    if _args_preadj_covar
                        chrom_yQ = glo_EA.vectors' * get_lm_residuals(X_MME, phenotype[:, _gene_annot.index], Xt_X)
                    else
                        chrom_yQ = glo_EA.vectors' * phenotype[:, _gene_annot.index]
                    end
                end
            else
                chrom_genotype = similar(genotype[snp_index_chrom, :], FloatT)
                chrom_genotype .= genotype[snp_index_chrom, :]
                if qtl_map_model in ["d+D", "d+A", "d+A+D", "d"]
                    broadcast!(-, chrom_genotype, chrom_genotype, _2pq)
                else
                    broadcast!(-, chrom_genotype, chrom_genotype, _2p)
                end
            end
        end
        if n_tests == 2
            df_full.beta_g2 .= NAN
            df_full.beta_se_g2 .= NAN
            df_full.pval_g2 .= NaN
            _df_tops.beta_g2 .= NAN
            _df_tops.beta_se_g2 .= NAN
            _df_tops.pval_g2 .= NaN
            @runif calcu_variant_threshold _df_tops.pval_g2_threshold .= NaN
            @runif multiple_testing_method == "acat" _df_tops.pval_g2_acat .= NaN
            if _args_run_mode == "cis_interaction"
                _df_tops.map_model .= replace(qtl_map_model, "a" => "a+ai")
            end
            _df_perm = hcat(DataFrame(pheno_id=_gene_annot.pheno_id, chrom=chrom), DataFrame(Dict(Symbol(lpad(i, 5, '0')) => repeat([NAN], _n_genes) for i in 1:((n_tests+1)*(n_perms+1)))))
            rename!(_df_perm, ["pheno_id", "chrom", string.("X", 1:((n_tests+1)*(n_perms+1)))...])
            _2p = 2 .* snp_annotation.af[snp_index_chrom]
            _2pq = _2p .* (1 .- snp_annotation.af[snp_index_chrom])
            if is_sample_byrow
                _2p = _2p' |> Matrix
                _2pq = _2pq' |> Matrix
                chrom_genotype = similar(genotype[:, snp_index_chrom], FloatT)
                chrom_genotype .= genotype[:, snp_index_chrom]
                chrom_genotype .-= _2p
                if _args_run_mode == "cis"
                    chrom_genotype_2nd = similar(domGenotype[:, snp_index_chrom], FloatT)
                    chrom_genotype_2nd .= domGenotype[:, snp_index_chrom]
                    chrom_genotype_2nd .-= _2pq
                elseif _args_run_mode == "cis_interaction"
                    if qtl_map_algo != "idul"
                        chrom_genotype_2nd = copy(chrom_genotype)
                        chrom_genotype_2nd .*= _struct_ITERM.ITERM
                    else
                        chrom_SQ = glo_EA.vectors' * chrom_genotype
                        chrom_SIQ = glo_EA.vectors' * (chrom_genotype .* _struct_ITERM.ITERM)
                        if _args_preadj_covar
                            chrom_yQ = glo_EA.vectors' * get_lm_residuals(X_MME, phenotype[:, _gene_annot.index], Xt_X)
                        else
                            chrom_yQ = glo_EA.vectors' * phenotype[:, _gene_annot.index]
                        end
                    end
                end
            else
                chrom_genotype = similar(genotype[snp_index_chrom, :], FloatT)
                chrom_genotype .= genotype[snp_index_chrom, :]
                chrom_genotype .-= _2p
                if _args_run_mode == "cis"
                    chrom_genotype_2nd = similar(domGenotype[snp_index_chrom, :], FloatT)
                    chrom_genotype_2nd .= domGenotype[snp_index_chrom, :]
                    chrom_genotype_2nd .-= _2pq
                end
                if _args_run_mode == "cis_interaction"
                    chrom_genotype_2nd = copy(chrom_genotype)
                    chrom_genotype_2nd .*= _struct_ITERM.ITERM'
                end
            end
        end
        @runif multiple_testing_method == "beta_approx" begin
            _df_tops.pval_beta .= NaN
            _df_tops.beta_shape1 .= NAN
            _df_tops.beta_shape2 .= NAN
            _df_tops.true_dof .= NAN
            _df_tops.pval_true_dof .= NaN
        end
        @runif !nominal_only begin
            if (n_tests == 2) & (_args_run_mode == "cis_interaction") & (permutation_method == "standard") & (qtl_map_algo == "idul")
                chrom_xtx_SQt_xQ = zeros(FloatT, _c2, size(chrom_SQ, 2))
                chrom_xtx_SQ2t_xQ = zeros(FloatT, _c2, size(chrom_SQ, 2))
                chrom_xtx_SQt_xQ[1, :] .= vec(sum(abs2, chrom_SQ, dims=1))
                chrom_xtx_SQ2t_xQ[2, :] = vec(sum(abs2, chrom_SIQ, dims=1))
                chrom_xtx_SQt_xQ[2, :] .= chrom_xtx_SQ2t_xQ[1, :] = vec(sum(chrom_SQ .* chrom_SIQ, dims=1))
                chrom_xtx_SQt_xQ[3:end, :] = matmul(xQ', chrom_SQ)
                chrom_xtx_SQ2t_xQ[3:end, :] = matmul(xQ', chrom_SIQ)
                stat_perm = fill(NAN, n_perms * (n_tests + 1))
            end
            if (n_tests == 2) & (perm_geno_type == "residualized") & (_args_run_mode == "cis_interaction")
                if qtl_map_algo == "standard_fast"
                    chrom_SQ1_pcc = similar(chrom_genotype)
                    @runif _args_run_mode == "cis_interaction" get_lm_residuals!(chrom_SQ1_pcc, X_MME, chrom_genotype, chrom_genotype .* _struct_ITERM.ITERM)
                    @runif _args_run_mode == "cis" get_lm_residuals!(chrom_SQ1_pcc, X_MME, chrom_genotype, chrom_genotype_2nd)
                    chrom_SQ1_pcc ./= sqrt.(sum(abs2, chrom_SQ1_pcc, dims=1))
                    chrom_SQ1_pcc .-= Statistics.mean(chrom_SQ1_pcc, dims=1)
                end
                chrom_SQ2_pcc = similar(chrom_genotype)
                @runif _args_run_mode == "cis_interaction" get_lm_residuals!(chrom_SQ2_pcc, X_MME, chrom_genotype .* _struct_ITERM.ITERM, chrom_genotype)
                @runif _args_run_mode == "cis" get_lm_residuals!(chrom_SQ2_pcc, X_MME, chrom_genotype_2nd, chrom_genotype)
                chrom_SQ2_pcc ./= sqrt.(sum(abs2, chrom_SQ2_pcc, dims=1))
                chrom_SQ2_pcc .-= Statistics.mean(chrom_SQ2_pcc, dims=1)
                stat_perm = fill(NAN, n_perms * (n_tests + 1))
            end
        end
        if !isnothing(_args_pheno_group_file)
            cis_genotype = nothing
            cis_genotype_iterm = nothing
            cis_genotype_2nd = nothing
            cis_g1_std = nothing
            cis_g2_std = nothing
        end
        GC.gc()
        time_start = now()
        println_to_file(string("  Chromosome: ", chrom, ", start at: ", time_start), log_file)
        for i in 1:_n_genes
            println_to_file(string("    GENE: ", i, "/", _n_genes), log_file)
            gene = _gene_annot.pheno_id[i]
            if test_phen_type == "residualized"
                testpheno = chrom_phenotype_res[:, i]
            end
            if test_phen_type == "rotate"
                testpheno = chrom_yQ[:, i]
            end
            pheno_index = findfirst(pheno_annotation.pheno_id .== gene)
            if test_phen_type == "raw"
                testpheno = vec(phenotype[:, pheno_index])
            end
            if !isnothing(_args_pheno_group_file)
                is_pre_data = _gene_annot.group_id_first[i]
            else
                is_pre_data = true
            end
            cissnps_annot, n_cis_snps = get_cis_snp_info(_gene_annot, _snp_annot, gene, _args_cis_window)
            if n_cis_snps < 1
                println_to_file(string(" * [SKIP] Zero variant within the cis-window of ", gene, "."), log_file)
                continue
            end
            if isnothing(_args_pheno_group_file) | is_pre_data
                begin
                    if is_sample_byrow
                        if qtl_map_algo == "standard"
                            cis_genotype = chrom_genotype[:, cissnps_annot.reindex]
                        elseif qtl_map_algo == "standard_fast"
                            cis_g1_std = chrom_g1_std[cissnps_annot.reindex]
                            if _args_run_mode == "cis"
                                cis_genotype = chrom_genotype_res[:, cissnps_annot.reindex]
                            elseif _args_run_mode == "cis_interaction"
                                cis_genotype = chrom_SQ1_pcc[:, cissnps_annot.reindex]
                            end
                            @runif _args_run_mode == "cis_interaction" cis_genotype_iterm = chrom_SQ2_pcc[:, cissnps_annot.reindex]
                            @runif _args_run_mode == "cis_interaction" cis_g2_std = chrom_g2_std[cissnps_annot.reindex]
                        elseif qtl_map_algo == "idul"
                            if n_grms < 2
                                cis_genotype = chrom_SQ[:, cissnps_annot.reindex]
                                @runif _args_run_mode == "cis_interaction" cis_genotype_iterm = chrom_SIQ[:, cissnps_annot.reindex]
                            elseif n_grms == 2
                                cis_genotype = chrom_genotype[:, cissnps_annot.reindex]
                            end
                        end
                    else
                        cis_genotype = chrom_genotype[cissnps_annot.reindex, :]
                    end
                    if (qtl_map_model in ["a+d+A+D", "a+d"]) & (qtl_map_algo == "idul")
                        if is_sample_byrow
                            cis_genotype_2nd = chrom_genotype_2nd[:, cissnps_annot.reindex]
                        else
                            cis_genotype_2nd = chrom_genotype_2nd[cissnps_annot.reindex, :]
                        end
                    end
                end
            end
            if !_args_linear_model
                if (qtl_map_algo == "standard") | (n_grms == 2)
                    if !isnothing(prior_h2)
                        index_prior_h2 = findfirst(prior_h2.pheno_id .== gene)
                        Σ_i = [prior_h2.vg1[index_prior_h2], prior_h2.vg2[index_prior_h2], prior_h2.ve[index_prior_h2]]
                        glo_vc_B = vec(prior_B[index_prior_h2, 3:end])
                    else
                        if _args_h2_algo == "minmax"
                            glo_vc = getOpenMendelVC(glo_KS, testpheno, EA=glo_EA, X=X_MME, algo=:MM)
                        elseif _args_h2_algo == "idul"
                            glo_vc = get_IDUL_VarianceComponent(glo_EA, testpheno, X_MME, xQ=xQ)
                        end
                        Σ_i = [glo_vc[:ΣG][1], NAN, glo_vc[:Σe]]
                        glo_vc_B = glo_vc[:Fix_eff]
                    end
                end
                if qtl_map_algo == "standard"
                    if qtl_map_model in ["a+A", "d+D", "d+A"]
                        getVinv!(Vi, Di, glo_EA, Σ_i[[1, 3]], EAvec_Di)
                    elseif qtl_map_model in ["a+A+D", "d+A+D", "a+d+A+D"]
                        getVinv!(Vi, Σ_i, _struct_PartialV, Di, EAvec_Di, EAvec)
                    end
                end
                if (qtl_map_algo == "idul") & (n_grms == 2)
                    ratio = maximum([Σ_i[1] / Σ_i[2], Σ_i[2] / Σ_i[1]])
                    println("Ratio between vg1 and vg2: ", ratio)
                    if ratio > maximum(_struct_PartialV.vec_ratio)
                        if ratio > 1000
                            if Σ_i[2] > Σ_i[1]
                                glo_EA.vectors .= _struct_KIN.domEA.vectors
                                glo_EA.values .= _struct_KIN.domEA.values
                            else
                                glo_EA.vectors .= _struct_KIN.EA.vectors
                                glo_EA.values .= _struct_KIN.EA.values
                            end
                        else
                            cGRM .= Σ_i[1] / sum(Σ_i[1:2]) * _struct_KIN.GRM + Σ_i[2] / sum(Σ_i[1:2]) * _struct_KIN.domGRM
                            glo_EA = eigen!(cGRM)
                        end
                    else
                        ratio_index = argmin(abs.(ratio .- _struct_PartialV.vec_ratio)) * 2
                        if Σ_i[1] >= Σ_i[2]
                            ratio_index -= 1
                        end
                        j = ratio_index
                        range_inds = _n*(j-1)+1:_n*j
                        vals_inds = CartesianIndices((range_inds,))
                        vecs_inds = CartesianIndices((range_inds, 1:_n))
                        copyto!(glo_EA.vectors, Inds_AD_vecs, _struct_PartialV.eigvecs, vecs_inds)
                        glo_EA.values .= _struct_PartialV.eigvals[vals_inds]
                    end
                    if !is_pre_data
                        cis_genotype .= chrom_genotype[:, cissnps_annot.reindex]
                        cis_genotype_2nd .= chrom_genotype_2nd[:, cissnps_annot.reindex]
                    end
                    cis_genotype .= glo_EA.vectors' * cis_genotype
                    @runif qtl_map_model == "a+d+A+D" cis_genotype_2nd .= glo_EA.vectors' * cis_genotype_2nd
                    mul!(yQ, glo_EA.vectors', testpheno)
                    mul!(xQ, glo_EA.vectors', X_MME)
                end
            end
            if _args_linear_model
                if _args_run_mode == "cis"
                    if !is_pre_data
                        cis_genotype .= chrom_genotype_res[:, cissnps_annot.reindex]
                    end
                    df_test = fill(NAN, n_cis_snps, 3)
                    assoc_r = fill(NAN, n_cis_snps)
                    mul!(assoc_r, cis_genotype', testpheno)
                    get_approx_slope_se_from_r!(df_test, assoc_r, DOF, cis_g1_std, chrom_phenotype_std[i]; is_calcu_pv=false)
                elseif _args_run_mode == "cis_interaction"
                    if qtl_map_algo == "idul"
                        if !is_pre_data
                            cis_genotype .= chrom_SQ[:, cissnps_annot.reindex]
                            cis_genotype_iterm .= chrom_SIQ[:, cissnps_annot.reindex]
                        end
                        df_test = fill(NAN, n_cis_snps, 3 * n_tests + 1)
                        idul_two_assoc_test_0eta!(df_test, cis_genotype, testpheno, xQ, cis_genotype_iterm; is_calcu_pv=false)
                    elseif qtl_map_algo == "standard_fast"
                        if !is_pre_data
                            cis_genotype .= chrom_SQ1_pcc[:, cissnps_annot.reindex]
                            cis_genotype_iterm .= chrom_SQ2_pcc[:, cissnps_annot.reindex]
                        end
                        df_test = fill(NAN, n_cis_snps, 3 * n_tests + 1)
                        assoc_r = fill(NAN, n_cis_snps)
                        yadj = get_phenotype_resid(testpheno, I_minus_Q_Qt)
                        mul!(assoc_r, cis_genotype', yadj)
                        get_approx_slope_se_from_r!(view(df_test, :, 1:3), assoc_r, DOF, cis_g1_std, std(testpheno); is_calcu_pv=false)
                        mul!(assoc_r, cis_genotype_iterm', yadj)
                        get_approx_slope_se_from_r!(view(df_test, :, 4:6), assoc_r, DOF, cis_g2_std, std(testpheno); is_calcu_pv=false)
                    end
                end
            else
                if qtl_map_algo == "idul"
                    if _args_run_mode == "cis"
                        if n_tests == 1
                            if !is_pre_data
                                @runif test_geno_type == "rotate" cis_genotype .= chrom_SQ[:, cissnps_annot.reindex]
                            end
                            @runif qtl_map_model == "d+A+D" testpheno .= yQ
                            df_test = fill(NAN, n_cis_snps, 3)
                            idul_prior_index = sample(1:n_cis_snps, 5)
                            fill!(df_subs, NAN)
                            idul_assoc_test_plus!(df_subs, cis_genotype[:, idul_prior_index], testpheno, xQ, glo_EA.values; max_iter=_args_idul_max_iter, thre=FloatT.(_args_idul_converge), init_eta=FloatT(1.5), return_detail=true, is_calcu_pv=false)
                            init_eta = Statistics.mean(df_subs[.!isnan.(df_subs[:, 2]), 2])
                            @runif isnan(init_eta) continue
                            if !_args_exact_map
                                idul_assoc_test_approx!(df_test, cis_genotype, testpheno, xQ, glo_EA.values; init_eta=init_eta, is_calcu_pv=false)
                            else
                                idul_assoc_test_plus!(df_test, cis_genotype, testpheno, xQ, glo_EA.values; max_iter=_args_idul_max_iter, thre=FloatT.(_args_idul_converge), init_eta=init_eta, is_calcu_pv=false)
                            end
                        elseif n_tests == 2
                            df_test = fill(NAN, n_cis_snps, 3 * n_tests + 1)
                            idul_prior_index = sample(1:n_cis_snps, 5)
                            fill!(df_subs, NAN)
                            idul_two_assoc_test!(df_subs, cis_genotype[:, idul_prior_index], testpheno, xQ, glo_EA.values, cis_genotype_2nd[:, idul_prior_index]; max_iter=_args_idul_max_iter, thre=FloatT.(_args_idul_converge), init_eta=FloatT(1.5), return_detail=true, is_calcu_pv=false)
                            init_eta = Statistics.mean(df_subs[.!isnan.(df_subs[:, 2]), 2])
                            @runif isnan(init_eta) continue
                            if !_args_exact_map
                                idul_two_assoc_test_approx!(df_test, cis_genotype, testpheno, xQ, glo_EA.values, cis_genotype_2nd; init_eta=init_eta, is_calcu_pv=false)
                            else
                                idul_two_assoc_test!(df_test, cis_genotype, testpheno, xQ, glo_EA.values, cis_genotype_2nd; max_iter=_args_idul_max_iter, thre=FloatT.(_args_idul_converge), init_eta=init_eta, is_calcu_pv=false)
                            end
                        end
                    elseif _args_run_mode == "cis_interaction"
                        if !is_pre_data
                            cis_genotype .= chrom_SQ[:, cissnps_annot.reindex]
                            cis_genotype_iterm .= chrom_SIQ[:, cissnps_annot.reindex]
                        end
                        df_test = fill(NAN, n_cis_snps, 3 * n_tests + 1)
                        idul_prior_index = sample(1:n_cis_snps, 5)
                        fill!(df_subs, NAN)
                        idul_two_assoc_test!(df_subs, cis_genotype[:, idul_prior_index], testpheno, xQ, glo_EA.values, cis_genotype_iterm[:, idul_prior_index]; max_iter=_args_idul_max_iter, thre=FloatT.(_args_idul_converge), init_eta=FloatT(1.5), return_detail=true, is_calcu_pv=false)
                        init_eta = Statistics.mean(df_subs[.!isnan.(df_subs[:, 2]), 2])
                        @runif isnan(init_eta) continue
                        if !_args_exact_map
                            idul_two_assoc_test_approx!(df_test, cis_genotype, testpheno, xQ, glo_EA.values, cis_genotype_iterm; init_eta=init_eta, is_calcu_pv=false)
                        else
                            idul_two_assoc_test!(df_test, cis_genotype, testpheno, xQ, glo_EA.values, cis_genotype_iterm; max_iter=_args_idul_max_iter, thre=FloatT.(_args_idul_converge), init_eta=init_eta, is_calcu_pv=false)
                        end
                    end
                elseif qtl_map_algo == "standard"
                    yadj = testpheno
                    if _args_run_mode == "cis"
                        if qtl_map_model in ["a+d+A+D"]
                            df_test = fill(NAN, n_cis_snps, 3 * n_tests + 1)
                            calcu_two_assoc_test!(df_test, Vi, cis_genotype, cis_genotype_2nd, yadj)
                        else
                            df_test = fill(NAN, n_cis_snps, 3)
                            calcu_one_assoc_test!(df_test, Vi, cis_genotype, yadj)
                        end
                    elseif _args_run_mode == "cis_interaction"
                        df_test = fill(NAN, n_cis_snps, 3 * n_tests + 1)
                        calcu_two_assoc_test!(df_test, Vi, cis_genotype, _struct_ITERM.ITERM, yadj)
                    end
                end
            end
            begin
                _df_full_index = _gene_start_index[i]:_gene_end_index[i]
                df_full.pheno_id[_df_full_index] .= gene
                df_full.variant_id[_df_full_index] .= cissnps_annot.variant
                df_full.start_distance[_df_full_index] .= cissnps_annot.start_distance
                df_full.af[_df_full_index] .= cissnps_annot.af
                if n_tests == 1
                    df_full.beta_g1[_df_full_index] .= df_test[:, 1]
                    df_full.beta_se_g1[_df_full_index] .= df_test[:, 2]
                    if _args_linear_model & (qtl_map_algo != "idul")
                        df_full.pval_g1[_df_full_index] .= cdf(TDist(DOF), -df_test[:, 3]) * 2
                    else
                        df_full.pval_g1[_df_full_index] .= ccdf(FDist(1, DOF), df_test[:, 3])
                    end
                end
                if n_tests == 2
                    df_full.beta_g1[_df_full_index] .= df_test[:, 1]
                    df_full.beta_se_g1[_df_full_index] .= df_test[:, 2]
                    if _args_linear_model & (qtl_map_algo != "idul")
                        df_full.pval_g1[_df_full_index] .= ccdf(TDist(DOF - 1), df_test[:, 3]) * 2
                    else
                        df_full.pval_g1[_df_full_index] .= ccdf(FDist(1, DOF - 1), df_test[:, 3])
                    end
                    df_full.beta_g2[_df_full_index] .= df_test[:, 4]
                    df_full.beta_se_g2[_df_full_index] .= df_test[:, 5]
                    if _args_linear_model & (qtl_map_algo != "idul")
                        df_full.pval_g2[_df_full_index] .= ccdf(TDist(DOF - 1), df_test[:, 6]) * 2
                    else
                        df_full.pval_g2[_df_full_index] .= ccdf(FDist(1, DOF - 1), df_test[:, 6])
                    end
                end
            end
            @runif !nominal_only if n_tests == 1
                begin
                    Ainds = CartesianIndices(cis_genotype)
                    if is_sample_byrow
                        Binds = CartesianIndices((1:size(chrom_genotype_res, 1), minimum(cissnps_annot.reindex):maximum(cissnps_annot.reindex)))
                    else
                        Binds = CartesianIndices((minimum(cissnps_annot.reindex):maximum(cissnps_annot.reindex), 1:size(chrom_genotype_res, 2)))
                    end
                    copyto!(cis_genotype, Ainds, chrom_genotype_res, Binds)
                end
                if permutation_method == "clipper"
                    permpheno = chrom_phenotype_res[:, i]
                    cis_permutation_one_assoc!("clipper", i, permpheno, nothing, cis_genotype, absr_perm, _df_perm, _df_tops, df_full[_df_full_index, :], DOF, fdr=FloatT(_args_fdr))
                end
                if permutation_method == "standard_fast"
                    permpheno = phenotype[:, pheno_index]
                    cis_permutation_one_assoc!("standard_fast", i, permpheno, QQt, cis_genotype, absr_perm, _df_perm, _df_tops, df_full[_df_full_index, :], DOF; y_perms=y_perms, fdr=FloatT(_args_fdr))
                end
            elseif (n_tests == 2) & (_args_run_mode == "cis")
                if permutation_method == "standard"
                    permpheno = phenotype[:, pheno_index]
                    cis_permutation_two_assoc!("standard", i, permpheno, cis_genotype, cis_genotype_2nd, _df_perm, _df_tops, df_full[_df_full_index, :], y_perms, cissnps_annot;
                        X_MME=nothing, Xt_X=nothing, glo_EA=glo_EA, chrom_xtx_SQt_xQ=chrom_xtx_SQt_xQ, chrom_xtx_SQ2t_xQ=chrom_xtx_SQ2t_xQ, xW0=xW0, xty_init=xty_init,
                        xtx_init=xtx_init, fdr=FloatT(_args_fdr))
                elseif permutation_method == "standard_fast"
                    Ainds = CartesianIndices(cis_genotype_2nd)
                    Binds = CartesianIndices((1:size(chrom_SQ2_pcc, 1), minimum(cissnps_annot.reindex):maximum(cissnps_annot.reindex)))
                    copyto!(cis_genotype_2nd, Ainds, chrom_SQ2_pcc, Binds)
                    permpheno = phenotype[:, pheno_index]
                    cis_permutation_two_assoc!("standard_fast", i, permpheno, cis_genotype, cis_genotype_2nd, _df_perm, _df_tops, df_full[_df_full_index, :], y_perms, cissnps_annot, stat_perm; X_MME=X_MME, Xt_X=Xt_X, fdr=FloatT(_args_fdr))
                end
            elseif (n_tests == 2) & (_args_run_mode == "cis_interaction")
                if permutation_method == "standard"
                    permpheno = phenotype[:, pheno_index]
                    cis_permutation_two_assoc!("standard", i, permpheno, cis_genotype, cis_genotype_iterm, _df_perm, _df_tops, df_full[_df_full_index, :], y_perms, cissnps_annot;
                        X_MME=nothing, Xt_X=nothing, glo_EA=glo_EA, chrom_xtx_SQt_xQ=chrom_xtx_SQt_xQ, chrom_xtx_SQ2t_xQ=chrom_xtx_SQ2t_xQ, xW0=xW0, xty_init=xty_init,
                        xtx_init=xtx_init, fdr=FloatT(_args_fdr))
                elseif permutation_method == "standard_fast"
                    Ainds = CartesianIndices(cis_genotype_iterm)
                    Binds = CartesianIndices((1:size(chrom_SQ2_pcc, 1), minimum(cissnps_annot.reindex):maximum(cissnps_annot.reindex)))
                    copyto!(cis_genotype_iterm, Ainds, chrom_SQ2_pcc, Binds)
                    permpheno = phenotype[:, pheno_index]
                    cis_permutation_two_assoc!("standard_fast", i, permpheno, cis_genotype, cis_genotype_iterm, _df_perm, _df_tops, df_full[_df_full_index, :], y_perms, cissnps_annot, stat_perm; X_MME=X_MME, Xt_X=Xt_X, fdr=FloatT(_args_fdr))
                end
            else
                error("!")
            end
            if multiple_testing_method == "acat"
                @runif !calcu_variant_threshold append_top_summary!(df_full[_df_full_index, :], _df_tops, i, n_tests)
                if n_tests == 1
                    pvals_for_acat = df_full.pval_g1[_df_full_index]
                elseif n_tests == 2
                    pvals_for_acat = df_full.pval_g2[_df_full_index]
                end
                if _args_dtss_weight
                    exp_weight_val = 5e-6
                    @runif n_tests == 1 _df_tops.pval_g1_acat[i] = ACATest(pvals_for_acat, exp.(.-abs.(exp_weight_val * df_full.start_distance[_df_full_index])); is_check=false)
                    @runif n_tests == 2 _df_tops.pval_g2_acat[i] = ACATest(pvals_for_acat, exp.(.-abs.(exp_weight_val * df_full.start_distance[_df_full_index])); is_check=false)
                else
                    @runif n_tests == 1 _df_tops.pval_g1_acat[i] = ACATest(pvals_for_acat; is_check=false)
                    @runif n_tests == 2 _df_tops.pval_g2_acat[i] = ACATest(pvals_for_acat; is_check=false)
                end
            end
            if multiple_testing_method == "beta_approx"
                append_top_summary!(df_full[_df_full_index, :], _df_tops, i, n_tests)
                if n_tests == 1
                    r2_nominal = abs2(_df_perm.X1[i])
                elseif n_tests == 2
                    r2_nominal = abs2(_df_perm.X2[i])
                    absr_perm = _df_perm[i, ((2-1)+6):3:size(_df_perm, 2)] |> Vector
                end
                _df_tops[i, ["pval_beta", "beta_shape1", "beta_shape2", "true_dof", "pval_true_dof"]] .= calculate_beta_approx_pval(abs2.(absr_perm), r2_nominal, DOF, 1e-4)
            end
            @runif _args_verbose if i % 10 == 0
                println_to_file(string("  *** Elapsed time (h:m:s:ms): ", format_milliseconds(now() - time_start)), log_file)
                println_to_file(string(to), log_file)
                println()
            end
        end
        @runif !nominal_only | (multiple_testing_method == "acat") begin
            if !isnothing(_args_pheno_group_file)
                _df_tops.group_id .= _gene_annot.group_id
            end
            append!(df_tops, _df_tops)
            append!(df_perm, _df_perm)
        end
        if !_args_write_top
            if chrom != chroms[1]
                wait(_task_write_full_pairs)
            end
            if nrow(df_full) > 0
                task_df_full = copy(df_full)
                task_chrom = chrom
                _task_write_full_pairs = @spawn begin
                    task_cols_float = [task_df_full[1, x] isa AbstractFloat for x in range(1, ncol(task_df_full))]
                    task_df_full[:, task_cols_float] .= round.(task_df_full[:, task_cols_float], sigdigits=6)
                    task_df_full.af .= round.(task_df_full.af, digits=3)
                    if isnothing(_args_output_format)
                        chrom_full_out_file = joinpath(_args_output_dir, string(_args_out_prefix, ".cis_qtl_pairs.", task_chrom, ".txt.gz"))
                        @runif _args_use_gzip chrom_full_out_file = replace(chrom_full_out_file, r".gz$" => "")
                        CSV.write(chrom_full_out_file, task_df_full, delim="\t", compress=!_args_use_gzip)
                        @runif _args_use_gzip run(`gzip -f $chrom_full_out_file`; wait=chrom == chroms[end])
                    else
                        if _args_output_format == "jld"
                            chrom_full_out_file = joinpath(_args_output_dir, string(_args_out_prefix, ".cis_qtl_pairs.", task_chrom, ".jld"))
                            save(chrom_full_out_file, "data", task_df_full)
                        elseif _args_output_format == "arrow"
                            chrom_full_out_file = joinpath(_args_output_dir, string(_args_out_prefix, ".cis_qtl_pairs.", task_chrom, ".arrow"))
                            Arrow.write(chrom_full_out_file, task_df_full)
                        elseif _args_output_format == "arrow_zstd"
                            chrom_full_out_file = joinpath(_args_output_dir, string(_args_out_prefix, ".cis_qtl_pairs.", task_chrom, ".arrow"))
                            Arrow.write(chrom_full_out_file, task_df_full, compress=:zstd)
                        end
                    end
                end
            end
            if chrom == chroms[end]
                wait(_task_write_full_pairs)
            end
        end
        @runif !nominal_only | (multiple_testing_method == "acat") begin
            cols_float = [_df_tops[1, x] isa AbstractFloat for x in range(1, ncol(_df_tops))]
            _df_tops[:, cols_float] .= round.(_df_tops[:, cols_float], sigdigits=6)
            cols_float = [_df_perm[1, x] isa AbstractFloat for x in range(1, ncol(_df_perm))]
            _df_perm[:, cols_float] .= round.(_df_perm[:, cols_float], sigdigits=6)
            if length(_args_chrom) > 0
                CSV.write(joinpath(_args_output_dir, string(_args_out_prefix, ".cis_qtl.", chrom, ".txt")), _df_tops, delim="\t")
                CSV.write(joinpath(_args_output_dir, string(_args_out_prefix, ".perm.", chrom, ".txt")), _df_perm, delim="\t")
            else
                is_append = chrom != chroms[1]
                if !isnothing(_args_pheno_group_file)
                    CSV.write(joinpath(_args_output_dir, string(_args_out_prefix, ".cis_qtl.detail.txt.gz")), _df_tops, delim="\t", compress=true, append=is_append)
                else
                    CSV.write(joinpath(_args_output_dir, string(_args_out_prefix, ".cis_qtl.txt.gz")), _df_tops, delim="\t", compress=true, append=is_append)
                end
                CSV.write(joinpath(_args_output_dir, string(_args_out_prefix, ".perm.txt.gz")), _df_perm, delim="\t", compress=true, append=is_append)
            end
        end
        println_to_file(string("+++ Total elapsed time (h:m:s:ms): ", format_milliseconds(now() - time_start)), log_file)
        if _args_verbose
            println_to_file(string(to), log_file)
            println()
        end
    end
    @runif multiple_testing_method == "beta_approx" if length(_args_chrom) == 0
        df_tops_mt = df_tops
        pval_mt = df_tops_mt.pval_beta
        if isnothing(_args_storey_lambda)
            qval_mt = MultipleTesting.adjust(pval_mt, BenjaminiHochbergAdaptive(Storey()))
        else
            qval_mt = MultipleTesting.adjust(pval_mt, BenjaminiHochbergAdaptive(Storey(_args_storey_lambda)))
        end
        if sum(qval_mt .<= _args_fdr) > 0
            set0_indices = findall(qval_mt .<= _args_fdr)
            set1_indices = findall(qval_mt .> _args_fdr)
            pthreshold = (sort(df_tops_mt.pval_beta[set1_indices])[1] - sort(-1.0 * df_tops_mt.pval_beta[set0_indices])[1]) / 2
            @runif n_tests == 1 df_tops_mt.pval_g1_threshold .= quantile.(Beta.(df_tops_mt.beta_shape1, df_tops_mt.beta_shape2), pthreshold)
            @runif n_tests == 2 df_tops_mt.pval_g2_threshold .= quantile.(Beta.(df_tops_mt.beta_shape1, df_tops_mt.beta_shape2), pthreshold)
        end
        if n_tests == 1
            df_tops_mt.qval_g1 .= qval_mt
        elseif n_tests == 2
            df_tops_mt.qval_g2 .= qval_mt
        end
        cols_float = [df_tops_mt[1, x] isa AbstractFloat for x in range(1, ncol(df_tops_mt))]
        df_tops_mt[:, cols_float] = round.(df_tops_mt[:, cols_float], sigdigits=6)
        CSV.write(joinpath(_args_output_dir, string(_args_out_prefix, ".cis_qtl.txt.gz")), df_tops_mt, delim="\t", compress=true)
        n_significant_phenotypes = sum((qval_mt .< FloatT(_args_fdr)) .& (df_tops_mt[:, ["pval_g1", "pval_g2"][n_tests]] .< df_tops_mt[:, ["pval_g1_threshold", "pval_g2_threshold"][n_tests]]))
        logtxt = string("  *** ", n_significant_phenotypes, " out of ", length(qval_mt), " tested phenotypes with significant cis-QTL.")
        println_to_file(logtxt, log_file)
    end
    @runif multiple_testing_method == "acat" if length(_args_chrom) == 0
        df_tops_mt = df_tops
        if n_tests == 1
            pval_mt = df_tops_mt.pval_g1_acat
        elseif n_tests == 2
            pval_mt = df_tops_mt.pval_g2_acat
        end
        df_tops_mt = df_tops
        if isnothing(_args_storey_lambda)
            qval_mt = MultipleTesting.adjust(pval_mt, BenjaminiHochberg())
        else
            qval_mt = MultipleTesting.adjust(pval_mt, BenjaminiHochbergAdaptive(Storey(_args_storey_lambda)))
        end
        if n_tests == 1
            df_tops_mt.qval_g1 .= qval_mt
        elseif n_tests == 2
            df_tops_mt.qval_g2 .= qval_mt
        end
        cols_float = [df_tops_mt[1, x] isa AbstractFloat for x in range(1, ncol(df_tops_mt))]
        df_tops_mt[:, cols_float] = round.(df_tops_mt[:, cols_float], sigdigits=6)
        CSV.write(joinpath(_args_output_dir, string(_args_out_prefix, ".cis_qtl.txt.gz")), df_tops_mt, delim="\t", compress=true)
        n_significant_phenotypes = sum(qval_mt .< FloatT(_args_fdr))
        logtxt = string("  *** ", n_significant_phenotypes, " out of ", length(qval_mt), " tested phenotypes with significant cis-QTL.")
        println_to_file(logtxt, log_file)
    end
    @runif multiple_testing_method == "clipper" if length(_args_chrom) == 0
        if !isnothing(_args_pheno_group_file)
            reduced_df_tops = DataFrames.combine(groupby(df_tops, :group_id)) do grouped
                min_row_index = first_nonnan_argmin(grouped.pval_g1)
                return grouped[min_row_index, :]
            end
            reduced_df_tops.group_size .= DataFrames.combine(groupby(df_tops, :group_id), nrow).nrow
            reduced_df_perm = copy(df_perm)
            reduced_df_perm.pheno_id .= df_tops.group_id
            df_perm_gdf = groupby(reduced_df_perm, :pheno_id)
            reduced_df_perm = DataFrames.combine(df_perm_gdf, :pheno_id, valuecols(df_perm_gdf) .=> maximum)
            reduced_df_perm = unique(reduced_df_perm, [:pheno_id])
            df_perm_mt = reduced_df_perm
            df_tops_mt = reduced_df_tops
        else
            df_perm_mt = df_perm
            df_tops_mt = df_tops
        end
        clipper_keep_index = .!isnan.(df_perm_mt[:, 3])
        if n_tests == 1
            df_tops_mt.qval_g1 .= NaN
            if n_perms < 1000
                res_clipper = Clipper(Matrix(df_perm_mt[clipper_keep_index, 3:3]), Matrix(df_perm_mt[clipper_keep_index, 4:end]), analysis="enrichment", procedure="GZ", contrast_score="max", FDR=[FloatT(_args_fdr)])
                qval_mt = res_clipper["q"]
            else
                numsOfPermsMoreSig = sum(Matrix(df_perm_mt[clipper_keep_index, 3:3]) .- Matrix(df_perm_mt[clipper_keep_index, 4:end]) .<= 0, dims=2)
                pval_mt = vec((numsOfPermsMoreSig .+ 1) ./ (n_perms + 1))
                if isnothing(_args_storey_lambda)
                    qval_mt = MultipleTesting.adjust(pval_mt, BenjaminiHochbergAdaptive(Storey()))
                else
                    qval_mt = MultipleTesting.adjust(pval_mt, BenjaminiHochbergAdaptive(Storey(_args_storey_lambda)))
                end
            end
            df_tops_mt.qval_g1[clipper_keep_index] .= qval_mt
            n_significant_phenotypes = sum((df_tops_mt.qval_g1 .< _args_fdr) .& (df_tops_mt.pval_g1 .< df_tops_mt.pval_g1_threshold))
            logtxt = string("  *** ", n_significant_phenotypes, " out of ", sum(clipper_keep_index), " tested phenotypes with significant cis-QTL.")
            println_to_file(logtxt, log_file)
        elseif n_tests == 2
            for i in 2:2
                idx_exp = ((i-1)+3):((i-1)+3)
                idx_back = ((i-1)+6):3:size(df_perm_mt, 2) |> Vector
                if n_perms < 1000
                    res_clipper = Clipper(Matrix(df_perm_mt[clipper_keep_index, idx_exp]), Matrix(df_perm_mt[clipper_keep_index, idx_back]), analysis="enrichment", procedure="GZ", contrast_score="max", FDR=[FloatT(_args_fdr)])
                    qval_mt = res_clipper["q"]
                else
                    numsOfPermsMoreSig = sum(Matrix(df_perm_mt[clipper_keep_index, idx_exp]) .- Matrix(df_perm_mt[clipper_keep_index, idx_back]) .<= 0, dims=2)
                    pval_mt = vec((numsOfPermsMoreSig .+ 1) ./ (n_perms + 1))
                    if isnothing(_args_storey_lambda)
                        qval_mt = MultipleTesting.adjust(pval_mt, BenjaminiHochbergAdaptive(Storey()))
                    else
                        qval_mt = MultipleTesting.adjust(pval_mt, BenjaminiHochbergAdaptive(Storey(_args_storey_lambda)))
                    end
                end
                mt_col_name = ["qval_g1", "qval_g2", "qval_joint"][i]
                mt_threshold_col_name = ["pval_g1_threshold", "pval_g2_threshold", "pval_joint_threshold"][i]
                df_tops_mt[:, mt_col_name] .= NaN
                df_tops_mt[clipper_keep_index, mt_col_name] .= qval_mt
                n_significant_phenotypes = sum((df_tops_mt[:, mt_col_name] .< FloatT(_args_fdr)) .& (df_tops_mt[:, mt_col_name] .< df_tops_mt[:, mt_threshold_col_name]))
                logtxt = string("  *** ", n_significant_phenotypes, " out of ", sum(clipper_keep_index), " tested phenotypes with significant cis-QTL(", ["g1", "g2", "g_joint"][i], ").")
                println_to_file(logtxt, log_file)
            end
        end
        cols_float = [df_tops_mt[1, x] isa AbstractFloat for x in range(1, ncol(df_tops_mt))]
        df_tops_mt[:, cols_float] = round.(df_tops_mt[:, cols_float], sigdigits=6)
        CSV.write(joinpath(_args_output_dir, string(_args_out_prefix, ".cis_qtl.txt.gz")), df_tops_mt, delim="\t", compress=true)
    end
end
