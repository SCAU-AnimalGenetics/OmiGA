```
 * OmiGA: a toolkit for Omics Genetic Analysis
 *
 * Copyright © 2024, Jinyan Teng
 *
 * This file is distributed under the GNU General Public
 * License, Version 3. Please see the file LICENSE for more
 * details.
 *
 * All the files in this project are allowed to be copied, 
 * modified, and distributed for educational, research and 
 * non-profit purposes, without charge and without a written 
 * agreement, provided that this copyright notice are included
 * in all copies. If you intend to use this project for 
 * commercial purposes, kindly contact the author for 
 * authorization prior to use.

 This file contains funtions that were modified from VarianceComponentModels [https://github.com/OpenMendel/VarianceComponentModels.jl]
 To acknowledge the VarianceComponentModels package, please cite the paper (2021): https://doi.org/10.1007/s00439-019-02001-z
```
import VarianceComponentModels.fit_reml!
import VarianceComponentModels.fit_mle!
function TwoVarCompVariateRotate(vcobs::VarianceComponentVariate{T,2}, F::Eigen{T,T,Matrix{T},Vector{T}}) where {T<:AbstractFloat}
  zeroT = zero(T)
  if isa(vcobs.V[2], UniformScaling) ||
     (isdiag(vcobs.V[2]) && norm(diag(vcobs.V[2]) .- one(T)) < 1.0e-8)
    deval = convert(Vector{T}, F.values)
    U = convert(Matrix{T}, F.vectors)
    logdetV2 = zero(T)
  else
    F = eigen(Symmetric(vcobs.V[1]), Symmetric(vcobs.V[2]))
    deval = convert(Vector{T}, F.values)
    U = convert(Matrix{T}, F.vectors)
    logdetV2 = convert(T, logdet(vcobs.V[2]))
  end
  @inbounds @simd for i in eachindex(deval)
    deval[i] = deval[i] > zeroT ? deval[i] : zeroT
  end
  Yrot = transpose(U) * vcobs.Y
  Xrot = isempty(vcobs.X) ? Array{T}(undef, size(Yrot, 1), 0) : transpose(U) * vcobs.X
  VarianceComponentModels.TwoVarCompVariateRotate(Yrot, Xrot, deval, U, logdetV2)
end
function fit_reml!(
  vcmodel::T1,
  vcdata::Union{T2,Array{T2}},
  EA::Eigen{T3,T3,Matrix{T3},Vector{T3}};
  algo::Symbol=:FS,
  qpsolver::Symbol=:Ipopt
) where {
  T1<:VarianceComponentModel,
  T2<:VarianceComponentVariate,
  T3<:AbstractFloat}
  T, d = eltype(vcmodel), length(vcmodel)
  vcaux = VarianceComponentAuxData(vcdata)
  if qpsolver == :Ipopt
    qs = VarianceComponentModels.IpoptSolver(print_level=0)
  elseif qpsolver == :Gurobi
    qs = VarianceComponentModels.GurobiSolver(OutputFlag=0)
  elseif qpsolver == :Mosek
    qs = VarianceComponentModels.MosekSolver(MSK_IPAR_LOG=0)
  end
  if typeof(vcdata) <: AbstractArray
    Q = kron(Matrix{T}(I, d, d), mapreduce(x -> transpose(x.X) * x.X, +, vcdata))
    c = vec(mapreduce(x -> transpose(x.X) * x.Y, +, vcdata))
  else
    Q = kron(Matrix{T}(I, d, d), transpose(vcdata.X) * vcdata.X)
    c = vec(transpose(vcdata.X) * vcdata.Y)
  end
  qpsol = VarianceComponentModels.quadprog(-c, Q, vcmodel.A, vcmodel.sense, vcmodel.b,
    vcmodel.lb, vcmodel.ub, qs)
  if qpsol.status ≠ :Optimal
    println("Error in quadratic programming $(qpsol.status)")
  end
  copyto!(vcmodel.B, qpsol.sol)
  resdata = deepcopy(vcdata)
  if typeof(vcdata) <: AbstractArray
    for i in eachindex(resdata)
      residual!(resdata[i].Y, vcmodel, vcdata[i])
      resdata[i].X = zeros(T, size(resdata[i].Y, 1), 0)
    end
  else
    residual!(resdata.Y, vcmodel, vcdata)
    resdata.X = zeros(T, size(resdata.Y, 1), 0)
  end
  resdatarot = TwoVarCompVariateRotate(resdata, EA)
  resmodel = deepcopy(vcmodel)
  resmodel.B = zeros(T, 0, d)
  if algo == :FS
    _, _, Σse, Σcov, = mle_fs!(resmodel, resdatarot)
  elseif algo == :MM
    _, _, Σse, Σcov, = mle_mm!(resmodel, resdatarot)
  end
  copyto!(vcmodel.Σ[1], resmodel.Σ[1]), copyto!(vcmodel.Σ[2], resmodel.Σ[2])
  vcdatarot = TwoVarCompVariateRotate(vcdata, EA)
  update_meanparam!(vcmodel, vcdatarot, qs, vcaux)
  Bcov = inv(fisher_B(vcmodel, vcdatarot, vcaux))
  Bse = similar(vcmodel.B)
  copyto!(Bse, sqrt.(diag(Bcov)))
  VarianceComponentModels.logpdf(vcmodel, vcdatarot), vcmodel, (Σse[1], Σse[2]), Σcov, Bse, Bcov
end
function fit_mle!(
  vcmodel::T1,
  vcdata::Union{T2,Array{T2}},
  EA::Eigen{T3,T3,Matrix{T3},Vector{T3}};
  algo::Symbol=:FS
) where {T1<:VarianceComponentModel,T2<:VarianceComponentVariate,T3<:AbstractFloat}
  vcdatarot = TwoVarCompVariateRotate(vcdata, EA)
  if algo == :FS
    return mle_fs!(vcmodel, vcdatarot)
  elseif algo == :MM
    return mle_mm!(vcmodel, vcdatarot)
  end
end
