```
 * OmiGA: a toolkit for Omics Genetic Analysis
 *
 * Developed by Jiajian Chen
 *
 * This file is distributed under the GNU General Public
 * License, Version 3. Please see the file LICENSE for more
 * details.
 *
 * All the files in this project are allowed to be copied, 
 * modified, and distributed for educational, research and 
 * non-profit purposes, without charge and without a written 
 * agreement, provided that this copyright notice are included
 * in all copies. If you intend to use this project for 
 * commercial purposes, kindly contact the author for 
 * authorization prior to use.
```
export SNP_matrix
struct SNP_matrix <: AbstractMatrix{Int8}
    data::Matrix{UInt8}
    columncounts::Matrix{Int}
    rowcounts::Matrix{Int}
    m::Int
end
function SNP_matrix(bednm::AbstractString, m::Integer, chooseID::Union{Nothing,AbstractArray{AbstractString}}=nothing, args...; kwargs...)
    data = open(bednm, args...; kwargs...) do io
        read(io, UInt16) == 0x1b6c
        read(io, UInt8) == 0x01
        Mmap.mmap(io)
    end
    drows = (m + 3) >> 2
    n, r = divrem(length(data), drows)
    if isnothing(chooseID)
        SNP_matrix(reshape(data, (drows, n)), zeros(Int, (3, n)), zeros(Int, (3, m)), m)
    else
        @views IDname = CSV.read(string(splitext(bednm)[1], ".fam"), DataFrame, header=false)[:, 2]
        positionID = findall(in(chooseID), IDname)
        @views SNP_matrix(reshape(data, (drows, n)), zeros(Int, (4, n)), zeros(Int, (4, m)), m)[positionID, :]
    end
end
SNP_matrix(nm::AbstractString, args...; kwargs...) = SNP_matrix(nm, countlines(string(splitext(nm)[1], ".fam")), nothing, args...; kwargs...)
SNP_matrix(nm::AbstractString, m::Integer, args...; kwargs...) = SNP_matrix(nm, countlines(string(splitext(nm)[1], ".fam")), nothing, args...; kwargs...)
SNP_matrix(nm::AbstractString, chooseID::AbstractArray{AbstractString}, args...; kwargs...) = SNP_matrix(nm, countlines(string(splitext(nm)[1], ".fam")), chooseID::AbstractArray{AbstractString}, args...; kwargs...)
Base.size(f::SNP_matrix) = f.m, size(f.data, 2)
@inline function Base.getindex(f::SNP_matrix, i::Integer, j::Integer)
    @boundscheck checkbounds(f, i, j)
    ip3 = i + 3
    if ((f.data[ip3>>2, j] >> ((ip3 & 0x03) << 1)) & 0x03) == 0x00
        2
    elseif ((f.data[ip3>>2, j] >> ((ip3 & 0x03) << 1)) & 0x03) == 0x03
        0
    elseif ((f.data[ip3>>2, j] >> ((ip3 & 0x03) << 1)) & 0x03) == 0x02
        1
    elseif ((f.data[ip3>>2, j] >> ((ip3 & 0x03) << 1)) & 0x03) == 0x01
        error("Program abort! There are missing values in the genotype matrix!")
    end
end
function _counts(s::SNP_matrix, dims::Integer)
    if isone(dims)
        cc = (typeof(s) == SNP_matrix) ? s.columncounts : zeros(Int, (4, size(s, 2)))
        if all(iszero, cc)
            m, n = size(s)
            @inbounds for j in 1:n
                for i in 1:m
                    cc[s[i, j]+1, j] += 1
                end
            end
        end
        return cc
    elseif dims == 2
        rc = (typeof(s) == SnpArray) ? s.rowcounts : zeros(Int, (4, size(s, 1)))
        if all(iszero, rc)
            m, n = size(s)
            @inbounds for j in 1:n
                for i in 1:m
                    rc[s[i, j]+1, i] += 1
                end
            end
        end
        return rc
    else
        throw(ArgumentError("counts(s::SnpArray, dims=k) only defined for k = 1 or 2"))
    end
end
_counts(s::SNP_matrix, ::Colon) = sum(_counts(s, 1), dims=2)
function maf!(out::AbstractVector{T}, s::SNP_matrix) where {T<:AbstractFloat}
    cc = _counts(s, 1)
    @inbounds for j in 1:size(s, 2)
        out[j] = (cc[2, j] + 2cc[3, j]) / 2(cc[1, j] + cc[2, j] + cc[3, j])
        (out[j] > 0.5) && (out[j] = 1 - out[j])
    end
    out
end
maf(s::SNP_matrix) = maf!(Vector{Float64}(undef, size(s, 2)), s)
function af!(out::AbstractVector{T}, s::SNP_matrix) where {T<:AbstractFloat}
    cc = _counts(s, 1)
    @inbounds for j in 1:size(s, 2)
        out[j] = (cc[2, j] + 2cc[3, j]) / 2(cc[1, j] + cc[2, j] + cc[3, j])
    end
    out
end
af(s::SNP_matrix) = af!(Vector{Float64}(undef, size(s, 2)), s)
function het!(out::AbstractVector{T}, s::SNP_matrix) where {T<:AbstractFloat}
    cc = _counts(s, 1)
    @inbounds for j in 1:size(s, 2)
        out[j] = 2cc[2, j] / 2(cc[1, j] + cc[2, j] + cc[3, j])
    end
    out
end
het(s::SNP_matrix) = het!(Vector{Float64}(undef, size(s, 2)), s)
