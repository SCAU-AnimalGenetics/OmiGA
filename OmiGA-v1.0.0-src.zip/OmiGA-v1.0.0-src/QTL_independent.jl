```
 * OmiGA: a toolkit for Omics Genetic Analysis
 *
 * Copyright © 2024, Jinyan Teng
 *
 * This file is distributed under the GNU General Public
 * License, Version 3. Please see the file LICENSE for more
 * details.
 *
 * All the files in this project are allowed to be copied, 
 * modified, and distributed for educational, research and 
 * non-profit purposes, without charge and without a written 
 * agreement, provided that this copyright notice are included
 * in all copies. If you intend to use this project for 
 * commercial purposes, kindly contact the author for 
 * authorization prior to use.
```
function runOmiGA_independent(_struct_PHENO, _struct_GENO, _struct_KIN, _struct_COVAR, _struct_PRIOR_HerB; _struct_DOM::Union{Nothing,Dominance}=nothing, _struct_ITERM::Union{Nothing,InteractionTerm}=nothing)
    phenotype = _struct_PHENO.phenotype
    pheno_annotation = _struct_PHENO.annotation
    X_MME = _struct_COVAR.X_MME
    if !isnothing(_struct_PRIOR_HerB)
        prior_h2 = _struct_PRIOR_HerB.h2
        prior_B = _struct_PRIOR_HerB.B
    else
        prior_h2 = prior_B = nothing
    end
    snp_annotation = _struct_GENO.annotation
    if length(_args_cis_output) == 1
        df_tops_mt = CSV.File(_args_cis_output[1], header=true, buffer_in_memory=true) |> DataFrame
        if !any(.!isnothing.(match.(r"qval", names(df_tops_mt))))
            error("qval column must be provided in cis-file!")
        end
    else
        error("Please provide correct cis-file!")
    end
    non_pcols = isnothing.(match.(r"pval|qval", names(df_tops_mt)))
    df_tops_mt[!, names(df_to_float32!(df_tops_mt[:, non_pcols]))] = df_to_float32!(df_tops_mt[:, non_pcols])
    df_tops_mt = df_tops_mt[findall(df_tops_mt.pheno_id .∈ (pheno_annotation.pheno_id,)), :]
    qtl_map_algo = _args_qtl_map_algo
    qtl_map_model = df_tops_mt.map_model[1]
    n_samples = _struct_GENO.n_samples
    _n, _X_c = size(X_MME)
    if !isnothing(_args_pheno_group_file) & _args_est_ind_h2
        est_ind_h2 = false
        @info "--est-ind-h2 do not supported for group cis-QTL!"
    else
        est_ind_h2 = _args_est_ind_h2
    end
    if isnothing(_args_h2_algo)
        h2_algo = "idul"
    else
        h2_algo = _args_h2_algo
    end
    n_tests = 1
    n_grms = 1
    if qtl_map_model == "a+A"
        glo_EA = _struct_KIN.EA
        genotype = _struct_GENO.genotype
        if isnothing(prior_h2) & (h2_algo == "minmax")
            glo_KS = _struct_KIN.GRM
        end
        glo_h2_model = "Ag"
    end
    if qtl_map_model == "d+D"
        glo_EA = _struct_KIN.domEA
        genotype = _struct_DOM.genotype
        if isnothing(prior_h2) & (h2_algo == "minmax")
            glo_KS = _struct_KIN.domGRM
        end
        glo_h2_model = "Dg"
    end
    if qtl_map_model == "d+A"
        glo_EA = _struct_KIN.EA
        genotype = _struct_DOM.genotype
        if isnothing(prior_h2) & (h2_algo == "minmax")
            glo_KS = _struct_KIN.GRM
        end
        glo_h2_model = "Ag"
    end
    if qtl_map_model == "a+d+A+D"
        genotype = _struct_GENO.genotype
        domGenotype = _struct_DOM.genotype
        n_tests = 2
        n_grms = 2
        glo_h2_model = "Ag+Dg"
    end
    if qtl_map_model == "d+A+D"
        genotype = _struct_DOM.genotype
        n_grms = 2
        glo_h2_model = "Ag+Dg"
    end
    if !_args_nominal_only
        permutation_method = _args_multiple_testing
        n_perms = _args_n_perms
        if !isnothing(permutation_method)
            if isnothing(n_perms)
                error("--permutations must be specified.")
            end
        end
        if isnothing(permutation_method)
            if n_tests == 1
                if n_samples < 450
                    permutation_method = "standard_fast"
                    if isnothing(_args_n_perms)
                        n_perms = 1000
                    end
                else
                    permutation_method = "clipper"
                    if isnothing(_args_n_perms)
                        n_perms = 100
                    end
                end
            elseif n_tests == 2
                permutation_method = "standard_fast"
                if isnothing(_args_n_perms)
                    n_perms = 1000
                end
            else
                permutation_method = "standard"
                if isnothing(_args_n_perms)
                    n_perms = 1000
                end
            end
        end
        if (n_tests == 2) | _args_preadj_covar
            Xt_X = X_MME' * X_MME
        end
        if permutation_method in ["standard", "standard_fast", "clipper"]
            if permutation_method == "standard_fast"
                y_perms = fill(NAN, n_samples, n_perms)
                absr_perm = fill(NAN, n_perms)
                perm_phen_type = "raw"
                perm_geno_type = "residualized"
            end
            if permutation_method == "clipper"
                absr_perm = fill(NAN, n_perms)
                perm_phen_type = "residualized"
                perm_geno_type = "residualized"
            end
            if (permutation_method == "standard") & (qtl_map_algo == "idul")
                y_perms = fill(NAN, n_samples, n_perms)
                absr_perm = fill(NAN, n_perms)
                perm_phen_type = "raw"
                perm_geno_type = "raw"
            end
        end
        if (n_tests == 2) & (permutation_method == "standard") & (qtl_map_algo == "idul")
            _xQ_c = size(xQ, 2)
            _c2 = _xQ_c + 2
            xW0 = [ones(FloatT, _n, 2) xQ]
            xtx_init = matmul(xW0', xW0)
            xty_init = zeros(FloatT, _c2, n_perms)
        end
    else
        n_perms = 0
    end
    _args_PreV = n_grms == 2
    if _args_PreV
        path_partialv = _args_path_partialv
        if !isnothing(path_partialv)
            _struct_PartialV = load(path_partialv)["data"]
        else
            error("--path-pre-eigen must be specified for QTL mapping models with two GRMs!")
        end
        if isnothing(prior_h2)
            error("--her-output must be specified for QTL mapping models with two GRMs!")
        end
    end
    if ((isnothing(prior_h2) & (h2_algo == "idul")) | (qtl_map_algo == "idul")) & (n_grms == 1)
        if _args_preadj_covar
            xQ = glo_EA.vectors' * X_MME[:, 1:1]
        else
            xQ = glo_EA.vectors' * X_MME
        end
    end
    if (qtl_map_algo == "idul") & (qtl_map_model in ["d+A+D"])
        xQ = similar(X_MME)
        yQ = zeros(FloatT, n_samples)
        cGRM = zeros(FloatT, n_samples, n_samples)
        GRM64 = zeros(Float64, n_samples, n_samples)
        glo_EA = Eigen{FloatT,FloatT,Matrix{FloatT},Vector{FloatT}}(zeros(FloatT, n_samples), zeros(FloatT, n_samples, n_samples))
        Inds_AD_vecs = CartesianIndices(glo_EA.vectors)
    end
    if qtl_map_algo == "standard"
        Vi = zeros(FloatT, _n, _n)
        Di = Diagonal(zeros(FloatT, _n, _n))
        EAvec_Di = zeros(FloatT, _n, _n)
        if qtl_map_model in ["a+A+D", "d+A+D", "a+d+A+D"]
            EAvec = zeros(FloatT, _n, _n)
        end
    end
    if (qtl_map_algo == "standard") & (h2_algo in ["minmax", "em_aireml"])
        In = diagm(ones(FloatT, _n))
        if n_grms == 1
            glo_KSs = [glo_KS, In]
        end
        if (n_grms == 2) & (glo_h2_model == "Ag+Dg")
            glo_KSs = [_struct_KIN.GRM, _struct_KIN.domGRM, In]
        end
        glo_n_cmp = length(glo_KSs)
    end
    if est_ind_h2 | (qtl_map_algo == "standard")
        _Py = zeros(FloatT, _n)
        _P = zeros(FloatT, _n, _n)
        _PA = zeros(FloatT, _n, _n)
        _Vi = zeros(FloatT, _n, _n)
        _cVi = zeros(FloatT, _n, _n)
        _Di = Diagonal(zeros(FloatT, _n, _n))
        _EAvec_Di = zeros(FloatT, _n, _n)
        _EAvec = zeros(FloatT, _n, _n)
        @runif (qtl_map_algo == "standard") & (h2_algo == "em_aireml") glo_Hi = zeros(FloatT, glo_n_cmp, glo_n_cmp)
        cGRM = zeros(FloatT, _n, _n)
        GRM64 = zeros(Float64, _n, _n)
    end
    df_inds = DataFrame()
    sig_df_tops = df_tops_mt[df_tops_mt.qval_g1.<_args_fdr, :]
    if isnothing(_args_pheno_group_file)
        sig_genes_index = pheno_annotation.pheno_id .∈ (sig_df_tops.pheno_id,)
        pheno_annotation.index = 1:nrow(pheno_annotation)
        sig_gene_annot = pheno_annotation[sig_genes_index, :]
        sig_phenotype = phenotype[:, sig_genes_index]
    else
        sig_genes_index = pheno_annotation.group_id .∈ (sig_df_tops.group_id,)
        pheno_annotation.index = 1:nrow(pheno_annotation)
        sig_gene_annot = pheno_annotation[sig_genes_index, :]
        sig_phenotype = phenotype[:, sig_genes_index]
    end
    chroms = intersect(string.(unique(pheno_annotation.chrom)), string.(unique(snp_annotation.chromosome)))
    _task_write_full_pairs = @task @info "Using Tasks"
    for chrom in chroms
        snp_index_chrom = snp_annotation.chromosome .== chrom
        _gene_annot = sig_gene_annot[sig_gene_annot.chrom.==chrom, :]
        _snp_annot = snp_annotation[snp_annotation.chromosome.==chrom, :]
        if !isnothing(_args_pheno_group_file)
            _n_genes = sum(_gene_annot.group_id_first)
        else
            _n_genes = length(_gene_annot.pheno_id)
        end
        _df_inds = DataFrame()
        df_full = DataFrame()
        _2p = 2 .* snp_annotation.af[snp_index_chrom]
        _2pq = _2p .* (1 .- snp_annotation.af[snp_index_chrom])
        if is_sample_byrow
            _2p = _2p' |> Matrix
            _2pq = _2pq' |> Matrix
            chrom_genotype = similar(genotype[:, snp_index_chrom], FloatT)
            chrom_genotype .= genotype[:, snp_index_chrom]
            if qtl_map_model in ["d+D", "d+A", "d+A+D"]
                chrom_genotype .-= _2pq
            else
                chrom_genotype .-= _2p
            end
            if (_args_run_mode in ["cis_independent"]) & (qtl_map_algo == "idul") & (n_grms == 1)
                chrom_SQ = glo_EA.vectors' * chrom_genotype
                chrom_yQ = glo_EA.vectors' * phenotype[:, _gene_annot.index]
            end
        else
            chrom_genotype = similar(genotype[snp_index_chrom, :], FloatT)
            chrom_genotype .= genotype[snp_index_chrom, :]
            if qtl_map_model in ["d+D", "d+A", "d+A+D"]
                chrom_genotype .-= _2pq
            else
                chrom_genotype .-= _2p
            end
        end
        _snp_annot.reindex = 1:size(_snp_annot, 1)
        if !isnothing(_args_pheno_group_file)
            cis_genotype = nothing
            cis_genotype_iterm = nothing
            cis_genotype_2nd = nothing
        end
        GC.gc()
        time_start = now()
        println_to_file(string("Chromosome: ", chrom, ", start at: ", time_start), log_file)
        @runif !isnothing(_args_pheno_group_file) for i in 1:_n_genes
            println_to_file(string("GENE: ", i, "/", _n_genes), log_file)
            gene = unique(_gene_annot.group_id)[i]
            group_pheno_ids = _gene_annot.pheno_id[_gene_annot.group_id.==gene]
            group_size = length(group_pheno_ids)
            index_tested_gene = findfirst(sig_df_tops.group_id .== gene)
            cissnps_annot, n_cis_snps = get_cis_snp_info(_gene_annot, _snp_annot, group_pheno_ids[1], _args_cis_window)
            begin
                if is_sample_byrow
                    if qtl_map_algo == "standard"
                        cis_genotype = chrom_genotype[:, cissnps_annot.reindex]
                    elseif qtl_map_algo == "idul"
                        if n_grms == 1
                            cis_genotype = chrom_SQ[:, cissnps_annot.reindex]
                            @runif _args_run_mode == "cis_interaction" cis_genotype_iterm = chrom_SIQ[:, cissnps_annot.reindex]
                        elseif n_grms == 2
                            cis_genotype = chrom_genotype[:, cissnps_annot.reindex]
                        end
                    end
                else
                    cis_genotype = chrom_genotype[cissnps_annot.reindex, :]
                end
                if (qtl_map_model in ["a+d+A+D"])
                    cis_genotype_2nd = chrom_domGenotype[cissnps_annot.reindex, :]
                end
            end
            begin
                df_test = zeros(FloatT, n_cis_snps, 3)
                _df_full = DataFrame([
                    "pheno_id" => gene,
                    "variant_id" => cissnps_annot.variant, "rank" => 1,
                    "snp_r" => NAN,
                ])
                if n_tests == 2
                    _df_full = hcat(_df_full, DataFrame(df_test[:, 1:end-1], Symbol.(["beta_g1", "beta_se_g1", "pval_g1", "beta_g2", "beta_se_g2", "pval_g2"])))
                    if USE_Float32
                        _df_full.pval_g1 = Float64.(_df_full.pval_g1)
                        _df_full.pval_g2 = Float64.(_df_full.pval_g2)
                    end
                end
                if n_tests == 1
                    _df_full = hcat(_df_full, DataFrame(df_test, Symbol.(["beta_g1", "beta_se_g1", "pval_g1"])))
                    if USE_Float32
                        _df_full.pval_g1 = Float64.(_df_full.pval_g1)
                    end
                end
            end
            if (qtl_map_algo == "idul") & (qtl_map_model in ["d+A+D"])
                if !isnothing(prior_h2)
                    index_prior_h2 = findfirst(prior_h2.pheno_id .== gene)
                    Σ_i = [prior_h2.glo_vg1[index_prior_h2], prior_h2.glo_vg2[index_prior_h2], prior_h2.glo_ve[index_prior_h2]]
                    glo_vc_B = vec(prior_B[index_prior_h2, 3:end])
                end
                ratio = maximum([Σ_i[1] / Σ_i[2], Σ_i[2] / Σ_i[1]])
                println("Ratio between vg1 and vg2: ", ratio)
                if ratio > maximum(_struct_PartialV.vec_ratio)
                    if ratio > 1000
                        if Σ_i[2] > Σ_i[1]
                            glo_EA.vectors .= _struct_KIN.domEA.vectors
                            glo_EA.values .= _struct_KIN.domEA.values * Σ_i[2]
                        else
                            glo_EA.vectors .= _struct_KIN.EA.vectors
                            glo_EA.values .= _struct_KIN.EA.values * Σ_i[1]
                        end
                    else
                        cGRM .= Σ_i[1] * _struct_KIN.GRM + Σ_i[2] * _struct_KIN.domGRM
                        glo_EA = eigen!(cGRM)
                    end
                else
                    ratio_index = argmin(abs.(ratio .- _struct_PartialV.vec_ratio)) * 2
                    if Σ_i[1] >= Σ_i[2]
                        ratio_index -= 1
                    end
                    j = ratio_index
                    range_inds = _n*(j-1)+1:_n*j
                    vals_inds = CartesianIndices((range_inds,))
                    vecs_inds = CartesianIndices((range_inds, 1:_n))
                    copyto!(glo_EA.vectors, Inds_AD_vecs, _struct_PartialV.eigvecs, vecs_inds)
                    glo_EA.values .= _struct_PartialV.eigvals[vals_inds] * sum(Σ_i[1:2])
                end
                cis_genotype .= glo_EA.vectors' * cis_genotype
                mul!(xQ, glo_EA.vectors', X_MME)
            end
            lead_variant = sig_df_tops.variant_id[index_tested_gene]
            index_lead_variant = findfirst(cissnps_annot.variant .== lead_variant)
            index_lead_variant_list = [index_lead_variant]
            if qtl_map_algo == "standard"
                lead_variant_and_X_MME = hcat(cis_genotype[index_lead_variant, :], X_MME)
            elseif qtl_map_algo == "idul"
                lead_variant_and_X_MME = hcat(cis_genotype[:, index_lead_variant], xQ)
            end
            ranki = 1
            summary_test_minp = [NAN, NAN, NAN]
            summary_test_minp_df = DataFrame(reshape(repeat(summary_test_minp, group_size), group_size, :), :auto)
            pval_g1_threshold_group = repeat([NaN], group_size)
            index_lead_variant_group = repeat([index_lead_variant], group_size)
            snp_h2 = snp_h2_se = acc_h2 = acc_h2_se = NAN
            while true
                println("Forward rank: ", ranki)
                for group_pheno_i in 1:group_size
                    pheno_id = group_pheno_ids[group_pheno_i]
                    chrom_index_tested_pheno = findfirst(_gene_annot.pheno_id .== pheno_id)
                    global_index_tested_pheno = _gene_annot.index[_gene_annot.pheno_id.==pheno_id]
                    yQ = chrom_yQ[:, chrom_index_tested_pheno]
                    if qtl_map_algo == "idul"
                        idul_prior_index = sample(1:n_cis_snps, 10)
                        df_subs = fill(NAN, 10, 3 * n_tests + 2)
                        idul_assoc_test_plus!(df_subs, cis_genotype[:, idul_prior_index], yQ, lead_variant_and_X_MME, glo_EA.values; max_iter=_args_idul_max_iter, thre=FloatT.(_args_idul_converge), return_detail=true, is_calcu_pv=false)
                        init_eta = Statistics.mean(df_subs[.!isnan.(df_subs[:, 2]), 2])
                        @runif isnan(init_eta) init_eta = FloatT(1e-5)
                        if !_args_exact_map
                            idul_assoc_test_approx!(df_test, cis_genotype, yQ, lead_variant_and_X_MME, glo_EA.values; init_eta=init_eta, is_calcu_pv=false)
                        else
                            idul_assoc_test_plus!(df_test, cis_genotype, yQ, lead_variant_and_X_MME, glo_EA.values; max_iter=_args_idul_max_iter, thre=FloatT.(_args_idul_converge), init_eta=init_eta, is_calcu_pv=false)
                        end
                    end
                    index_lead_variant = first_nonnan_argmax(df_test[:, 3])
                    @runif index_lead_variant == -1 break
                    index_lead_variant_group[group_pheno_i] = index_lead_variant
                    summary_test_minp .= df_test[index_lead_variant, :]
                    summary_test_minp[3] = ccdf(FDist(1, _n - size(lead_variant_and_X_MME, 2) - 1), summary_test_minp[3])
                    summary_test_minp_df[group_pheno_i, :] .= summary_test_minp
                    pval_g1_threshold = sig_df_tops.pval_g1_threshold[index_tested_gene]
                    if !_args_nominal_only
                        Q, _dof = residualizer(glo_EA.vectors * lead_variant_and_X_MME)
                        QQt = Q * Q'
                        cis_genotype .= chrom_genotype[:, cissnps_annot.reindex]
                        get_matrix_resid!(cis_genotype, QQt, return_std=false)
                        if permutation_method == "standard_fast"
                            y_perms .= phenotype[:, global_index_tested_pheno] .- Statistics.mean(phenotype[:, global_index_tested_pheno])
                            Random.seed!(_args_seed)
                            @inbounds @views for perm_i in 1:n_perms
                                shuffle!(y_perms[:, perm_i])
                            end
                            get_matrix_resid!(y_perms, QQt, return_std=false)
                            fast_linear_permutation_test!(cis_genotype, y_perms, absr_perm, byrow=is_sample_byrow)
                        elseif permutation_method == "clipper"
                            pheno_perm = get_matrix_resid(phenotype[:, global_index_tested_pheno], QQt, return_std=false)
                            fast_permutation_clipper!(absr_perm, cis_genotype, pheno_perm, n_perms; byrow=is_sample_byrow)
                        end
                        pval_g1_threshold = sort(get_approx_p_from_r(absr_perm, _dof))[ceil(Int, n_perms * _args_fdr)]
                    end
                    pval_g1_threshold_group[group_pheno_i] = pval_g1_threshold
                    if n_grms < 2
                        cis_genotype .= chrom_SQ[:, cissnps_annot.reindex]
                    else
                        cis_genotype .= glo_EA.vectors' * chrom_genotype[:, cissnps_annot.reindex]
                    end
                end
                if minimum(summary_test_minp_df[:, 3]) <= minimum(pval_g1_threshold_group)
                    ranki = ranki + 1
                    index_lead_variant = index_lead_variant_group[argmin(summary_test_minp_df[:, 3])]
                    push!(index_lead_variant_list, index_lead_variant)
                    lead_variant_and_X_MME = hcat(cis_genotype[:, index_lead_variant], lead_variant_and_X_MME)
                else
                    break
                end
            end
            n_forward_variants = length(index_lead_variant_list)
            if n_forward_variants > 1
                backward_X_MME = fill(NAN, _n, size(lead_variant_and_X_MME, 2) - 1)
            else
                backward_X_MME = xQ
            end
            index_lead_variant_list_pass = []
            ranki = 1
            _df_test = copy(df_test)
            for bi in 1:n_forward_variants
                println("Backward rank: ", bi)
                rm_col = n_forward_variants - bi + 1
                @runif n_forward_variants > 1 backward_X_MME .= lead_variant_and_X_MME[:, setdiff(1:size(lead_variant_and_X_MME, 2), rm_col)]
                index_lead_variant = index_lead_variant_list[bi]
                summary_test_minp_df .= NAN
                ind_index_tested_pheno = 0
                for group_pheno_i in 1:group_size
                    pheno_id = group_pheno_ids[group_pheno_i]
                    chrom_index_tested_pheno = findfirst(_gene_annot.pheno_id .== pheno_id)
                    global_index_tested_pheno = _gene_annot.index[_gene_annot.pheno_id.==pheno_id]
                    yQ = chrom_yQ[:, chrom_index_tested_pheno]
                    if qtl_map_algo == "idul"
                        idul_prior_index = sample(1:n_cis_snps, 10)
                        df_subs = fill(FloatT(NAN), 10, 3 * n_tests + 2)
                        idul_assoc_test_plus!(df_subs, cis_genotype[:, idul_prior_index], yQ, backward_X_MME, glo_EA.values; max_iter=_args_idul_max_iter, thre=FloatT.(_args_idul_converge), return_detail=true, is_calcu_pv=false)
                        init_eta = Statistics.mean(df_subs[.!isnan.(df_subs[:, 2]), 2])
                        @runif isnan(init_eta) init_eta = FloatT(1e-5)
                        if !_args_exact_map
                            idul_assoc_test_approx!(df_test, cis_genotype, yQ, backward_X_MME, glo_EA.values; init_eta=init_eta, is_calcu_pv=false)
                        else
                            idul_assoc_test_plus!(df_test, cis_genotype, yQ, backward_X_MME, glo_EA.values; max_iter=_args_idul_max_iter, thre=FloatT.(_args_idul_converge), init_eta=init_eta, is_calcu_pv=false)
                        end
                    end
                    summary_test_minp .= df_test[index_lead_variant, :]
                    summary_test_minp[3] = ccdf(FDist(1, _n - size(backward_X_MME, 2) - 1), summary_test_minp[3])
                    summary_test_minp_df[group_pheno_i, :] .= summary_test_minp
                    if group_pheno_i == 1
                        _df_test .= df_test
                        ind_index_tested_pheno = chrom_index_tested_pheno
                    elseif group_pheno_i > 1
                        if summary_test_minp_df[group_pheno_i, 3] < summary_test_minp_df[1, 3]
                            _df_test .= df_test
                            ind_index_tested_pheno = chrom_index_tested_pheno
                        end
                    end
                    pval_g1_threshold = sig_df_tops.pval_g1_threshold[index_tested_gene]
                    if !_args_nominal_only
                        Q, _dof = residualizer(glo_EA.vectors * backward_X_MME)
                        QQt = Q * Q'
                        cis_genotype .= chrom_genotype[:, cissnps_annot.reindex]
                        get_matrix_resid!(cis_genotype, QQt, return_std=false)
                        if permutation_method == "standard_fast"
                            y_perms .= phenotype[:, global_index_tested_pheno] .- Statistics.mean(phenotype[:, global_index_tested_pheno])
                            Random.seed!(_args_seed)
                            @inbounds @views for perm_i in 1:n_perms
                                shuffle!(y_perms[:, perm_i])
                            end
                            get_matrix_resid!(y_perms, QQt, return_std=false)
                            fast_linear_permutation_test!(cis_genotype, y_perms, absr_perm, byrow=is_sample_byrow)
                        elseif permutation_method == "clipper"
                            pheno_perm = vec(get_matrix_resid(phenotype[:, global_index_tested_pheno], QQt, return_std=false))
                            fast_permutation_clipper!(absr_perm, cis_genotype, pheno_perm, n_perms; byrow=is_sample_byrow)
                        end
                        pval_g1_threshold = sort(get_approx_p_from_r(absr_perm, _dof))[ceil(Int, n_perms * _args_fdr)]
                    end
                    pval_g1_threshold_group[group_pheno_i] = pval_g1_threshold
                    if n_grms < 2
                        cis_genotype .= chrom_SQ[:, cissnps_annot.reindex]
                    else
                        cis_genotype .= glo_EA.vectors' * chrom_genotype[:, cissnps_annot.reindex]
                    end
                end
                snp_r = cor(lead_variant_and_X_MME[:, rm_col], lead_variant_and_X_MME[:, n_forward_variants])
                if (minimum(summary_test_minp_df[:, 3]) <= minimum(pval_g1_threshold_group)) | (n_forward_variants == 1)
                    @runif !isnothing(_args_ind_r2) if n_forward_variants > 1
                        if abs2(snp_r) > _args_ind_r2
                            continue
                        end
                    end
                    append!(index_lead_variant_list_pass, index_lead_variant)
                    variant_id = cissnps_annot.variant[index_lead_variant]
                    start_distance = cissnps_annot.start_distance[index_lead_variant]
                    af = cissnps_annot.af[index_lead_variant]
                    het_rate = cissnps_annot.het_rate[index_lead_variant]
                    beta_g1, beta_se_g1, pval_g1 = summary_test_minp_df[argmin(summary_test_minp_df[:, 3]), :]
                    _df_backward = DataFrame([
                        "pheno_id" => _gene_annot.pheno_id[ind_index_tested_pheno],
                        "variant_id" => variant_id,
                        "start_distance" => start_distance,
                        "af" => af,
                        "het_rate" => het_rate,
                        "beta_g1" => beta_g1,
                        "beta_se_g1" => beta_se_g1,
                        "pval_g1" => pval_g1,
                        "rank" => ranki,
                        "snp_r" => snp_r,
                        "map_model" => qtl_map_model,
                    ])
                    append!(_df_inds, _df_backward)
                    snp_rs = [cor(cis_genotype[:, index_lead_variant], x) for x in eachcol(cis_genotype)]
                    begin
                        _df_full.rank .= ranki
                        _df_full.snp_r .= snp_rs
                        _df_full.beta_g1 .= _df_test[:, 1]
                        _df_full.beta_se_g1 .= _df_test[:, 2]
                        _df_full.pval_g1 .= ccdf(FDist(1, _n - size(lead_variant_and_X_MME, 2) - 1), _df_test[:, 3])
                        append!(df_full, _df_full)
                    end
                    ranki += 1
                end
            end
            @runif _args_verbose if i % 10 == 0
                println_to_file(string("*** Elapsed time (h:m:s:ms): ", format_milliseconds(now() - time_start)), log_file)
                show(to)
                println()
            end
        end
        @runif isnothing(_args_pheno_group_file) for i in 1:_n_genes
            println_to_file(string("GENE: ", i, "/", _n_genes), log_file)
            gene = _gene_annot.pheno_id[i]
            index_tested_gene = findfirst(sig_df_tops.pheno_id .== gene)
            global_index_tested_gene = _gene_annot.index[findfirst(_gene_annot.pheno_id .== gene)]
            cissnps_annot, n_cis_snps = get_cis_snp_info(_gene_annot, _snp_annot, gene, _args_cis_window)
            begin
                if is_sample_byrow
                    if qtl_map_algo == "standard"
                        cis_genotype = chrom_genotype[:, cissnps_annot.reindex]
                    elseif qtl_map_algo == "idul"
                        if n_grms == 1
                            cis_genotype = chrom_SQ[:, cissnps_annot.reindex]
                            @runif _args_run_mode == "cis_interaction" cis_genotype_iterm = chrom_SIQ[:, cissnps_annot.reindex]
                        elseif n_grms == 2
                            cis_genotype = chrom_genotype[:, cissnps_annot.reindex]
                        end
                    end
                else
                    cis_genotype = chrom_genotype[cissnps_annot.reindex, :]
                end
                if (qtl_map_model in ["a+d+A+D"])
                    cis_genotype_2nd = chrom_domGenotype[cissnps_annot.reindex, :]
                end
            end
            exppheno = vec(sig_phenotype[:, sig_gene_annot.pheno_id.==gene])
            begin
                df_test = zeros(FloatT, n_cis_snps, 3)
                _df_full = DataFrame([
                    "pheno_id" => gene,
                    "variant_id" => cissnps_annot.variant, "rank" => 1,
                    "snp_r" => NAN,
                ])
                if n_tests == 2
                    _df_full = hcat(_df_full, DataFrame(df_test[:, 1:end-1], Symbol.(["beta_g1", "beta_se_g1", "pval_g1", "beta_g2", "beta_se_g2", "pval_g2"])))
                    if USE_Float32
                        _df_full.pval_g1 = Float64.(_df_full.pval_g1)
                        _df_full.pval_g2 = Float64.(_df_full.pval_g2)
                    end
                end
                if n_tests == 1
                    _df_full = hcat(_df_full, DataFrame(df_test, Symbol.(["beta_g1", "beta_se_g1", "pval_g1"])))
                    if USE_Float32
                        _df_full.pval_g1 = Float64.(_df_full.pval_g1)
                    end
                end
            end
            if (qtl_map_algo == "idul") & (qtl_map_model in ["d+A+D"])
                if !isnothing(prior_h2)
                    index_prior_h2 = findfirst(prior_h2.pheno_id .== gene)
                    Σ_i = [prior_h2.glo_vg1[index_prior_h2], prior_h2.glo_vg2[index_prior_h2], prior_h2.glo_ve[index_prior_h2]]
                    glo_vc_B = vec(prior_B[index_prior_h2, 3:end])
                end
                ratio = maximum([Σ_i[1] / Σ_i[2], Σ_i[2] / Σ_i[1]])
                println("Ratio between vg1 and vg2: ", ratio)
                if ratio > maximum(_struct_PartialV.vec_ratio)
                    if ratio > 1000
                        if Σ_i[2] > Σ_i[1]
                            glo_EA.vectors .= _struct_KIN.domEA.vectors
                            glo_EA.values .= _struct_KIN.domEA.values * Σ_i[2]
                        else
                            glo_EA.vectors .= _struct_KIN.EA.vectors
                            glo_EA.values .= _struct_KIN.EA.values * Σ_i[1]
                        end
                    else
                        cGRM .= Σ_i[1] * _struct_KIN.GRM + Σ_i[2] * _struct_KIN.domGRM
                        glo_EA = eigen!(cGRM)
                    end
                else
                    ratio_index = argmin(abs.(ratio .- _struct_PartialV.vec_ratio)) * 2
                    if Σ_i[1] >= Σ_i[2]
                        ratio_index -= 1
                    end
                    j = ratio_index
                    range_inds = _n*(j-1)+1:_n*j
                    vals_inds = CartesianIndices((range_inds,))
                    vecs_inds = CartesianIndices((range_inds, 1:_n))
                    copyto!(glo_EA.vectors, Inds_AD_vecs, _struct_PartialV.eigvecs, vecs_inds)
                    glo_EA.values .= _struct_PartialV.eigvals[vals_inds] * sum(Σ_i[1:2])
                end
                cis_genotype .= glo_EA.vectors' * cis_genotype
                mul!(yQ, glo_EA.vectors', exppheno)
                mul!(xQ, glo_EA.vectors', X_MME)
            end
            lead_variant = sig_df_tops.variant_id[index_tested_gene]
            index_lead_variant = findfirst(cissnps_annot.variant .== lead_variant)
            index_lead_variant_list = [index_lead_variant]
            if qtl_map_algo == "standard"
                lead_variant_and_X_MME = hcat(cis_genotype[index_lead_variant, :], X_MME)
            elseif qtl_map_algo == "idul"
                if n_grms == 1
                    yQ = chrom_yQ[:, i]
                end
                lead_variant_and_X_MME = hcat(cis_genotype[:, index_lead_variant], xQ)
            end
            ranki = 1
            summary_test_minp = [NAN, NAN, NAN]
            snp_h2 = snp_h2_se = acc_h2 = acc_h2_se = NAN
            while true
                println("Forward rank: ", ranki)
                if qtl_map_algo == "idul"
                    idul_prior_index = sample(1:n_cis_snps, 10)
                    df_subs = fill(FloatT(NAN), 10, 3 * n_tests + 2)
                    idul_assoc_test_plus!(df_subs, cis_genotype[:, idul_prior_index], yQ, lead_variant_and_X_MME, glo_EA.values; max_iter=_args_idul_max_iter, thre=FloatT.(_args_idul_converge), return_detail=true, is_calcu_pv=false)
                    init_eta = Statistics.mean(df_subs[.!isnan.(df_subs[:, 2]), 2])
                    @runif isnan(init_eta) init_eta = FloatT(1e-5)
                    if !_args_exact_map
                        idul_assoc_test_approx!(df_test, cis_genotype, yQ, lead_variant_and_X_MME, glo_EA.values; init_eta=init_eta, is_calcu_pv=false)
                    else
                        idul_assoc_test_plus!(df_test, cis_genotype, yQ, lead_variant_and_X_MME, glo_EA.values; max_iter=_args_idul_max_iter, thre=FloatT.(_args_idul_converge), init_eta=init_eta, is_calcu_pv=false)
                    end
                end
                index_lead_variant = first_nonnan_argmax(df_test[:, 3])
                @runif index_lead_variant == -1 break
                summary_test_minp .= df_test[index_lead_variant, :]
                summary_test_minp[3] = ccdf(FDist(1, _n - size(lead_variant_and_X_MME, 2) - 1), summary_test_minp[3])
                pval_g1_threshold = sig_df_tops.pval_g1_threshold[index_tested_gene]
                if !_args_nominal_only
                    Q, _dof = residualizer(glo_EA.vectors * lead_variant_and_X_MME)
                    QQt = Q * Q'
                    cis_genotype .= chrom_genotype[:, cissnps_annot.reindex]
                    get_matrix_resid!(cis_genotype, QQt, return_std=false)
                    if permutation_method == "standard_fast"
                        y_perms .= phenotype[:, global_index_tested_gene] .- Statistics.mean(phenotype[:, global_index_tested_gene])
                        Random.seed!(_args_seed)
                        @inbounds @views for perm_i in 1:n_perms
                            shuffle!(y_perms[:, perm_i])
                        end
                        get_matrix_resid!(y_perms, QQt, return_std=false)
                        fast_linear_permutation_test!(cis_genotype, y_perms, absr_perm, byrow=is_sample_byrow)
                    elseif permutation_method == "clipper"
                        pheno_perm = get_matrix_resid(phenotype[:, global_index_tested_gene], QQt, return_std=false)
                        fast_permutation_clipper!(absr_perm, cis_genotype, pheno_perm, n_perms; byrow=is_sample_byrow)
                    end
                    pval_g1_threshold = sort(get_approx_p_from_r(absr_perm, _dof))[ceil(Int, n_perms * _args_fdr)]
                end
                if n_grms < 2
                    cis_genotype .= chrom_SQ[:, cissnps_annot.reindex]
                else
                    cis_genotype .= glo_EA.vectors' * chrom_genotype[:, cissnps_annot.reindex]
                end
                if summary_test_minp[3] <= pval_g1_threshold
                    ranki = ranki + 1
                    push!(index_lead_variant_list, index_lead_variant)
                    lead_variant_and_X_MME = hcat(cis_genotype[:, index_lead_variant], lead_variant_and_X_MME)
                else
                    break
                end
            end
            n_forward_variants = length(index_lead_variant_list)
            if n_forward_variants > 1
                backward_X_MME = fill(NAN, _n, size(lead_variant_and_X_MME, 2) - 1)
            else
                backward_X_MME = xQ
            end
            index_lead_variant_list_pass = []
            ranki = 1
            for bi in 1:n_forward_variants
                println("Backward rank: ", bi)
                rm_col = n_forward_variants - bi + 1
                @runif n_forward_variants > 1 backward_X_MME .= lead_variant_and_X_MME[:, setdiff(1:size(lead_variant_and_X_MME, 2), rm_col)]
                index_lead_variant = index_lead_variant_list[bi]
                if qtl_map_algo == "standard"
                    yadj = exppheno - lead_variant_and_X_MME * glo_vc[:Fix_eff]
                    if qtl_map_model in ["a+A", "d+D", "d+A"]
                        getVinv!(_Vi, _Di, glo_EA, glo_Σ_i, _EAvec_Di)
                    elseif qtl_map_model in ["a+A+D", "d+A+D", "a+d+A+D"]
                        getVinv!(_Vi, glo_Σ_i, _struct_PartialV, _Di, _EAvec_Di, _EAvec)
                    end
                    calcu_one_assoc_test!(df_test, _Vi, cis_genotype, yadj)
                elseif qtl_map_algo == "idul"
                    idul_prior_index = sample(1:n_cis_snps, 10)
                    df_subs = fill(FloatT(NAN), 10, 3 * n_tests + 2)
                    idul_assoc_test_plus!(df_subs, cis_genotype[:, idul_prior_index], yQ, backward_X_MME, glo_EA.values; max_iter=_args_idul_max_iter, thre=FloatT.(_args_idul_converge), return_detail=true, is_calcu_pv=false)
                    init_eta = Statistics.mean(df_subs[.!isnan.(df_subs[:, 2]), 2])
                    @runif isnan(init_eta) init_eta = FloatT(1e-5)
                    if !_args_exact_map
                        idul_assoc_test_approx!(df_test, cis_genotype, yQ, backward_X_MME, glo_EA.values; init_eta=init_eta, is_calcu_pv=false)
                    else
                        idul_assoc_test_plus!(df_test, cis_genotype, yQ, backward_X_MME, glo_EA.values; max_iter=_args_idul_max_iter, thre=FloatT.(_args_idul_converge), init_eta=init_eta, is_calcu_pv=false)
                    end
                end
                summary_test_minp .= df_test[index_lead_variant, :]
                beta_g1, beta_se_g1, pval_g1 = summary_test_minp
                pval_g1 = ccdf(FDist(1, _n - size(backward_X_MME, 2) - 1), pval_g1)
                pval_g1_threshold = sig_df_tops.pval_g1_threshold[index_tested_gene]
                if !_args_nominal_only
                    Q, _dof = residualizer(glo_EA.vectors * backward_X_MME)
                    QQt = Q * Q'
                    cis_genotype .= chrom_genotype[:, cissnps_annot.reindex]
                    get_matrix_resid!(cis_genotype, QQt, return_std=false)
                    if permutation_method == "standard_fast"
                        y_perms .= phenotype[:, global_index_tested_gene] .- Statistics.mean(phenotype[:, global_index_tested_gene])
                        Random.seed!(_args_seed)
                        @inbounds @views for perm_i in 1:n_perms
                            shuffle!(y_perms[:, perm_i])
                        end
                        get_matrix_resid!(y_perms, QQt, return_std=false)
                        fast_linear_permutation_test!(cis_genotype, y_perms, absr_perm, byrow=is_sample_byrow)
                    elseif permutation_method == "clipper"
                        pheno_perm = get_matrix_resid(phenotype[:, global_index_tested_gene], QQt, return_std=false)
                        fast_permutation_clipper!(absr_perm, cis_genotype, pheno_perm, n_perms; byrow=is_sample_byrow)
                    end
                    pval_g1_threshold = sort(get_approx_p_from_r(absr_perm, _dof))[ceil(Int, n_perms * _args_fdr)]
                end
                if n_grms < 2
                    cis_genotype .= chrom_SQ[:, cissnps_annot.reindex]
                else
                    cis_genotype .= glo_EA.vectors' * chrom_genotype[:, cissnps_annot.reindex]
                end
                snp_r = cor(lead_variant_and_X_MME[:, rm_col], lead_variant_and_X_MME[:, n_forward_variants])
                if (pval_g1 <= pval_g1_threshold) | (n_forward_variants == 1)
                    @runif !isnothing(_args_ind_r2) if n_forward_variants > 1
                        if abs2(snp_r) > _args_ind_r2
                            continue
                        end
                    end
                    append!(index_lead_variant_list_pass, index_lead_variant)
                    if est_ind_h2
                        begin
                            if qtl_map_algo == "idul"
                                geno_lead_variant = glo_EA.vectors * cis_genotype[:, index_lead_variant:index_lead_variant]
                            end
                            if qtl_map_model in ["d+D", "d+A+D"]
                                getG_dominance!(GRM64, Float64.(geno_lead_variant), code_type="dominance", adjusted=true, afs=Float64.([cissnps_annot.af[index_lead_variant]]), byrow=true)
                            elseif qtl_map_model in ["a+A", "a+A+D", "d+A"]
                                getG_VanRaden!(GRM64, Float64.(geno_lead_variant), adjusted=true, afs=Float64.([cissnps_annot.af[index_lead_variant]]), byrow=true)
                            end
                            cGRM .= GRM64
                            _Vi .= cGRM
                            snp_GRM_EA = eigen!(_Vi)
                            if h2_algo == "minmax"
                                snp_vc = getOpenMendelVC(cGRM, exppheno, EA=snp_GRM_EA, X=X_MME, algo=:MM)
                            elseif (h2_algo == "idul") | true
                                snp_xQ = snp_GRM_EA.vectors' * X_MME
                                snp_vc = get_IDUL_VarianceComponent(snp_GRM_EA, exppheno, X_MME, xQ=snp_xQ)
                            end
                            snp_h2 = snp_vc[:h2]
                            snp_h2_se = snp_vc[:h2_se]
                        end
                        begin
                            if ranki > 1
                                if qtl_map_algo == "idul"
                                    geno_lead_variants = glo_EA.vectors * cis_genotype[:, index_lead_variant_list_pass]
                                end
                                if qtl_map_model in ["d+D", "d+A+D"]
                                    getG_dominance!(GRM64, Float64.(geno_lead_variants), code_type="dominance", adjusted=true, afs=Float64.(cissnps_annot.af[index_lead_variant_list]), byrow=true)
                                elseif qtl_map_model in ["a+A", "a+A+D", "d+A"]
                                    getG_VanRaden!(GRM64, Float64.(geno_lead_variants), adjusted=true, afs=Float64.(cissnps_annot.af[index_lead_variant_list]), byrow=true)
                                end
                                cGRM .= GRM64
                                _Vi .= cGRM
                                acc_GRM_EA = eigen!(_Vi)
                                if h2_algo == "minmax"
                                    acc_vc = getOpenMendelVC(cGRM, exppheno, EA=acc_GRM_EA, X=X_MME, algo=:MM)
                                elseif (h2_algo == "idul") | true
                                    acc_xQ = acc_GRM_EA.vectors' * X_MME
                                    acc_vc = get_IDUL_VarianceComponent(acc_GRM_EA, exppheno, X_MME, xQ=acc_xQ)
                                end
                                acc_h2 = acc_vc[:h2]
                                acc_h2_se = acc_vc[:h2_se]
                            else
                                acc_h2 = snp_h2
                                acc_h2_se = snp_h2_se
                            end
                        end
                    end
                    variant_id = cissnps_annot.variant[index_lead_variant]
                    start_distance = cissnps_annot.start_distance[index_lead_variant]
                    snpaf = cissnps_annot.af[index_lead_variant]
                    het_rate = cissnps_annot.het_rate[index_lead_variant]
                    if est_ind_h2
                        _df_backward = DataFrame([
                            "pheno_id" => gene,
                            "variant_id" => variant_id,
                            "start_distance" => start_distance,
                            "af" => snpaf,
                            "het_rate" => het_rate,
                            "beta_g1" => beta_g1,
                            "beta_se_g1" => beta_se_g1,
                            "pval_g1" => pval_g1,
                            "rank" => ranki,
                            "snp_r" => snp_r,
                            "map_model" => qtl_map_model,
                            "snp_h2" => snp_h2,
                            "snp_h2_se" => snp_h2_se,
                            "acc_h2" => acc_h2,
                            "acc_h2_se" => acc_h2_se,
                        ])
                    else
                        _df_backward = DataFrame([
                            "pheno_id" => gene,
                            "variant_id" => variant_id,
                            "start_distance" => start_distance,
                            "af" => snpaf,
                            "het_rate" => het_rate,
                            "beta_g1" => beta_g1,
                            "beta_se_g1" => beta_se_g1,
                            "pval_g1" => pval_g1,
                            "rank" => ranki,
                            "snp_r" => snp_r,
                            "map_model" => qtl_map_model,
                        ])
                    end
                    append!(_df_inds, _df_backward)
                    snp_rs = [cor(cis_genotype[:, index_lead_variant], x) for x in eachcol(cis_genotype)]
                    begin
                        _df_full.rank .= ranki
                        _df_full.snp_r .= snp_rs
                        _df_full.beta_g1 .= df_test[:, 1]
                        _df_full.beta_se_g1 .= df_test[:, 2]
                        _df_full.pval_g1 .= ccdf(FDist(1, _n - size(lead_variant_and_X_MME, 2) - 1), df_test[:, 3])
                        append!(df_full, _df_full)
                    end
                    ranki += 1
                end
            end
            @runif _args_verbose if i % 10 == 0
                println_to_file(string("*** Elapsed time (h:m:s:ms): ", format_milliseconds(now() - time_start)), log_file)
                show(to)
                println()
            end
        end
        cols_float = [df_full[1, x] isa AbstractFloat for x in range(1, ncol(df_full))]
        df_full[:, cols_float] = round.(df_full[:, cols_float], sigdigits=6)
        if !_args_write_top
            if chrom != chroms[1]
                wait(_task_write_full_pairs)
            end
            task_df_full = copy(df_full)
            task_chrom = chrom
            _task_write_full_pairs = @spawn begin
                chrom_full_out_file = joinpath(_args_output_dir, string(_args_out_prefix, ".cis_independent_pairs.", task_chrom, ".txt.gz"))
                @runif _args_use_gzip chrom_full_out_file = replace(chrom_full_out_file, r".gz$" => "")
                CSV.write(chrom_full_out_file, task_df_full, delim="\t", compress=!_args_use_gzip)
                @runif _args_use_gzip run(`gzip -f $chrom_full_out_file`; wait=chrom == chroms[end])
            end
            if chrom == chroms[end]
                wait(_task_write_full_pairs)
            end
        end
        @runif !_args_nominal_only begin
            cols_float = [eltype(_df_inds[:, x]) == FloatT for x in range(1, ncol(_df_inds))]
            _df_inds[:, cols_float] = round.(_df_inds[:, cols_float], sigdigits=6)
            if length(_args_chrom) > 0
                CSV.write(joinpath(_args_output_dir, string(_args_out_prefix, ".cis_independent.", chrom, ".txt")), _df_inds, delim="\t")
            else
                is_append = chrom != chroms[1]
                CSV.write(joinpath(_args_output_dir, string(_args_out_prefix, ".cis_independent.txt.gz")), _df_inds, delim="\t", compress=true, append=is_append)
            end
        end
        println_to_file(string("+++ Total elapsed time (h:m:s:ms): ", format_milliseconds(now() - time_start)), log_file)
        append!(df_inds, _df_inds)
        if _args_verbose
            println_to_file(string(to), log_file)
            println()
        end
    end
    if _args_verbose
        show(to)
    end
end
