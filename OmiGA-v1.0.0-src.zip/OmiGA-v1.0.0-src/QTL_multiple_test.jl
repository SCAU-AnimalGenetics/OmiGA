```
 * OmiGA: a toolkit for Omics Genetic Analysis
 *
 * Copyright © 2024, Jinyan Teng
 *
 * This file is distributed under the GNU General Public
 * License, Version 3. Please see the file LICENSE for more
 * details.
 *
 * All the files in this project are allowed to be copied, 
 * modified, and distributed for educational, research and 
 * non-profit purposes, without charge and without a written 
 * agreement, provided that this copyright notice are included
 * in all copies. If you intend to use this project for 
 * commercial purposes, kindly contact the author for 
 * authorization prior to use.
```
function runOmiGA_cis_mt()
    time_start = now()
    println_to_file(string("  cis_mt mode start at: ", time_start), log_file)
    df_tops = DataFrame()
    if length(_args_cis_output) > 1
        for fn in _args_cis_output
            _df_tops = CSV.File(fn, header=true, buffer_in_memory=true) |> DataFrame
            append!(df_tops, _df_tops)
        end
    else
        if isfile(_args_cis_output[1])
            file_cis_qtl_txt = _args_cis_output
            df_tops = CSV.File(file_cis_qtl_txt, header=true, buffer_in_memory=true) |> DataFrame
        else
            error("Please provide correct cis-file!")
        end
    end
    n_tests = any(.!isnothing.(match.(r"g2", names(df_tops)))) ? 2 : 1
    cis_summary_prefix = replace(_args_cis_output[1], ".cis_qtl.txt.gz" => "")
    summary_dir = dirname(cis_summary_prefix)
    file_prefix = basename(cis_summary_prefix)
    if _args_output_significant_qtls
        significant_phenotypes = df_tops.pheno_id[df_tops[:, ["qval_g1", "qval_g2"][n_tests]].<_args_fdr]
        all_files = readdir(summary_dir)
        full_summary_files = all_files[.!isnothing.(match.(Regex(string(file_prefix, ".cis_qtl_pairs")), all_files))]
        println_to_file(string("Found ", length(full_summary_files), " *.cis_qtl_pairs.txt.gz files."), log_file)
        if length(full_summary_files) == 0
            error("*.cis_qtl_pairs.txt.gz files must be provided the same dir as ", basename(_args_cis_output[1]))
        else
            sorted_indices = sortperm(replace.(full_summary_files, ".txt.gz" => "", r"(.)*.cis_qtl_pairs." => ""), lt=compare_chromosomes)
            full_summary_files = full_summary_files[sorted_indices]
            n_significant_qtls = 0
            out_file = joinpath(summary_dir, string(file_prefix, ".significant_qtl_pairs.txt.gz"))
            for fn in full_summary_files
                _df_sig_qtls_df = DataFrame()
                println_to_file(string("    * Processing ", fn), log_file)
                _cis_qtl_pairs = CSV.File(joinpath(summary_dir, fn)) |> DataFrame
                _cis_qtl_pairs = _cis_qtl_pairs[_cis_qtl_pairs[:, ["pval_g1", "pval_g2"][n_tests]].<=maximum(df_tops[:, ["pval_g1_threshold", "pval_g2_threshold"][n_tests]]), :]
                pheno_ids = unique(_cis_qtl_pairs.pheno_id)
                pheno_ids = pheno_ids[findall(pheno_ids .∈ (significant_phenotypes,))]
                for _pid in pheno_ids
                    _pval_mt = _cis_qtl_pairs[_cis_qtl_pairs.pheno_id.==_pid, :]
                    append!(_df_sig_qtls_df, _pval_mt[_pval_mt[:, ["pval_g1", "pval_g2"][n_tests]].<=df_tops[findfirst(df_tops.pheno_id .== _pid), ["pval_g1_threshold", "pval_g2_threshold"][n_tests]], :])
                end
                n_significant_qtls += size(_df_sig_qtls_df, 1)
                CSV.write(out_file, _df_sig_qtls_df, delim="\t", compress=true, append=fn != full_summary_files[1])
            end
            println_to_file(string(" *** Found ", n_significant_qtls, " significant variant-phenotype pairs."), log_file)
        end
        return 0
    end
    if isnothing(_args_multiple_testing)
        error("--multiple-testing must be specified!")
    else
        multiple_testing_method = _args_multiple_testing
    end
    df_tops_mt = copy(df_tops)
    df_tops_mt.mt_method .= multiple_testing_method
    if multiple_testing_method == "acat"
        df_tops_mt[:, ["pval_g1_acat", "pval_g2_acat"][n_tests]] .= NaN
        df_tops_mt[:, ["qval_g1", "qval_g2"][n_tests]] .= NaN
        all_files = readdir(summary_dir)
        full_summary_files = all_files[.!isnothing.(match.(Regex(string(file_prefix, ".cis_qtl_pairs")), all_files))]
        println_to_file(string("Found ", length(full_summary_files), " *.cis_qtl_pairs.txt.gz files."), log_file)
        if length(full_summary_files) == 0
            error("*.cis_qtl_pairs.txt.gz files must be provided the same dir as ", basename(_args_cis_output[1]))
        else
            sorted_indices = sortperm(replace.(full_summary_files, ".txt.gz" => "", r"(.)*.cis_qtl_pairs." => ""), lt=compare_chromosomes)
            full_summary_files = full_summary_files[sorted_indices]
            for fn in full_summary_files
                println_to_file(string("    * Processing ", fn), log_file)
                _cis_qtl_pairs = CSV.File(joinpath(summary_dir, fn)) |> DataFrame
                pheno_ids = unique(_cis_qtl_pairs.pheno_id)
                for _pid in pheno_ids
                    _pval_mt = _cis_qtl_pairs[_cis_qtl_pairs.pheno_id.==_pid, ["pval_g1", "pval_g2"][n_tests]]
                    df_tops_mt[df_tops_mt.pheno_id.==_pid, ["pval_g1_acat", "pval_g2_acat"][n_tests]] .= ACATest(_pval_mt; is_check=false)
                end
            end
            pval_mt = df_tops_mt[:, ["pval_g1_acat", "pval_g2_acat"][n_tests]]
            if any(isnan.(pval_mt))
                error(string("Cannot found ", df_tops_mt.pheno_id[isnan.(pval_mt)], " in *.cis_qtl_pairs.txt.gz files."))
            end
            if isnothing(_args_storey_lambda)
                qval_mt = MultipleTesting.adjust(pval_mt, BenjaminiHochberg())
            else
                qval_mt = MultipleTesting.adjust(pval_mt, BenjaminiHochbergAdaptive(Storey(_args_storey_lambda)))
            end
            df_tops_mt[:, ["qval_g1", "qval_g2"][n_tests]] .= qval_mt
        end
    end
    if multiple_testing_method in ["beta_approx", "clipper"]
        DOF = df_tops.dof[1]
        perm_file = joinpath(summary_dir, file_prefix) * ".perm.txt.gz"
        if !isfile(perm_file)
            error("Cannot found " * perm_file)
        end
        df_perm = CSV.File(perm_file) |> DataFrame
    end
    if multiple_testing_method == "beta_approx"
        df_tops_mt.pval_beta .= NaN
        df_tops_mt.beta_shape1 .= NAN
        df_tops_mt.beta_shape2 .= NAN
        df_tops_mt.true_dof .= NAN
        df_tops_mt.pval_true_dof .= NaN
        for i in axes(df_tops_mt, 1)
            r2_nominal = abs2(df_perm[i, ["X1", "X2"][n_tests]])
            if n_tests == 1
                absr_perm = df_perm[i, 4:end] |> Vector
            elseif n_tests == 2
                absr_perm = df_perm[i, ((2-1)+6):3:size(df_perm, 2)] |> Vector
            end
            df_tops_mt[i, ["pval_beta", "beta_shape1", "beta_shape2", "true_dof", "pval_true_dof"]] .= calculate_beta_approx_pval(abs2.(absr_perm), r2_nominal, DOF, 1e-4)
        end
        pval_mt = df_tops_mt.pval_beta
        if isnothing(_args_storey_lambda)
            qval_mt = MultipleTesting.adjust(pval_mt, BenjaminiHochbergAdaptive(Storey()))
        else
            qval_mt = MultipleTesting.adjust(pval_mt, BenjaminiHochbergAdaptive(Storey(_args_storey_lambda)))
        end
        if sum(qval_mt .<= _args_fdr) > 0
            set0_indices = findall(qval_mt .<= _args_fdr)
            set1_indices = findall(qval_mt .> _args_fdr)
            pthreshold = (sort(df_tops_mt.pval_beta[set1_indices])[1] - sort(-1.0 * df_tops_mt.pval_beta[set0_indices])[1]) / 2
            funbeta = Beta.(df_tops_mt.beta_shape1, df_tops_mt.beta_shape2)
            df_tops_mt[:, ["pval_g1_threshold", "pval_g2_threshold"][n_tests]] .= quantile.(funbeta, pthreshold)
        end
        df_tops_mt[:, ["qval_g1", "qval_g2"][n_tests]] .= qval_mt
    end
    if multiple_testing_method == "clipper"
        if !isnothing(_args_pheno_group_file)
            reduced_df_tops = DataFrames.combine(groupby(df_tops, :group_id)) do grouped
                min_row_index = first_nonnan_argmin(grouped.pval_g1)
                return grouped[min_row_index, :]
            end
            reduced_df_tops.group_size .= DataFrames.combine(groupby(df_tops, :group_id), nrow).nrow
            reduced_df_perm = copy(df_perm)
            reduced_df_perm.pheno_id .= df_tops.group_id
            df_perm_gdf = groupby(reduced_df_perm, :pheno_id)
            reduced_df_perm = DataFrames.combine(df_perm_gdf, :pheno_id, valuecols(df_perm_gdf) .=> maximum)
            reduced_df_perm = unique(reduced_df_perm, [:pheno_id])
            df_perm_clipper = reduced_df_perm
            df_tops_mt = reduced_df_tops
        else
            df_perm_clipper = df_perm
            df_tops_mt = df_tops
        end
        clipper_keep_index = .!isnan.(df_perm_clipper[:, 3])
        if n_tests == 1
            df_tops_mt.qval_g1 .= NaN
            if n_perms < 1000
                res_clipper = Clipper(Matrix(df_perm_clipper[clipper_keep_index, 3:3]), Matrix(df_perm_clipper[clipper_keep_index, 4:end]), analysis="enrichment", procedure="GZ", contrast_score="max", FDR=[FloatT(_args_fdr)])
                qval_mt = res_clipper["q"]
            else
                numsOfPermsMoreSig = sum(Matrix(df_perm_clipper[clipper_keep_index, 3:3]) .- Matrix(df_perm_clipper[clipper_keep_index, 4:end]) .<= 0, dims=2)
                pval_mt = vec((numsOfPermsMoreSig .+ 1) ./ (n_perms + 1))
                if isnothing(_args_storey_lambda)
                    qval_mt = MultipleTesting.adjust(pval_mt, BenjaminiHochbergAdaptive(Storey()))
                else
                    qval_mt = MultipleTesting.adjust(pval_mt, BenjaminiHochbergAdaptive(Storey(_args_storey_lambda)))
                end
            end
            df_tops_mt.qval_g1[clipper_keep_index] .= qval_mt
            n_significant_phenotypes = sum((df_tops_mt.qval_g1 .< FloatT(_args_fdr)) .& (df_tops_mt.pval_g1 .< df_tops_mt.pval_g1_threshold))
            logtxt = string("  *** ", n_significant_phenotypes, " out of ", sum(clipper_keep_index), " tested phenotypes with significant cis-QTL.")
            println_to_file(logtxt, log_file)
        elseif n_tests == 2
            for i in 2:2
                idx_exp = ((i-1)+3):((i-1)+3)
                idx_back = ((i-1)+6):3:size(df_perm_clipper, 2) |> Vector
                n_perms = length(idx_back)
                if n_perms < 1000
                    res_clipper = Clipper(Matrix(df_perm_clipper[clipper_keep_index, idx_exp]), Matrix(df_perm_clipper[clipper_keep_index, idx_back]), analysis="enrichment", procedure="GZ", contrast_score="max", FDR=[FloatT(_args_fdr)])
                    qval_mt = res_clipper["q"]
                else
                    numsOfPermsMoreSig = sum(Matrix(df_perm_clipper[clipper_keep_index, idx_exp]) .- Matrix(df_perm_clipper[clipper_keep_index, idx_back]) .<= 0, dims=2)
                    pval_mt = vec((numsOfPermsMoreSig .+ 1) ./ (n_perms + 1))
                    if isnothing(_args_storey_lambda)
                        qval_mt = MultipleTesting.adjust(pval_mt, BenjaminiHochbergAdaptive(Storey()))
                    else
                        qval_mt = MultipleTesting.adjust(pval_mt, BenjaminiHochbergAdaptive(Storey(_args_storey_lambda)))
                    end
                end
                if i == 1
                    df_tops_mt.qval_g1 .= NaN
                    df_tops_mt.qval_g1[clipper_keep_index] .= qval_mt
                    logtxt = string("  *** ", sum(qval_mt .< FloatT(_args_fdr)), " out of ", sum(clipper_keep_index), " tested phenotypes with significant cis-QTL(g1).")
                    println_to_file(logtxt, log_file)
                elseif i == 2
                    pval_g2_threshold = [sort(get_approx_p_from_r(Vector(df_perm_clipper[pix, idx_back]), DOF - 1))[ceil(Int, n_perms * _args_fdr)] for pix in axes(df_perm_clipper, 1)]
                    df_tops_mt.pval_g2_threshold .= pval_g2_threshold
                    df_tops_mt.qval_g2 .= NaN
                    df_tops_mt.qval_g2[clipper_keep_index] .= qval_mt
                    n_significant_phenotypes = sum((df_tops_mt.qval_g2 .< FloatT(_args_fdr)) .& (df_tops_mt.pval_g2 .< df_tops_mt.pval_g2_threshold))
                    logtxt = string("  *** ", n_significant_phenotypes, " out of ", sum(clipper_keep_index), " tested phenotypes with significant cis-QTL(g2).")
                    println_to_file(logtxt, log_file)
                elseif i == 3
                    df_tops_mt.qval_joint .= NaN
                    df_tops_mt.qval_joint[clipper_keep_index] .= qval_mt
                end
            end
        end
    end
    cols_float = [df_tops_mt[1, x] isa AbstractFloat for x in range(1, ncol(df_tops_mt))]
    df_tops_mt[:, cols_float] = round.(df_tops_mt[:, cols_float], sigdigits=6)
    CSV.write(joinpath(_args_output_dir, string(_args_out_prefix, ".cis_qtl_mt.txt.gz")), df_tops_mt, delim="\t", compress=true)
    println_to_file(string("+++ Total elapsed time (h:m:s:ms): ", format_milliseconds(now() - time_start)), log_file)
    if _args_debug
        println_to_file(string(to), log_file)
        println()
    end
    return df_tops_mt
end
